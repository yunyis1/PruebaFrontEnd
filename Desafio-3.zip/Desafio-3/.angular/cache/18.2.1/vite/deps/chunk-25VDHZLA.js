import {
  EventsStrategy
} from "./chunk-IMMMCDPJ.js";
import {
  getHeight,
  getWidth,
  renderer_default
} from "./chunk-M4HNHSVV.js";
import {
  ready_callbacks_default
} from "./chunk-IY7TXKCY.js";
import {
  call_once_default
} from "./chunk-E4ZFM5M7.js";
import {
  callbacks_default,
  config_default,
  dom_adapter_default,
  error_default,
  errors_default,
  extend,
  getNavigator,
  getWindow,
  hasWindow,
  isPlainObject
} from "./chunk-V6EUNM2D.js";

// node_modules/devextreme/esm/core/utils/view_port.js
var ready = ready_callbacks_default.add;
var changeCallback = callbacks_default();
var $originalViewPort = renderer_default();
var value = /* @__PURE__ */ function() {
  let $current;
  return function(element) {
    if (!arguments.length) {
      return $current;
    }
    const $element = renderer_default(element);
    $originalViewPort = $element;
    const isNewViewportFound = !!$element.length;
    const prevViewPort = value();
    $current = isNewViewportFound ? $element : renderer_default("body");
    changeCallback.fire(isNewViewportFound ? value() : renderer_default(), prevViewPort);
  };
}();
ready(function() {
  value(".dx-viewport");
});
function originalViewPort() {
  return $originalViewPort;
}

// node_modules/devextreme/esm/core/utils/resize_callbacks.js
var resizeCallbacks = function() {
  let prevSize;
  const callbacks = callbacks_default();
  const originalCallbacksAdd = callbacks.add;
  const originalCallbacksRemove = callbacks.remove;
  if (!hasWindow()) {
    return callbacks;
  }
  const formatSize = function() {
    const window3 = getWindow();
    return {
      width: window3.innerWidth,
      height: window3.innerHeight
    };
  };
  const handleResize = function() {
    const now = formatSize();
    if (now.width === prevSize.width && now.height === prevSize.height) {
      return;
    }
    let changedDimension;
    if (now.width === prevSize.width) {
      changedDimension = "height";
    }
    if (now.height === prevSize.height) {
      changedDimension = "width";
    }
    prevSize = now;
    callbacks.fire(changedDimension);
  };
  const setPrevSize = call_once_default(function() {
    prevSize = formatSize();
  });
  let removeListener;
  callbacks.add = function() {
    const result = originalCallbacksAdd.apply(callbacks, arguments);
    setPrevSize();
    ready_callbacks_default.add(function() {
      if (!removeListener && callbacks.has()) {
        removeListener = dom_adapter_default.listen(getWindow(), "resize", handleResize);
      }
    });
    return result;
  };
  callbacks.remove = function() {
    const result = originalCallbacksRemove.apply(callbacks, arguments);
    if (!callbacks.has() && removeListener) {
      removeListener();
      removeListener = void 0;
    }
    return result;
  };
  return callbacks;
}();
var resize_callbacks_default = resizeCallbacks;

// node_modules/devextreme/esm/core/utils/storage.js
var window = getWindow();
var getSessionStorage = function() {
  let sessionStorage;
  try {
    sessionStorage = window.sessionStorage;
  } catch (e) {
  }
  return sessionStorage;
};

// node_modules/devextreme/esm/core/devices.js
var window2 = getWindow();
var KNOWN_UA_TABLE = {
  iPhone: "iPhone",
  iPhone5: "iPhone",
  iPhone6: "iPhone",
  iPhone6plus: "iPhone",
  iPad: "iPad",
  iPadMini: "iPad Mini",
  androidPhone: "Android Mobile",
  androidTablet: "Android",
  msSurface: "Windows ARM Tablet PC",
  desktop: "desktop"
};
var DEFAULT_DEVICE = {
  deviceType: "desktop",
  platform: "generic",
  version: [],
  phone: false,
  tablet: false,
  android: false,
  ios: false,
  generic: true,
  grade: "A",
  mac: false
};
var UA_PARSERS = {
  generic(userAgent) {
    const isPhone = /windows phone/i.test(userAgent) || userAgent.match(/WPDesktop/);
    const isTablet = !isPhone && /Windows(.*)arm(.*)Tablet PC/i.test(userAgent);
    const isDesktop = !isPhone && !isTablet && /msapphost/i.test(userAgent);
    const isMac = /((intel|ppc) mac os x)/.test(userAgent.toLowerCase());
    if (!(isPhone || isTablet || isDesktop || isMac)) {
      return null;
    }
    return {
      deviceType: isPhone ? "phone" : isTablet ? "tablet" : "desktop",
      platform: "generic",
      version: [],
      grade: "A",
      mac: isMac
    };
  },
  appleTouchDevice(userAgent) {
    const navigator = getNavigator();
    const isIpadOs = /Macintosh/i.test(userAgent) && (null === navigator || void 0 === navigator ? void 0 : navigator.maxTouchPoints) > 2;
    const isAppleDevice = /ip(hone|od|ad)/i.test(userAgent);
    if (!isAppleDevice && !isIpadOs) {
      return null;
    }
    const isPhone = /ip(hone|od)/i.test(userAgent);
    const matches = userAgent.match(/os\s{0,}X? (\d+)_(\d+)_?(\d+)?/i);
    const version = matches ? [parseInt(matches[1], 10), parseInt(matches[2], 10), parseInt(matches[3] || 0, 10)] : [];
    const isIPhone4 = 480 === window2.screen.height;
    const grade = isIPhone4 ? "B" : "A";
    return {
      deviceType: isPhone ? "phone" : "tablet",
      platform: "ios",
      version,
      grade
    };
  },
  android(userAgent) {
    const isAndroid = /android|htc_|silk/i.test(userAgent);
    const isWinPhone = /windows phone/i.test(userAgent);
    if (!isAndroid || isWinPhone) {
      return null;
    }
    const isPhone = /mobile/i.test(userAgent);
    const matches = userAgent.match(/android (\d+)\.?(\d+)?\.?(\d+)?/i);
    const version = matches ? [parseInt(matches[1], 10), parseInt(matches[2] || 0, 10), parseInt(matches[3] || 0, 10)] : [];
    const worseThan4_4 = version.length > 1 && (version[0] < 4 || 4 === version[0] && version[1] < 4);
    const grade = worseThan4_4 ? "B" : "A";
    return {
      deviceType: isPhone ? "phone" : "tablet",
      platform: "android",
      version,
      grade
    };
  }
};
var UA_PARSERS_ARRAY = [UA_PARSERS.appleTouchDevice, UA_PARSERS.android, UA_PARSERS.generic];
var Devices = class {
  constructor(options) {
    this._window = (null === options || void 0 === options ? void 0 : options.window) || window2;
    this._realDevice = this._getDevice();
    this._currentDevice = void 0;
    this._currentOrientation = void 0;
    this._eventsStrategy = new EventsStrategy(this);
    this.changed = callbacks_default();
    if (hasWindow()) {
      ready_callbacks_default.add(this._recalculateOrientation.bind(this));
      resize_callbacks_default.add(this._recalculateOrientation.bind(this));
    }
  }
  current(deviceOrName) {
    if (deviceOrName) {
      this._currentDevice = this._getDevice(deviceOrName);
      this._forced = true;
      this.changed.fire();
      return;
    }
    if (!this._currentDevice) {
      deviceOrName = void 0;
      try {
        deviceOrName = this._getDeviceOrNameFromWindowScope();
      } catch (e) {
        deviceOrName = this._getDeviceNameFromSessionStorage();
      } finally {
        if (!deviceOrName) {
          deviceOrName = this._getDeviceNameFromSessionStorage();
        }
        if (deviceOrName) {
          this._forced = true;
        }
      }
      this._currentDevice = this._getDevice(deviceOrName);
    }
    return this._currentDevice;
  }
  real(forceDevice) {
    return extend({}, this._realDevice);
  }
  orientation() {
    return this._currentOrientation;
  }
  isForced() {
    return this._forced;
  }
  isRippleEmulator() {
    return !!this._window.tinyHippos;
  }
  _getCssClasses(device) {
    const result = [];
    const realDevice = this._realDevice;
    device = device || this.current();
    if (device.deviceType) {
      result.push(`dx-device-${device.deviceType}`);
      if ("desktop" !== device.deviceType) {
        result.push("dx-device-mobile");
      }
    }
    result.push(`dx-device-${realDevice.platform}`);
    if (realDevice.version && realDevice.version.length) {
      result.push(`dx-device-${realDevice.platform}-${realDevice.version[0]}`);
    }
    if (this.isSimulator()) {
      result.push("dx-simulator");
    }
    if (config_default().rtlEnabled) {
      result.push("dx-rtl");
    }
    return result;
  }
  attachCssClasses(element, device) {
    this._deviceClasses = this._getCssClasses(device).join(" ");
    renderer_default(element).addClass(this._deviceClasses);
  }
  detachCssClasses(element) {
    renderer_default(element).removeClass(this._deviceClasses);
  }
  isSimulator() {
    try {
      return this._isSimulator || hasWindow() && this._window.top !== this._window.self && this._window.top["dx-force-device"] || this.isRippleEmulator();
    } catch (e) {
      return false;
    }
  }
  forceSimulator() {
    this._isSimulator = true;
  }
  _getDevice(deviceName) {
    if ("genericPhone" === deviceName) {
      deviceName = {
        deviceType: "phone",
        platform: "generic",
        generic: true
      };
    }
    if (isPlainObject(deviceName)) {
      return this._fromConfig(deviceName);
    } else {
      let ua;
      if (deviceName) {
        ua = KNOWN_UA_TABLE[deviceName];
        if (!ua) {
          throw errors_default.Error("E0005");
        }
      } else {
        const navigator = getNavigator();
        ua = navigator.userAgent;
      }
      return this._fromUA(ua);
    }
  }
  _getDeviceOrNameFromWindowScope() {
    let result;
    if (hasWindow() && (this._window.top["dx-force-device-object"] || this._window.top["dx-force-device"])) {
      result = this._window.top["dx-force-device-object"] || this._window.top["dx-force-device"];
    }
    return result;
  }
  _getDeviceNameFromSessionStorage() {
    const sessionStorage = getSessionStorage();
    if (!sessionStorage) {
      return;
    }
    const deviceOrName = sessionStorage.getItem("dx-force-device");
    try {
      return JSON.parse(deviceOrName);
    } catch (ex) {
      return deviceOrName;
    }
  }
  _fromConfig(config) {
    const result = extend({}, DEFAULT_DEVICE, this._currentDevice, config);
    const shortcuts = {
      phone: "phone" === result.deviceType,
      tablet: "tablet" === result.deviceType,
      android: "android" === result.platform,
      ios: "ios" === result.platform,
      generic: "generic" === result.platform
    };
    return extend(result, shortcuts);
  }
  _fromUA(ua) {
    for (let idx = 0; idx < UA_PARSERS_ARRAY.length; idx += 1) {
      const parser = UA_PARSERS_ARRAY[idx];
      const config = parser(ua);
      if (config) {
        return this._fromConfig(config);
      }
    }
    return DEFAULT_DEVICE;
  }
  _changeOrientation() {
    const $window = renderer_default(this._window);
    const orientation = getHeight($window) > getWidth($window) ? "portrait" : "landscape";
    if (this._currentOrientation === orientation) {
      return;
    }
    this._currentOrientation = orientation;
    this._eventsStrategy.fireEvent("orientationChanged", [{
      orientation
    }]);
  }
  _recalculateOrientation() {
    const windowWidth = getWidth(this._window);
    if (this._currentWidth === windowWidth) {
      return;
    }
    this._currentWidth = windowWidth;
    this._changeOrientation();
  }
  on(eventName, eventHandler) {
    this._eventsStrategy.on(eventName, eventHandler);
    return this;
  }
  off(eventName, eventHandler) {
    this._eventsStrategy.off(eventName, eventHandler);
    return this;
  }
};
var devices = new Devices();
var viewPortElement = value();
if (viewPortElement) {
  devices.attachCssClasses(viewPortElement);
}
changeCallback.add((viewPort, prevViewport) => {
  devices.detachCssClasses(prevViewport);
  devices.attachCssClasses(viewPort);
});
var devices_default = devices;

// node_modules/devextreme/esm/ui/widget/ui.errors.js
var ui_errors_default = error_default(errors_default.ERROR_MESSAGES, {
  E1001: "Module '{0}'. Controller '{1}' is already registered",
  E1002: "Module '{0}'. Controller '{1}' does not inherit from DevExpress.ui.dxDataGrid.Controller",
  E1003: "Module '{0}'. View '{1}' is already registered",
  E1004: "Module '{0}'. View '{1}' does not inherit from DevExpress.ui.dxDataGrid.View",
  E1005: "Public method '{0}' is already registered",
  E1006: "Public method '{0}.{1}' does not exist",
  E1007: "State storing cannot be provided due to the restrictions of the browser",
  E1010: "The template does not contain the TextBox widget",
  E1011: 'Items cannot be deleted from the List. Implement the "remove" function in the data store',
  E1012: "Editing type '{0}' with the name '{1}' is unsupported",
  E1016: "Unexpected type of data source is provided for a lookup column",
  E1018: "The 'collapseAll' method cannot be called if you use a remote data source",
  E1019: "Search mode '{0}' is unavailable",
  E1020: "The type cannot be changed after initialization",
  E1021: "{0} '{1}' you are trying to remove does not exist",
  E1022: 'The "markers" option is given an invalid value. Assign an array instead',
  E1023: 'The "routes" option is given an invalid value. Assign an array instead',
  E1025: "This layout is too complex to render",
  E1026: 'The "calculateCustomSummary" function is missing from a field whose "summaryType" option is set to "custom"',
  E1031: "Unknown subscription in the Scheduler widget: '{0}'",
  E1032: "Unknown start date in an appointment: '{0}'",
  E1033: "Unknown step in the date navigator: '{0}'",
  E1034: "The browser does not implement an API for saving files",
  E1035: "The editor cannot be created: {0}",
  E1037: "Invalid structure of grouped data",
  E1038: "The browser does not support local storages for local web pages",
  E1039: "A cell's position cannot be calculated",
  E1040: "The '{0}' key value is not unique within the data array",
  E1041: "The '{0}' script is referenced after the DevExtreme scripts or not referenced at all",
  E1042: "{0} requires the key field to be specified",
  E1043: "Changes cannot be processed due to the incorrectly set key",
  E1044: "The key field specified by the keyExpr option does not match the key field specified in the data store",
  E1045: "Editing requires the key field to be specified in the data store",
  E1046: "The '{0}' key field is not found in data objects",
  E1047: 'The "{0}" field is not found in the fields array',
  E1048: 'The "{0}" operation is not found in the filterOperations array',
  E1049: "Column '{0}': filtering is allowed but the 'dataField' or 'name' option is not specified",
  E1050: "The validationRules option does not apply to third-party editors defined in the editCellTemplate",
  E1051: `HtmlEditor's valueType is "{0}", but the {0} converter was not imported.`,
  E1052: '{0} should have the "dataSource" option specified',
  E1053: 'The "buttons" option accepts an array that contains only objects or string values',
  E1054: "All text editor buttons must have names",
  E1055: 'One or several text editor buttons have invalid or non-unique "name" values',
  E1056: 'The {0} widget does not support buttons of the "{1}" type',
  E1058: 'The "startDayHour" and "endDayHour" options must be integers in the [0, 24] range, with "endDayHour" being greater than "startDayHour".',
  E1059: "The following column names are not unique: {0}",
  E1060: "All editable columns must have names",
  E1061: 'The "offset" option must be an integer in the [-1440, 1440] range, divisible by 5 without a remainder.',
  E1062: 'The "cellDuration" must be a positive integer, evenly dividing the ("endDayHour" - "startDayHour") interval into minutes.',
  W1001: 'The "key" option cannot be modified after initialization',
  W1002: "An item with the key '{0}' does not exist",
  W1003: "A group with the key '{0}' in which you are trying to select items does not exist",
  W1004: "The item '{0}' you are trying to select in the group '{1}' does not exist",
  W1005: "Due to column data types being unspecified, data has been loaded twice in order to apply initial filter settings. To resolve this issue, specify data types for all grid columns.",
  W1006: "The map service returned the following error: '{0}'",
  W1007: "No item with key {0} was found in the data source, but this key was used as the parent key for item {1}",
  W1008: "Cannot scroll to the '{0}' date because it does not exist on the current view",
  W1009: "Searching works only if data is specified using the dataSource option",
  W1010: "The capability to select all items works with source data of plain structure only",
  W1011: 'The "keyExpr" option is not applied when dataSource is not an array',
  W1012: "The '{0}' key field is not found in data objects",
  W1013: 'The "message" field in the dialog component was renamed to "messageHtml". Change your code correspondingly. In addition, if you used HTML code in the message, make sure that it is secure',
  W1014: "The Floating Action Button exceeds the recommended speed dial action count. If you need to display more speed dial actions, increase the maxSpeedDialActionCount option value in the global config.",
  W1016: "The '{0}' field in the HTML Editor toolbar item configuration was renamed to '{1}'. Please make a corresponding change in your code.",
  W1017: "The 'key' property is not specified for a lookup data source. Please specify it to prevent requests for the entire dataset when users filter data.",
  W1018: "Infinite scrolling may not work properly with multiple selection. To use these features together, set 'selection.deferred' to true or set 'selection.selectAllMode' to 'page'.",
  W1019: "Filter query string exceeds maximum length limit of {0} characters.",
  W1020: "hideEvent is ignored when the shading property is true",
  W1021: `The '{0}' is not rendered because none of the DOM elements match the value of the "container" property.`,
  W1022: "{0} JSON parsing error: '{1}'",
  W1023: "Appointments require unique keys. Otherwise, the agenda view may not work correctly.",
  W1024: "The client-side export is enabled. Implement the 'onExporting' function.",
  W1025: "'scrolling.mode' is set to 'virtual' or 'infinite'. Specify the height of the component."
});

export {
  resize_callbacks_default,
  getSessionStorage,
  changeCallback,
  value,
  originalViewPort,
  devices_default,
  ui_errors_default
};
//# sourceMappingURL=chunk-25VDHZLA.js.map
