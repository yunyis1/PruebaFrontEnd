import {
  ui_collection_widget_edit_default
} from "./chunk-7WJHXR3Y.js";
import {
  ui_widget_default
} from "./chunk-GJ5KWMNN.js";

// node_modules/devextreme/esm/__internal/ui/widget.js
var TypedWidget = ui_widget_default;
var widget_default = TypedWidget;

// node_modules/devextreme/esm/__internal/ui/collection/edit.js
var TypedCollectionWidget = ui_collection_widget_edit_default;
var edit_default = TypedCollectionWidget;

export {
  widget_default,
  edit_default
};
//# sourceMappingURL=chunk-3UEUMB2C.js.map
