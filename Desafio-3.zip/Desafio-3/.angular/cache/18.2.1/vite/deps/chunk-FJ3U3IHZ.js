import {
  ui_hierarchical_collection_widget_default
} from "./chunk-G3IF5HS3.js";
import {
  ui_scrollable_default
} from "./chunk-VRGBSUXM.js";
import {
  hold_default,
  m_collection_widget_edit_strategy_plain_default,
  m_item_default,
  name
} from "./chunk-7WJHXR3Y.js";
import {
  DxiItemComponent,
  DxiItemModule,
  DxoAnimationModule,
  DxoAtModule,
  DxoBoundaryOffsetModule,
  DxoCollisionModule,
  DxoDelayModule,
  DxoFromModule,
  DxoHideModule,
  DxoMyModule,
  DxoOffsetModule,
  DxoPositionModule,
  DxoShowEventModule,
  DxoShowModule,
  DxoShowSubmenuModeModule,
  DxoToModule
} from "./chunk-FU2NNGS6.js";
import {
  render
} from "./chunk-H4MEN2W7.js";
import {
  current,
  isMaterialBased
} from "./chunk-ZLMLMAKO.js";
import {
  fx_default,
  position_default,
  ui_overlay_default
} from "./chunk-MY7IBGWI.js";
import {
  addNamespace,
  component_registrator_default,
  contains,
  getPublicElement
} from "./chunk-X73RLF6Y.js";
import {
  devices_default
} from "./chunk-25VDHZLA.js";
import {
  DxComponent,
  DxIntegrationModule,
  DxTemplateHost,
  DxTemplateModule,
  IterableDifferHelper,
  NestedOptionHost,
  WatcherHelper
} from "./chunk-JWCECMBJ.js";
import {
  getOuterHeight,
  renderer_default
} from "./chunk-M4HNHSVV.js";
import {
  events_engine_default
} from "./chunk-PJXMQ5JC.js";
import {
  Deferred,
  asyncNoop,
  dom_adapter_default,
  each,
  extend,
  getWindow,
  guid_default,
  hasWindow,
  isDefined,
  isFunction,
  isObject,
  isPlainObject,
  isRenderer,
  isWindow,
  map,
  noop
} from "./chunk-V6EUNM2D.js";
import {
  Component,
  ContentChildren,
  ElementRef,
  Inject,
  Input,
  NgModule,
  NgZone,
  Output,
  PLATFORM_ID,
  TransferState,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵloadQuery,
  ɵɵqueryRefresh
} from "./chunk-I2242OIJ.js";

// node_modules/devextreme/esm/__internal/ui/collection/hierarchical.js
var TypedCollectionWidget = ui_hierarchical_collection_widget_default;
var hierarchical_default = TypedCollectionWidget;

// node_modules/devextreme/esm/__internal/ui/context_menu/m_menu_base.edit.strategy.js
var MenuBaseEditStrategy = class extends m_collection_widget_edit_strategy_plain_default {
  _getPlainItems() {
    return map(this._collectionWidget.option("items"), function getMenuItems(item) {
      return item.items ? [item].concat(map(item.items, getMenuItems)) : item;
    });
  }
  _stringifyItem(item) {
    return JSON.stringify(item, (key, value) => {
      if ("template" === key) {
        return this._getTemplateString(value);
      }
      return value;
    });
  }
  _getTemplateString(template) {
    let result;
    if ("object" === typeof template) {
      result = renderer_default(template).text();
    } else {
      result = template.toString();
    }
    return result;
  }
};
var m_menu_base_edit_strategy_default = MenuBaseEditStrategy;

// node_modules/devextreme/esm/__internal/ui/context_menu/m_menu_base.js
var ITEM_CLASS = "dx-menu-item";
var DX_ITEM_CONTENT_CLASS = `${ITEM_CLASS}-content`;
var DX_MENU_SELECTED_ITEM_CLASS = `${ITEM_CLASS}-selected`;
var DX_MENU_ITEM_WRAPPER_CLASS = `${ITEM_CLASS}-wrapper`;
var DX_MENU_ITEM_EXPANDED_CLASS = `${ITEM_CLASS}-expanded`;
var DX_ITEM_HAS_TEXT = `${ITEM_CLASS}-has-text`;
var DX_ITEM_HAS_ICON = `${ITEM_CLASS}-has-icon`;
var DX_ITEM_HAS_SUBMENU = `${ITEM_CLASS}-has-submenu`;
var DX_MENU_ITEM_POPOUT_CLASS = `${ITEM_CLASS}-popout`;
var DX_MENU_ITEM_POPOUT_CONTAINER_CLASS = `${DX_MENU_ITEM_POPOUT_CLASS}-container`;
var DX_MENU_ITEM_CAPTION_CLASS = `${ITEM_CLASS}-text`;
var DEFAULT_DELAY = {
  show: 50,
  hide: 300
};
var DX_MENU_ITEM_CAPTION_URL_CLASS = `${DX_MENU_ITEM_CAPTION_CLASS}-with-url`;
var MenuBase = class extends hierarchical_default {
  _getDefaultOptions() {
    return extend(super._getDefaultOptions(), {
      items: [],
      cssClass: "",
      activeStateEnabled: true,
      showSubmenuMode: {
        name: "onHover",
        delay: {
          show: 50,
          hide: 300
        }
      },
      animation: {
        show: {
          type: "fade",
          from: 0,
          to: 1,
          duration: 100
        },
        hide: {
          type: "fade",
          from: 1,
          to: 0,
          duration: 100
        }
      },
      selectByClick: false,
      focusOnSelectedItem: false,
      keyExpr: null,
      _itemAttributes: {
        role: "menuitem"
      },
      useInkRipple: false
    });
  }
  _itemDataKey() {
    return "dxMenuItemDataKey";
  }
  _itemClass() {
    return ITEM_CLASS;
  }
  _setAriaSelectionAttribute($itemElement, isSelected) {
  }
  _selectedItemClass() {
    return DX_MENU_SELECTED_ITEM_CLASS;
  }
  _widgetClass() {
    return "dx-menu-base";
  }
  _focusTarget() {
    return this._itemContainer();
  }
  _clean() {
    this.option("focusedElement", null);
    super._clean();
  }
  _supportedKeys() {
    return extend(super._supportedKeys(), {
      space: () => {
        const $item = renderer_default(this.option("focusedElement"));
        if (!$item.length || !this._isSelectionEnabled()) {
          return;
        }
        this.selectItem($item[0]);
      },
      pageUp: noop,
      pageDown: noop
    });
  }
  _isSelectionEnabled() {
    return "single" === this.option("selectionMode");
  }
  _init() {
    this._activeStateUnit = `.${ITEM_CLASS}`;
    super._init();
    this._renderSelectedItem();
    this._initActions();
  }
  _getLinkContainer(iconContainer, textContainer, itemData) {
    const {
      linkAttr,
      url
    } = itemData;
    null === iconContainer || void 0 === iconContainer || iconContainer.addClass("dx-icon-with-url");
    null === textContainer || void 0 === textContainer || textContainer.addClass(DX_MENU_ITEM_CAPTION_URL_CLASS);
    return super._getLinkContainer(iconContainer, textContainer, {
      linkAttr,
      url
    });
  }
  _addContent($container, itemData) {
    const {
      html,
      url
    } = itemData;
    if (url) {
      $container.html(html);
      const link = this._getLinkContainer(this._getIconContainer(itemData), this._getTextContainer(itemData), itemData);
      $container.append(link);
    } else {
      super._addContent($container, itemData);
    }
    $container.append(this._getPopoutContainer(itemData));
    this._addContentClasses(itemData, $container.parent());
  }
  _getTextContainer(itemData) {
    const {
      text
    } = itemData;
    if (!text) {
      return;
    }
    const $itemContainer = renderer_default("<span>").addClass(DX_MENU_ITEM_CAPTION_CLASS);
    const itemText = isPlainObject(itemData) ? text : String(itemData);
    return $itemContainer.text(itemText);
  }
  _getItemExtraPropNames() {
    return ["url", "linkAttr"];
  }
  _getPopoutContainer(itemData) {
    const {
      items
    } = itemData;
    let $popOutContainer;
    if (items && items.length) {
      const $popOutImage = renderer_default("<div>").addClass(DX_MENU_ITEM_POPOUT_CLASS);
      $popOutContainer = renderer_default("<span>").addClass(DX_MENU_ITEM_POPOUT_CONTAINER_CLASS).append($popOutImage);
    }
    return $popOutContainer;
  }
  _getDataAdapterOptions() {
    return {
      rootValue: 0,
      multipleSelection: false,
      recursiveSelection: false,
      recursiveExpansion: false,
      searchValue: ""
    };
  }
  _selectByItem(selectedItem) {
    if (!selectedItem) {
      return;
    }
    const nodeToSelect = this._dataAdapter.getNodeByItem(selectedItem);
    this._dataAdapter.toggleSelection(nodeToSelect.internalFields.key, true);
  }
  _renderSelectedItem() {
    const selectedKeys = this._dataAdapter.getSelectedNodesKeys();
    const selectedKey = selectedKeys.length && selectedKeys[0];
    const selectedItem = this.option("selectedItem");
    if (!selectedKey) {
      this._selectByItem(selectedItem);
      return;
    }
    const node = this._dataAdapter.getNodeByKey(selectedKey);
    if (false === node.selectable) {
      return;
    }
    if (!selectedItem) {
      this.option("selectedItem", node.internalFields.item);
      return;
    }
    if (selectedItem !== node.internalFields.item) {
      this._dataAdapter.toggleSelection(selectedKey, false);
      this._selectByItem(selectedItem);
    }
  }
  _initActions() {
  }
  _initMarkup() {
    super._initMarkup();
    this.option("useInkRipple") && this._renderInkRipple();
  }
  _renderInkRipple() {
    this._inkRipple = render();
  }
  _toggleActiveState($element, value, e) {
    super._toggleActiveState.apply(this, arguments);
    if (!this._inkRipple) {
      return;
    }
    const config = {
      element: $element,
      event: e
    };
    if (value) {
      this._inkRipple.showWave(config);
    } else {
      this._inkRipple.hideWave(config);
    }
  }
  _getShowSubmenuMode() {
    let optionValue = this.option("showSubmenuMode");
    optionValue = isObject(optionValue) ? optionValue.name : optionValue;
    return this._isDesktopDevice() ? optionValue : "onClick";
  }
  _initSelectedItems() {
  }
  _isDesktopDevice() {
    return "desktop" === devices_default.real().deviceType;
  }
  _initEditStrategy() {
    const Strategy = m_menu_base_edit_strategy_default;
    this._editStrategy = new Strategy(this);
  }
  _addCustomCssClass($element) {
    $element.addClass(this.option("cssClass"));
  }
  _itemWrapperSelector() {
    return `.${DX_MENU_ITEM_WRAPPER_CLASS}`;
  }
  _hoverStartHandler(e) {
    const $itemElement = this._getItemElementByEventArgs(e);
    if (!$itemElement || this._isItemDisabled($itemElement)) {
      return;
    }
    e.stopPropagation();
    if ("onHover" === this._getShowSubmenuMode()) {
      clearTimeout(this._showSubmenusTimeout);
      this._showSubmenusTimeout = setTimeout(this._showSubmenu.bind(this, $itemElement), this._getSubmenuDelay("show"));
    }
  }
  _getAvailableItems($itemElements) {
    return super._getAvailableItems($itemElements).filter(function() {
      return "hidden" !== renderer_default(this).css("visibility");
    });
  }
  _isItemDisabled($item) {
    return this._disabledGetter($item.data(this._itemDataKey()));
  }
  _showSubmenu($itemElement) {
    this._addExpandedClass($itemElement);
  }
  _addExpandedClass(itemElement) {
    renderer_default(itemElement).addClass(DX_MENU_ITEM_EXPANDED_CLASS);
  }
  _getSubmenuDelay(action) {
    const {
      delay
    } = this.option("showSubmenuMode");
    if (!isDefined(delay)) {
      return DEFAULT_DELAY[action];
    }
    return isObject(delay) ? delay[action] : delay;
  }
  _getItemElementByEventArgs(eventArgs) {
    let $target = renderer_default(eventArgs.target);
    if ($target.hasClass(this._itemClass()) || $target.get(0) === eventArgs.currentTarget) {
      return $target;
    }
    while (!$target.hasClass(this._itemClass())) {
      $target = $target.parent();
      if ($target.hasClass("dx-submenu")) {
        return null;
      }
    }
    return $target;
  }
  _hoverEndHandler(event) {
    clearTimeout(this._showSubmenusTimeout);
  }
  _hasSubmenu(node) {
    return node && node.internalFields.childrenKeys.length;
  }
  _renderContentImpl() {
    this._renderItems(this._dataAdapter.getRootNodes());
  }
  _renderItems(nodes, submenuContainer) {
    if (!nodes.length) {
      return;
    }
    this.hasIcons = false;
    const $nodeContainer = this._renderContainer(this.$element(), submenuContainer);
    let firstVisibleIndex = -1;
    let nextGroupFirstIndex = -1;
    each(nodes, (index, node) => {
      const isVisibleNode = false !== node.visible;
      if (isVisibleNode && firstVisibleIndex < 0) {
        firstVisibleIndex = index;
      }
      const isBeginGroup = firstVisibleIndex < index && (node.beginGroup || index === nextGroupFirstIndex);
      if (isBeginGroup) {
        nextGroupFirstIndex = isVisibleNode ? index : index + 1;
      }
      if (index === nextGroupFirstIndex && firstVisibleIndex < index) {
        this._renderSeparator($nodeContainer);
      }
      this._renderItem(index, node, $nodeContainer);
    });
    if (!this.hasIcons) {
      $nodeContainer.addClass("dx-menu-no-icons");
    }
  }
  _renderContainer($wrapper, submenuContainer) {
    const $container = renderer_default("<ul>");
    this.setAria("role", "none", $container);
    return $container.appendTo($wrapper).addClass("dx-menu-items-container");
  }
  _createDOMElement($nodeContainer) {
    const $node = renderer_default("<li>");
    this.setAria("role", "none", $node);
    return $node.appendTo($nodeContainer).addClass(DX_MENU_ITEM_WRAPPER_CLASS);
  }
  _renderItem(index, node, $nodeContainer, $nodeElement) {
    const {
      items = []
    } = this.option();
    const $node = $nodeElement ?? this._createDOMElement($nodeContainer);
    if (items[index + 1] && items[index + 1].beginGroup) {
      $node.addClass("dx-menu-last-group-item");
    }
    const $itemFrame = super._renderItem(index, node.internalFields.item, $node);
    if (node.internalFields.item === this.option("selectedItem")) {
      $itemFrame.addClass(DX_MENU_SELECTED_ITEM_CLASS);
    }
    $itemFrame.attr("tabIndex", -1);
    if (this._hasSubmenu(node)) {
      this.setAria("haspopup", "true", $itemFrame);
    }
  }
  _renderItemFrame(index, itemData, $itemContainer) {
    const $itemFrame = $itemContainer.children(`.${ITEM_CLASS}`);
    return $itemFrame.length ? $itemFrame : super._renderItemFrame.apply(this, arguments);
  }
  _refreshItem($item, item) {
    const node = this._dataAdapter.getNodeByItem(item);
    const index = $item.data(this._itemIndexKey());
    const $nodeContainer = $item.closest("ul");
    const $nodeElement = $item.closest("li");
    this._renderItem(index, node, $nodeContainer, $nodeElement);
  }
  _addContentClasses(itemData, $itemFrame) {
    const hasText = itemData.text ? !!itemData.text.length : false;
    const hasIcon = !!itemData.icon;
    const hasSubmenu = itemData.items ? !!itemData.items.length : false;
    $itemFrame.toggleClass(DX_ITEM_HAS_TEXT, hasText);
    $itemFrame.toggleClass(DX_ITEM_HAS_ICON, hasIcon);
    if (!this.hasIcons) {
      this.hasIcons = hasIcon;
    }
    $itemFrame.toggleClass(DX_ITEM_HAS_SUBMENU, hasSubmenu);
  }
  _getItemContent($itemFrame) {
    let $itemContent = super._getItemContent($itemFrame);
    if (!$itemContent.length) {
      $itemContent = $itemFrame.children(`.${DX_ITEM_CONTENT_CLASS}`);
    }
    return $itemContent;
  }
  _postprocessRenderItem(args) {
    const $itemElement = renderer_default(args.itemElement);
    const selectedIndex = this._dataAdapter.getSelectedNodesKeys();
    if (!selectedIndex.length || !this._selectedGetter(args.itemData) || !this._isItemSelectable(args.itemData)) {
      this._setAriaSelectionAttribute($itemElement, "false");
      return;
    }
    const node = this._dataAdapter.getNodeByItem(args.itemData);
    if (node.internalFields.key === selectedIndex[0]) {
      $itemElement.addClass(this._selectedItemClass());
      this._setAriaSelectionAttribute($itemElement, "true");
    } else {
      this._setAriaSelectionAttribute($itemElement, "false");
    }
  }
  _isItemSelectable(item) {
    return false !== item.selectable;
  }
  _renderSeparator($itemsContainer) {
    renderer_default("<li>").appendTo($itemsContainer).addClass("dx-menu-separator");
  }
  _itemClickHandler(e) {
    if (e._skipHandling) {
      return;
    }
    const itemClickActionHandler = this._createAction(this._updateSubmenuVisibilityOnClick.bind(this));
    this._itemDXEventHandler(e, "onItemClick", {}, {
      beforeExecute: this._itemClick,
      afterExecute: itemClickActionHandler.bind(this)
    });
    e._skipHandling = true;
  }
  _itemClick(actionArgs) {
    const {
      event,
      itemData
    } = actionArgs.args[0];
    const $itemElement = this._getItemElementByEventArgs(event);
    const link = $itemElement && $itemElement.find(".dx-item-url").get(0);
    if (itemData.url && link) {
      link.click();
    }
  }
  _updateSubmenuVisibilityOnClick(actionArgs) {
    this._updateSelectedItemOnClick(actionArgs);
    if ("onClick" === this._getShowSubmenuMode()) {
      this._addExpandedClass(actionArgs.args[0].itemElement);
    }
  }
  _updateSelectedItemOnClick(actionArgs) {
    const args = actionArgs.args ? actionArgs.args[0] : actionArgs;
    if (!this._isItemSelectAllowed(args.itemData)) {
      return;
    }
    const selectedItemKey = this._dataAdapter.getSelectedNodesKeys();
    const selectedNode = selectedItemKey.length && this._dataAdapter.getNodeByKey(selectedItemKey[0]);
    if (selectedNode) {
      this._toggleItemSelection(selectedNode, false);
    }
    if (!selectedNode || selectedNode.internalFields.item !== args.itemData) {
      this.selectItem(args.itemData);
    } else {
      this._fireSelectionChangeEvent(null, this.option("selectedItem"));
      this._setOptionWithoutOptionChange("selectedItem", null);
    }
  }
  _isItemSelectAllowed(item) {
    const isSelectByClickEnabled = this._isSelectionEnabled() && this.option("selectByClick");
    return !this._isContainerEmpty() && isSelectByClickEnabled && this._isItemSelectable(item) && !this._itemsGetter(item);
  }
  _isContainerEmpty() {
    return this._itemContainer().is(":empty");
  }
  _syncSelectionOptions() {
    return asyncNoop();
  }
  _optionChanged(args) {
    switch (args.name) {
      case "showSubmenuMode":
        break;
      case "selectedItem": {
        const node = this._dataAdapter.getNodeByItem(args.value);
        const selectedKey = this._dataAdapter.getSelectedNodesKeys()[0];
        if (node && node.internalFields.key !== selectedKey) {
          if (false === node.selectable) {
            break;
          }
          if (selectedKey) {
            this._toggleItemSelection(this._dataAdapter.getNodeByKey(selectedKey), false);
          }
          this._toggleItemSelection(node, true);
          this._updateSelectedItems();
        }
        break;
      }
      case "cssClass":
      case "position":
      case "selectByClick":
      case "animation":
      case "useInkRipple":
        this._invalidate();
        break;
      default:
        super._optionChanged(args);
    }
  }
  _toggleItemSelection(node, value) {
    const itemElement = this._getElementByItem(node.internalFields.item);
    itemElement && renderer_default(itemElement).toggleClass(DX_MENU_SELECTED_ITEM_CLASS);
    this._dataAdapter.toggleSelection(node.internalFields.key, value);
  }
  _getElementByItem(itemData) {
    let result;
    each(this._itemElements(), (_, itemElement) => {
      if (renderer_default(itemElement).data(this._itemDataKey()) !== itemData) {
        return true;
      }
      result = itemElement;
      return false;
    });
    return result;
  }
  _updateSelectedItems(oldSelection, newSelection) {
    if (oldSelection || newSelection) {
      this._fireSelectionChangeEvent(newSelection, oldSelection);
    }
  }
  _fireSelectionChangeEvent(addedSelection, removedSelection) {
    this._createActionByOption("onSelectionChanged", {
      excludeValidators: ["disabled", "readOnly"]
    })({
      addedItems: [addedSelection],
      removedItems: [removedSelection]
    });
  }
  selectItem(itemElement) {
    const itemData = itemElement.nodeType ? this._getItemData(itemElement) : itemElement;
    const selectedKey = this._dataAdapter.getSelectedNodesKeys()[0];
    const selectedItem = this.option("selectedItem");
    const node = this._dataAdapter.getNodeByItem(itemData);
    if (node.internalFields.key !== selectedKey) {
      if (selectedKey) {
        this._toggleItemSelection(this._dataAdapter.getNodeByKey(selectedKey), false);
      }
      this._toggleItemSelection(node, true);
      this._updateSelectedItems(selectedItem, itemData);
      this._setOptionWithoutOptionChange("selectedItem", itemData);
    }
  }
  unselectItem(itemElement) {
    const itemData = itemElement.nodeType ? this._getItemData(itemElement) : itemElement;
    const node = this._dataAdapter.getNodeByItem(itemData);
    const selectedItem = this.option("selectedItem");
    if (node.internalFields.selected) {
      this._toggleItemSelection(node, false);
      this._updateSelectedItems(selectedItem, null);
      this._setOptionWithoutOptionChange("selectedItem", null);
    }
  }
};
MenuBase.ItemClass = m_item_default;
var m_menu_base_default = MenuBase;

// node_modules/devextreme/esm/__internal/ui/context_menu/m_context_menu.js
var DX_MENU_PHONE_CLASS = "dx-menu-phone-overlay";
var ACTIONS = ["onShowing", "onShown", "onSubmenuCreated", "onHiding", "onHidden", "onPositioning", "onLeftFirstItem", "onLeftLastItem", "onCloseRootSubmenu", "onExpandLastSubmenu"];
var LOCAL_SUBMENU_DIRECTIONS = ["up", "down", "first", "last"];
var window = getWindow();
var ContextMenu = class extends m_menu_base_default {
  getShowEvent(showEventOption) {
    if (isObject(showEventOption)) {
      if (null !== showEventOption.name) {
        return showEventOption.name ?? "dxcontextmenu";
      }
    } else {
      return showEventOption;
    }
    return null;
  }
  getShowDelay(showEventOption) {
    return isObject(showEventOption) && showEventOption.delay;
  }
  _getDefaultOptions() {
    return extend(super._getDefaultOptions(), {
      showEvent: "dxcontextmenu",
      hideOnOutsideClick: true,
      position: {
        at: "top left",
        my: "top left"
      },
      onShowing: null,
      onShown: null,
      onSubmenuCreated: null,
      onHiding: null,
      onHidden: null,
      onPositioning: null,
      submenuDirection: "auto",
      visible: false,
      target: void 0,
      onLeftFirstItem: null,
      onLeftLastItem: null,
      onCloseRootSubmenu: null,
      onExpandLastSubmenu: null
    });
  }
  _defaultOptionsRules() {
    return super._defaultOptionsRules().concat([{
      device: () => !hasWindow(),
      options: {
        animation: null
      }
    }]);
  }
  _setDeprecatedOptions() {
    super._setDeprecatedOptions();
    extend(this._deprecatedOptions, {
      closeOnOutsideClick: {
        since: "22.2",
        alias: "hideOnOutsideClick"
      }
    });
  }
  _initActions() {
    this._actions = {};
    each(ACTIONS, (index, action) => {
      this._actions[action] = this._createActionByOption(action) || noop;
    });
  }
  _setOptionsByReference() {
    super._setOptionsByReference();
    extend(this._optionsByReference, {
      animation: true,
      selectedItem: true
    });
  }
  _focusInHandler() {
  }
  _itemContainer() {
    return this._overlay ? this._overlay.$content() : renderer_default();
  }
  _eventBindingTarget() {
    return this._itemContainer();
  }
  itemsContainer() {
    return this._overlay ? this._overlay.$content() : void 0;
  }
  _supportedKeys() {
    return extend(super._supportedKeys(), {
      space: () => {
        const $item = renderer_default(this.option("focusedElement"));
        this.hide();
        if (!$item.length || !this._isSelectionEnabled()) {
          return;
        }
        this.selectItem($item[0]);
      },
      escape: this.hide
    });
  }
  _getActiveItem(last) {
    const $availableItems = this._getAvailableItems();
    const $focusedItem = $availableItems.filter(".dx-state-focused");
    const $hoveredItem = $availableItems.filter(".dx-state-hover");
    const $hoveredItemContainer = $hoveredItem.closest(".dx-menu-items-container");
    if ($hoveredItemContainer.find(".dx-menu-item").index($focusedItem) >= 0) {
      return $focusedItem;
    }
    if ($hoveredItem.length) {
      return $hoveredItem;
    }
    return super._getActiveItem();
  }
  _moveFocus(location) {
    const $items = this._getItemsByLocation(location);
    const $oldTarget = this._getActiveItem(true);
    const $hoveredItem = this.itemsContainer().find(".dx-state-hover");
    const $focusedItem = renderer_default(this.option("focusedElement"));
    const $activeItemHighlighted = !!($focusedItem.length || $hoveredItem.length);
    let $newTarget;
    switch (location) {
      case "up":
        $newTarget = $activeItemHighlighted ? this._prevItem($items) : $oldTarget;
        this._setFocusedElement($newTarget);
        if ($oldTarget.is($items.first())) {
          this._actions.onLeftFirstItem($oldTarget);
        }
        break;
      case "down":
        $newTarget = $activeItemHighlighted ? this._nextItem($items) : $oldTarget;
        this._setFocusedElement($newTarget);
        if ($oldTarget.is($items.last())) {
          this._actions.onLeftLastItem($oldTarget);
        }
        break;
      case "right":
        $newTarget = this.option("rtlEnabled") ? this._hideSubmenuHandler() : this._expandSubmenuHandler($items, location);
        this._setFocusedElement($newTarget);
        break;
      case "left":
        $newTarget = this.option("rtlEnabled") ? this._expandSubmenuHandler($items, location) : this._hideSubmenuHandler();
        this._setFocusedElement($newTarget);
        break;
      case "first":
        $newTarget = $items.first();
        this._setFocusedElement($newTarget);
        break;
      case "last":
        $newTarget = $items.last();
        this._setFocusedElement($newTarget);
        break;
      default:
        return super._moveFocus(location);
    }
  }
  _setFocusedElement($element) {
    if ($element && 0 !== $element.length) {
      this.option("focusedElement", getPublicElement($element));
      this._scrollToElement($element);
    }
  }
  _scrollToElement($element) {
    const $scrollableElement = $element.closest(".dx-scrollable");
    const scrollableInstance = $scrollableElement.dxScrollable("instance");
    null === scrollableInstance || void 0 === scrollableInstance || scrollableInstance.scrollToElement($element);
  }
  _getItemsByLocation(location) {
    const $activeItem = this._getActiveItem(true);
    let $items;
    if (LOCAL_SUBMENU_DIRECTIONS.includes(location)) {
      $items = $activeItem.closest(".dx-menu-items-container").children().children();
    }
    $items = this._getAvailableItems($items);
    return $items;
  }
  _getAriaTarget() {
    return this.$element();
  }
  _refreshActiveDescendant() {
    if (isDefined(this._overlay)) {
      const $target = this._overlay.$content();
      super._refreshActiveDescendant($target);
    }
  }
  _hideSubmenuHandler() {
    const $curItem = this._getActiveItem(true);
    const $parentItem = $curItem.parents(".dx-menu-item-expanded").first();
    if ($parentItem.length) {
      this._hideSubmenusOnSameLevel($parentItem);
      this._hideSubmenu($curItem.closest(".dx-submenu"));
      return $parentItem;
    }
    this._actions.onCloseRootSubmenu($curItem);
  }
  _expandSubmenuHandler($items, location) {
    const $curItem = this._getActiveItem(true);
    const itemData = this._getItemData($curItem);
    const node = this._dataAdapter.getNodeByItem(itemData);
    const isItemHasSubmenu = this._hasSubmenu(node);
    const $submenu = $curItem.children(".dx-submenu");
    if (isItemHasSubmenu && !$curItem.hasClass("dx-state-disabled")) {
      if (!$submenu.length || "hidden" === $submenu.css("visibility")) {
        this._showSubmenu($curItem);
      }
      return this._nextItem(this._getItemsByLocation(location));
    }
    this._actions.onExpandLastSubmenu($curItem);
    return;
  }
  _clean() {
    if (this._overlay) {
      this._overlay.$element().remove();
      this._overlay = null;
    }
    this._detachShowContextMenuEvents(this._getTarget());
    super._clean();
  }
  _initMarkup() {
    this.$element().addClass("dx-has-context-menu");
    super._initMarkup();
  }
  _render() {
    super._render();
    this._renderVisibility(this.option("visible"));
    this._addWidgetClass();
  }
  _isTargetOutOfComponent(relatedTarget) {
    const isInsideContextMenu = 0 !== renderer_default(relatedTarget).closest(".dx-context-menu").length;
    return !isInsideContextMenu;
  }
  _focusOutHandler(e) {
    const {
      relatedTarget
    } = e;
    if (relatedTarget) {
      const isTargetOutside = this._isTargetOutOfComponent(relatedTarget);
      if (isTargetOutside) {
        this.hide();
      }
    }
    super._focusOutHandler(e);
  }
  _renderContentImpl() {
    this._detachShowContextMenuEvents(this._getTarget());
    this._attachShowContextMenuEvents();
  }
  _attachKeyboardEvents() {
    !this._keyboardListenerId && this._focusTarget().length && super._attachKeyboardEvents();
  }
  _renderContextMenuOverlay() {
    if (this._overlay) {
      return;
    }
    const overlayOptions = this._getOverlayOptions();
    this._overlay = this._createComponent(renderer_default("<div>").appendTo(this._$element), ui_overlay_default, overlayOptions);
    const $overlayContent = this._overlay.$content();
    $overlayContent.addClass("dx-context-menu");
    this._addCustomCssClass($overlayContent);
    this._addPlatformDependentClass($overlayContent);
    this._attachContextMenuEvent();
  }
  preventShowingDefaultContextMenuAboveOverlay() {
    const $itemContainer = this._itemContainer();
    const eventName = addNamespace(name, this.NAME);
    events_engine_default.off($itemContainer, eventName, ".dx-submenu");
    events_engine_default.on($itemContainer, eventName, ".dx-submenu", (e) => {
      e.stopPropagation();
      e.preventDefault();
      events_engine_default.off($itemContainer, eventName, ".dx-submenu");
    });
  }
  _itemContextMenuHandler(e) {
    super._itemContextMenuHandler(e);
    e.stopPropagation();
  }
  _addPlatformDependentClass($element) {
    if (devices_default.current().phone) {
      $element.addClass(DX_MENU_PHONE_CLASS);
    }
  }
  _detachShowContextMenuEvents(target) {
    const showEvent = this.getShowEvent(this.option("showEvent"));
    if (!showEvent) {
      return;
    }
    const eventName = addNamespace(showEvent, this.NAME);
    if (this._showContextMenuEventHandler) {
      events_engine_default.off(dom_adapter_default.getDocument(), eventName, target, this._showContextMenuEventHandler);
    } else {
      events_engine_default.off(renderer_default(target), eventName);
    }
  }
  _attachShowContextMenuEvents() {
    const target = this._getTarget();
    const showEvent = this.getShowEvent(this.option("showEvent"));
    if (!showEvent) {
      return;
    }
    const eventName = addNamespace(showEvent, this.NAME);
    let contextMenuAction = this._createAction((e) => {
      const delay = this.getShowDelay(this.option("showEvent"));
      if (delay) {
        setTimeout(() => this._show(e.event), delay);
      } else {
        this._show(e.event);
      }
    }, {
      validatingTargetName: "target"
    });
    const handler = (e) => contextMenuAction({
      event: e,
      target: renderer_default(e.currentTarget)
    });
    contextMenuAction = this._createAction(contextMenuAction);
    if (isRenderer(target) || target.nodeType || isWindow(target)) {
      this._showContextMenuEventHandler = void 0;
      events_engine_default.on(target, eventName, handler);
    } else {
      this._showContextMenuEventHandler = handler;
      events_engine_default.on(dom_adapter_default.getDocument(), eventName, target, this._showContextMenuEventHandler);
    }
  }
  _hoverEndHandler(e) {
    super._hoverEndHandler(e);
    e.stopPropagation();
  }
  _renderDimensions() {
  }
  _renderContainer($wrapper, submenuContainer) {
    const $holder = submenuContainer || this._itemContainer();
    $wrapper = renderer_default("<div>");
    $wrapper.appendTo($holder).addClass("dx-submenu").css("visibility", submenuContainer ? "hidden" : "visible");
    if (!$wrapper.parent().hasClass("dx-overlay-content")) {
      this._addCustomCssClass($wrapper);
    }
    const $itemsContainer = super._renderContainer($wrapper);
    if (submenuContainer) {
      return $itemsContainer;
    }
    if (this.option("width")) {
      return $itemsContainer.css("minWidth", this.option("width"));
    }
    if (this.option("height")) {
      return $itemsContainer.css("minHeight", this.option("height"));
    }
    return $itemsContainer;
  }
  _renderSubmenuItems(node, $itemFrame) {
    this._renderItems(this._getChildNodes(node), $itemFrame);
    const $submenu = $itemFrame.children(".dx-submenu");
    this._actions.onSubmenuCreated({
      itemElement: getPublicElement($itemFrame),
      itemData: node.internalFields.item,
      submenuElement: getPublicElement($submenu)
    });
    this._initScrollable($submenu);
    this.setAria({
      role: "menu"
    }, $submenu);
  }
  _getOverlayOptions() {
    const position = this.option("position");
    const overlayOptions = {
      focusStateEnabled: this.option("focusStateEnabled"),
      animation: this.option("animation"),
      innerOverlay: true,
      hideOnOutsideClick: (e) => this._hideOnOutsideClickHandler(e),
      propagateOutsideClick: true,
      hideOnParentScroll: true,
      deferRendering: false,
      position: {
        at: position.at,
        my: position.my,
        of: this._getTarget(),
        collision: "flipfit"
      },
      shading: false,
      showTitle: false,
      height: "auto",
      width: "auto",
      onShown: this._overlayShownActionHandler.bind(this),
      onHiding: this._overlayHidingActionHandler.bind(this),
      onHidden: this._overlayHiddenActionHandler.bind(this),
      visualContainer: window
    };
    return overlayOptions;
  }
  _overlayShownActionHandler(arg) {
    this._actions.onShown(arg);
  }
  _overlayHidingActionHandler(arg) {
    this._actions.onHiding(arg);
    if (!arg.cancel) {
      this._hideAllShownSubmenus();
      this._setOptionWithoutOptionChange("visible", false);
    }
  }
  _overlayHiddenActionHandler(arg) {
    this._actions.onHidden(arg);
  }
  _shouldHideOnOutsideClick(e) {
    const {
      closeOnOutsideClick,
      hideOnOutsideClick
    } = this.option();
    if (isFunction(hideOnOutsideClick)) {
      return hideOnOutsideClick(e);
    }
    if (isFunction(closeOnOutsideClick)) {
      return closeOnOutsideClick(e);
    }
    return hideOnOutsideClick || closeOnOutsideClick;
  }
  _hideOnOutsideClickHandler(e) {
    if (!this._shouldHideOnOutsideClick(e)) {
      return false;
    }
    if (dom_adapter_default.isDocument(e.target)) {
      return true;
    }
    const $activeItemContainer = this._getActiveItemsContainer(e.target);
    const $itemContainers = this._getItemsContainers();
    const $clickedItem = this._searchActiveItem(e.target);
    const $rootItem = this.$element().parents(".dx-menu-item");
    const isRootItemClicked = $clickedItem[0] === $rootItem[0] && $clickedItem.length && $rootItem.length;
    const isInnerOverlayClicked = this._isIncludeOverlay($activeItemContainer, $itemContainers) && $clickedItem.length;
    if (isInnerOverlayClicked || isRootItemClicked) {
      if ("onClick" === this._getShowSubmenuMode()) {
        this._hideAllShownChildSubmenus($clickedItem);
      }
      return false;
    }
    return true;
  }
  _getActiveItemsContainer(target) {
    return renderer_default(target).closest(".dx-menu-items-container");
  }
  _getItemsContainers() {
    return this._overlay.$content().find(".dx-menu-items-container");
  }
  _searchActiveItem(target) {
    return renderer_default(target).closest(".dx-menu-item").eq(0);
  }
  _isIncludeOverlay($activeOverlay, $allOverlays) {
    let isSame = false;
    each($allOverlays, (index, $overlay) => {
      if ($activeOverlay.is($overlay) && !isSame) {
        isSame = true;
      }
    });
    return isSame;
  }
  _hideAllShownChildSubmenus($clickedItem) {
    const $submenuElements = $clickedItem.find(".dx-submenu");
    const shownSubmenus = extend([], this._shownSubmenus);
    if ($submenuElements.length > 0) {
      each(shownSubmenus, (index, $submenu) => {
        const $context = this._searchActiveItem($submenu.context).parent();
        if ($context.parent().is($clickedItem.parent().parent()) && !$context.is($clickedItem.parent())) {
          this._hideSubmenu($submenu);
        }
      });
    }
  }
  _initScrollable($container) {
    this._createComponent($container, ui_scrollable_default, {
      useKeyboard: false,
      _onVisibilityChanged: (scrollable) => {
        scrollable.scrollTo(0);
      }
    });
  }
  _setSubMenuHeight($submenu, anchor, isNestedSubmenu) {
    const $itemsContainer = $submenu.find(".dx-menu-items-container");
    const contentHeight = getOuterHeight($itemsContainer);
    const maxHeight = this._getMaxHeight(anchor, !isNestedSubmenu);
    const menuHeight = Math.min(contentHeight, maxHeight);
    $submenu.css("height", isNestedSubmenu ? menuHeight : "100%");
  }
  _getMaxHeight(anchor) {
    let considerAnchorHeight = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : true;
    const windowHeight = getOuterHeight(window);
    const isAnchorRenderer = isRenderer(anchor);
    const document = dom_adapter_default.getDocument();
    const isAnchorDocument = anchor.length && anchor[0] === document;
    if (!isAnchorRenderer || isAnchorDocument) {
      return windowHeight;
    }
    const offsetTop = anchor[0].getBoundingClientRect().top;
    const anchorHeight = getOuterHeight(anchor);
    const availableHeight = considerAnchorHeight ? Math.max(offsetTop, windowHeight - offsetTop - anchorHeight) : Math.max(offsetTop + anchorHeight, windowHeight - offsetTop);
    return availableHeight - 10;
  }
  _dimensionChanged() {
    if (!this._shownSubmenus) {
      return;
    }
    this._shownSubmenus.forEach(($submenu) => {
      const $item = $submenu.closest(".dx-menu-item");
      this._setSubMenuHeight($submenu, $item, true);
      this._scrollToElement($item);
      const submenuPosition = this._getSubmenuPosition($item);
      position_default.setup($submenu, submenuPosition);
    });
  }
  _getSubmenuBorderWidth() {
    return isMaterialBased(current()) ? 0 : 1;
  }
  _showSubmenu($item) {
    const node = this._dataAdapter.getNodeByItem(this._getItemData($item));
    this._hideSubmenusOnSameLevel($item);
    if (!this._hasSubmenu(node)) {
      return;
    }
    let $submenu = $item.children(".dx-submenu");
    const isSubmenuRendered = $submenu.length;
    super._showSubmenu($item);
    if (!isSubmenuRendered) {
      this._renderSubmenuItems(node, $item);
      $submenu = $item.children(".dx-submenu");
    }
    this._setSubMenuHeight($submenu, $item, true);
    if (!this._isSubmenuVisible($submenu)) {
      this._drawSubmenu($item);
    }
  }
  _hideSubmenusOnSameLevel($item) {
    const $expandedItems = $item.parent(".dx-menu-item-wrapper").siblings().find(".dx-menu-item-expanded");
    if ($expandedItems.length) {
      $expandedItems.removeClass("dx-menu-item-expanded");
      this._hideSubmenu($expandedItems.find(".dx-submenu"));
    }
  }
  _hideSubmenuGroup($submenu) {
    if (this._isSubmenuVisible($submenu)) {
      this._hideSubmenuCore($submenu);
    }
  }
  _isSubmenuVisible($submenu) {
    return "visible" === $submenu.css("visibility");
  }
  _drawSubmenu($itemElement) {
    const animation = this.option("animation") ? this.option("animation").show : {};
    const $submenu = $itemElement.children(".dx-submenu");
    const submenuPosition = this._getSubmenuPosition($itemElement);
    if (this._overlay && this._overlay.option("visible")) {
      if (!isDefined(this._shownSubmenus)) {
        this._shownSubmenus = [];
      }
      if (!this._shownSubmenus.includes($submenu)) {
        this._shownSubmenus.push($submenu);
      }
      if (animation) {
        fx_default.stop($submenu);
      }
      position_default.setup($submenu, submenuPosition);
      if (animation) {
        if (isPlainObject(animation.to)) {
          animation.to.position = submenuPosition;
        }
        this._animate($submenu, animation);
      }
      $submenu.css("visibility", "visible");
    }
  }
  _animate($container, options) {
    fx_default.animate($container, options);
  }
  _getSubmenuPosition($rootItem) {
    const submenuDirection = this.option("submenuDirection").toLowerCase();
    const $rootItemWrapper = $rootItem.parent(".dx-menu-item-wrapper");
    const position = {
      collision: "flip",
      of: $rootItemWrapper,
      offset: {
        h: 0,
        v: -1
      }
    };
    switch (submenuDirection) {
      case "left":
        position.at = "left top";
        position.my = "right top";
        break;
      case "right":
        position.at = "right top";
        position.my = "left top";
        break;
      default:
        if (this.option("rtlEnabled")) {
          position.at = "left top";
          position.my = "right top";
        } else {
          position.at = "right top";
          position.my = "left top";
        }
    }
    return position;
  }
  _updateSubmenuVisibilityOnClick(actionArgs) {
    if (!actionArgs.args.length) {
      return;
    }
    const {
      itemData
    } = actionArgs.args[0];
    const node = this._dataAdapter.getNodeByItem(itemData);
    if (!node) {
      return;
    }
    const $itemElement = renderer_default(actionArgs.args[0].itemElement);
    let $submenu = $itemElement.find(".dx-submenu");
    const shouldRenderSubmenu = this._hasSubmenu(node) && !$submenu.length;
    if (shouldRenderSubmenu) {
      this._renderSubmenuItems(node, $itemElement);
      $submenu = $itemElement.find(".dx-submenu");
    }
    if ($itemElement.context === $submenu.context && "visible" === $submenu.css("visibility")) {
      return;
    }
    this._updateSelectedItemOnClick(actionArgs);
    const notCloseMenuOnItemClick = itemData && false === itemData.closeMenuOnClick;
    if (!itemData || itemData.disabled || notCloseMenuOnItemClick) {
      return;
    }
    if (0 === $submenu.length) {
      const $prevSubmenu = renderer_default($itemElement.parents(".dx-submenu")[0]);
      this._hideSubmenu($prevSubmenu);
      if (!actionArgs.canceled && this._overlay && this._overlay.option("visible")) {
        this.option("visible", false);
      }
    } else {
      if (this._shownSubmenus && this._shownSubmenus.length > 0) {
        if (this._shownSubmenus[0].is($submenu)) {
          this._hideSubmenu($submenu);
        }
      }
      this._showSubmenu($itemElement);
    }
  }
  _hideSubmenu($curSubmenu) {
    const shownSubmenus = extend([], this._shownSubmenus);
    each(shownSubmenus, (index, $submenu) => {
      if ($curSubmenu.is($submenu) || contains($curSubmenu[0], $submenu[0])) {
        $submenu.parent().removeClass("dx-menu-item-expanded");
        this._hideSubmenuCore($submenu);
      }
    });
  }
  _hideSubmenuCore($submenu) {
    const index = this._shownSubmenus.indexOf($submenu);
    const animation = this.option("animation") ? this.option("animation").hide : null;
    if (index >= 0) {
      this._shownSubmenus.splice(index, 1);
    }
    this._stopAnimate($submenu);
    animation && this._animate($submenu, animation);
    $submenu.css("visibility", "hidden");
    const scrollableInstance = $submenu.dxScrollable("instance");
    scrollableInstance.scrollTo(0);
    this.option("focusedElement", null);
  }
  _stopAnimate($container) {
    fx_default.stop($container, true);
  }
  _hideAllShownSubmenus() {
    const shownSubmenus = extend([], this._shownSubmenus);
    const $expandedItems = this._overlay.$content().find(".dx-menu-item-expanded");
    $expandedItems.removeClass("dx-menu-item-expanded");
    each(shownSubmenus, (_, $submenu) => {
      this._hideSubmenu($submenu);
    });
  }
  _visibilityChanged(visible) {
    if (visible) {
      this._renderContentImpl();
    }
  }
  _optionChanged(args) {
    if (ACTIONS.includes(args.name)) {
      this._initActions();
      return;
    }
    switch (args.name) {
      case "visible":
        this._renderVisibility(args.value);
        break;
      case "showEvent":
      case "position":
      case "submenuDirection":
        this._invalidate();
        break;
      case "target":
        args.previousValue && this._detachShowContextMenuEvents(args.previousValue);
        this._invalidate();
        break;
      case "closeOnOutsideClick":
      case "hideOnOutsideClick":
        break;
      default:
        super._optionChanged(args);
    }
  }
  _renderVisibility(showing) {
    return showing ? this._show() : this._hide();
  }
  _toggleVisibility() {
  }
  _show(event) {
    const args = {
      jQEvent: event
    };
    let promise = Deferred().reject().promise();
    this._actions.onShowing(args);
    if (args.cancel) {
      return promise;
    }
    const position = this._positionContextMenu(event);
    if (position) {
      var _event$originalEvent;
      if (!this._overlay) {
        this._renderContextMenuOverlay();
        this._overlay.$content().addClass(this._widgetClass());
        this._renderFocusState();
        this._attachHoverEvents();
        this._attachClickEvent();
        this._renderItems(this._dataAdapter.getRootNodes());
      }
      const $subMenu = renderer_default(this._overlay.content()).children(".dx-submenu");
      this._setOptionWithoutOptionChange("visible", true);
      this._overlay.option({
        height: () => this._getMaxHeight(position.of),
        maxHeight: () => {
          const $content = $subMenu.find(".dx-menu-items-container");
          const borderWidth = this._getSubmenuBorderWidth();
          return getOuterHeight($content) + 2 * borderWidth;
        },
        position
      });
      if ($subMenu.length) {
        this._setSubMenuHeight($subMenu, position.of, false);
      }
      promise = this._overlay.show();
      event && event.stopPropagation();
      this._setAriaAttributes();
      if ((null === event || void 0 === event || null === (_event$originalEvent = event.originalEvent) || void 0 === _event$originalEvent ? void 0 : _event$originalEvent.type) === hold_default.name) {
        this.preventShowingDefaultContextMenuAboveOverlay();
      }
    }
    return promise;
  }
  _renderItems(nodes, submenuContainer) {
    super._renderItems(nodes, submenuContainer);
    const $submenu = renderer_default(this._overlay.content()).children(".dx-submenu");
    if ($submenu.length) {
      this._initScrollable($submenu);
    }
  }
  _setAriaAttributes() {
    this._overlayContentId = `dx-${new guid_default()}`;
    this.setAria("owns", this._overlayContentId);
    this.setAria({
      id: this._overlayContentId,
      role: "menu"
    }, this._overlay.$content());
  }
  _cleanAriaAttributes() {
    this._overlay && this.setAria("id", null, this._overlay.$content());
    this.setAria("owns", void 0);
  }
  _getTarget() {
    return this.option("target") || this.option("position").of || renderer_default(dom_adapter_default.getDocument());
  }
  _getContextMenuPosition() {
    return extend({}, this.option("position"), {
      of: this._getTarget()
    });
  }
  _positionContextMenu(jQEvent) {
    let position = this._getContextMenuPosition();
    const isInitialPosition = this._isInitialOptionValue("position");
    const positioningAction = this._createActionByOption("onPositioning");
    if (jQEvent && jQEvent.preventDefault && isInitialPosition) {
      position.of = jQEvent;
    }
    const actionArgs = {
      position,
      event: jQEvent
    };
    positioningAction(actionArgs);
    if (actionArgs.cancel) {
      position = null;
    } else if (actionArgs.event) {
      actionArgs.event.cancel = true;
      jQEvent.preventDefault();
    }
    return position;
  }
  _refresh() {
    if (!hasWindow()) {
      super._refresh();
    } else if (this._overlay) {
      const lastPosition = this._overlay.option("position");
      super._refresh();
      this._overlay && this._overlay.option("position", lastPosition);
    } else {
      super._refresh();
    }
  }
  _hide() {
    let promise;
    if (this._overlay) {
      promise = this._overlay.hide();
      this._setOptionWithoutOptionChange("visible", false);
    }
    this._cleanAriaAttributes();
    this.option("focusedElement", null);
    return promise || Deferred().reject().promise();
  }
  toggle(showing) {
    const visible = this.option("visible");
    showing = void 0 === showing ? !visible : showing;
    return this._renderVisibility(showing);
  }
  show() {
    return this.toggle(true);
  }
  hide() {
    return this.toggle(false);
  }
};
component_registrator_default("dxContextMenu", ContextMenu);
var m_context_menu_default = ContextMenu;

// node_modules/devextreme/esm/ui/context_menu.js
var context_menu_default = m_context_menu_default;

// node_modules/devextreme-angular/fesm2022/devextreme-angular-ui-context-menu.mjs
var DxContextMenuComponent = class _DxContextMenuComponent extends DxComponent {
  _watcherHelper;
  _idh;
  instance = null;
  /**
   * Specifies the shortcut key that sets focus on the UI component.
  
   */
  get accessKey() {
    return this._getOption("accessKey");
  }
  set accessKey(value) {
    this._setOption("accessKey", value);
  }
  /**
   * Specifies whether the UI component changes its visual state as a result of user interaction.
  
   */
  get activeStateEnabled() {
    return this._getOption("activeStateEnabled");
  }
  set activeStateEnabled(value) {
    this._setOption("activeStateEnabled", value);
  }
  /**
   * Configures UI component visibility animations. This object contains two fields: show and hide.
  
   */
  get animation() {
    return this._getOption("animation");
  }
  set animation(value) {
    this._setOption("animation", value);
  }
  /**
   * Specifies whether to close the UI component if a user clicks outside it.
  
   * @deprecated Use the hideOnOutsideClick option instead.
  
   */
  get closeOnOutsideClick() {
    return this._getOption("closeOnOutsideClick");
  }
  set closeOnOutsideClick(value) {
    this._setOption("closeOnOutsideClick", value);
  }
  /**
   * Specifies the name of the CSS class to be applied to the root menu level and all submenus.
  
   */
  get cssClass() {
    return this._getOption("cssClass");
  }
  set cssClass(value) {
    this._setOption("cssClass", value);
  }
  /**
   * Binds the UI component to data.
  
   */
  get dataSource() {
    return this._getOption("dataSource");
  }
  set dataSource(value) {
    this._setOption("dataSource", value);
  }
  /**
   * Specifies whether the UI component responds to user interaction.
  
   */
  get disabled() {
    return this._getOption("disabled");
  }
  set disabled(value) {
    this._setOption("disabled", value);
  }
  /**
   * Specifies the name of the data source item field whose value defines whether or not the corresponding UI component item is disabled.
  
   */
  get disabledExpr() {
    return this._getOption("disabledExpr");
  }
  set disabledExpr(value) {
    this._setOption("disabledExpr", value);
  }
  /**
   * Specifies the data field whose values should be displayed.
  
   */
  get displayExpr() {
    return this._getOption("displayExpr");
  }
  set displayExpr(value) {
    this._setOption("displayExpr", value);
  }
  /**
   * Specifies the global attributes to be attached to the UI component&apos;s container element.
  
   */
  get elementAttr() {
    return this._getOption("elementAttr");
  }
  set elementAttr(value) {
    this._setOption("elementAttr", value);
  }
  /**
   * Specifies whether the UI component can be focused using keyboard navigation.
  
   */
  get focusStateEnabled() {
    return this._getOption("focusStateEnabled");
  }
  set focusStateEnabled(value) {
    this._setOption("focusStateEnabled", value);
  }
  /**
   * Specifies the UI component&apos;s height.
  
   */
  get height() {
    return this._getOption("height");
  }
  set height(value) {
    this._setOption("height", value);
  }
  /**
   * Specifies whether to hide the UI component if a user clicks outside it.
  
   */
  get hideOnOutsideClick() {
    return this._getOption("hideOnOutsideClick");
  }
  set hideOnOutsideClick(value) {
    this._setOption("hideOnOutsideClick", value);
  }
  /**
   * Specifies text for a hint that appears when a user pauses on the UI component.
  
   */
  get hint() {
    return this._getOption("hint");
  }
  set hint(value) {
    this._setOption("hint", value);
  }
  /**
   * Specifies whether the UI component changes its state when a user pauses on it.
  
   */
  get hoverStateEnabled() {
    return this._getOption("hoverStateEnabled");
  }
  set hoverStateEnabled(value) {
    this._setOption("hoverStateEnabled", value);
  }
  /**
   * Holds an array of menu items.
  
   */
  get items() {
    return this._getOption("items");
  }
  set items(value) {
    this._setOption("items", value);
  }
  /**
   * Specifies which data field contains nested items.
  
   */
  get itemsExpr() {
    return this._getOption("itemsExpr");
  }
  set itemsExpr(value) {
    this._setOption("itemsExpr", value);
  }
  /**
   * Specifies a custom template for items.
  
   */
  get itemTemplate() {
    return this._getOption("itemTemplate");
  }
  set itemTemplate(value) {
    this._setOption("itemTemplate", value);
  }
  /**
   * An object defining UI component positioning properties.
  
   */
  get position() {
    return this._getOption("position");
  }
  set position(value) {
    this._setOption("position", value);
  }
  /**
   * Switches the UI component to a right-to-left representation.
  
   */
  get rtlEnabled() {
    return this._getOption("rtlEnabled");
  }
  set rtlEnabled(value) {
    this._setOption("rtlEnabled", value);
  }
  /**
   * Specifies whether an item is selected if a user clicks it.
  
   */
  get selectByClick() {
    return this._getOption("selectByClick");
  }
  set selectByClick(value) {
    this._setOption("selectByClick", value);
  }
  /**
   * Specifies the name of the data source item field whose value defines whether or not the corresponding UI component items is selected.
  
   */
  get selectedExpr() {
    return this._getOption("selectedExpr");
  }
  set selectedExpr(value) {
    this._setOption("selectedExpr", value);
  }
  /**
   * The selected item object.
  
   */
  get selectedItem() {
    return this._getOption("selectedItem");
  }
  set selectedItem(value) {
    this._setOption("selectedItem", value);
  }
  /**
   * Specifies the selection mode supported by the menu.
  
   */
  get selectionMode() {
    return this._getOption("selectionMode");
  }
  set selectionMode(value) {
    this._setOption("selectionMode", value);
  }
  /**
   * Specifies properties for displaying the UI component.
  
   */
  get showEvent() {
    return this._getOption("showEvent");
  }
  set showEvent(value) {
    this._setOption("showEvent", value);
  }
  /**
   * Specifies properties of submenu showing and hiding.
  
   */
  get showSubmenuMode() {
    return this._getOption("showSubmenuMode");
  }
  set showSubmenuMode(value) {
    this._setOption("showSubmenuMode", value);
  }
  /**
   * Specifies the direction at which submenus are displayed.
  
   */
  get submenuDirection() {
    return this._getOption("submenuDirection");
  }
  set submenuDirection(value) {
    this._setOption("submenuDirection", value);
  }
  /**
   * Specifies the number of the element when the Tab key is used for navigating.
  
   */
  get tabIndex() {
    return this._getOption("tabIndex");
  }
  set tabIndex(value) {
    this._setOption("tabIndex", value);
  }
  /**
   * The target element associated with the context menu.
  
   */
  get target() {
    return this._getOption("target");
  }
  set target(value) {
    this._setOption("target", value);
  }
  /**
   * A Boolean value specifying whether or not the UI component is visible.
  
   */
  get visible() {
    return this._getOption("visible");
  }
  set visible(value) {
    this._setOption("visible", value);
  }
  /**
   * Specifies the UI component&apos;s width.
  
   */
  get width() {
    return this._getOption("width");
  }
  set width(value) {
    this._setOption("width", value);
  }
  /**
  
   * A function that is executed when the UI component is rendered and each time the component is repainted.
  
  
   */
  onContentReady;
  /**
  
   * A function that is executed before the UI component is disposed of.
  
  
   */
  onDisposing;
  /**
  
   * A function that is executed after the ContextMenu is hidden.
  
  
   */
  onHidden;
  /**
  
   * A function that is executed before the ContextMenu is hidden.
  
  
   */
  onHiding;
  /**
  
   * A function used in JavaScript frameworks to save the UI component instance.
  
  
   */
  onInitialized;
  /**
  
   * A function that is executed when a collection item is clicked or tapped.
  
  
   */
  onItemClick;
  /**
  
   * A function that is executed when a collection item is right-clicked or pressed.
  
  
   */
  onItemContextMenu;
  /**
  
   * A function that is executed after a collection item is rendered.
  
  
   */
  onItemRendered;
  /**
  
   * A function that is executed after a UI component property is changed.
  
  
   */
  onOptionChanged;
  /**
  
   * A function that is executed before the ContextMenu is positioned.
  
  
   */
  onPositioning;
  /**
  
   * A function that is executed when a collection item is selected or selection is canceled.
  
  
   */
  onSelectionChanged;
  /**
  
   * A function that is executed before the ContextMenu is shown.
  
  
   */
  onShowing;
  /**
  
   * A function that is executed after the ContextMenu is shown.
  
  
   */
  onShown;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  accessKeyChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  activeStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  animationChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  closeOnOutsideClickChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  cssClassChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  dataSourceChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  disabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  disabledExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  displayExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  elementAttrChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  focusStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  heightChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hideOnOutsideClickChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hintChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hoverStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemsExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemTemplateChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  positionChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  rtlEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectByClickChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectedExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectedItemChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectionModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  showEventChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  showSubmenuModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  submenuDirectionChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  tabIndexChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  targetChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  visibleChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  widthChange;
  get itemsChildren() {
    return this._getOption("items");
  }
  set itemsChildren(value) {
    this.setChildren("items", value);
  }
  constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
    super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
    this._watcherHelper = _watcherHelper;
    this._idh = _idh;
    this._createEventEmitters([{
      subscribe: "contentReady",
      emit: "onContentReady"
    }, {
      subscribe: "disposing",
      emit: "onDisposing"
    }, {
      subscribe: "hidden",
      emit: "onHidden"
    }, {
      subscribe: "hiding",
      emit: "onHiding"
    }, {
      subscribe: "initialized",
      emit: "onInitialized"
    }, {
      subscribe: "itemClick",
      emit: "onItemClick"
    }, {
      subscribe: "itemContextMenu",
      emit: "onItemContextMenu"
    }, {
      subscribe: "itemRendered",
      emit: "onItemRendered"
    }, {
      subscribe: "optionChanged",
      emit: "onOptionChanged"
    }, {
      subscribe: "positioning",
      emit: "onPositioning"
    }, {
      subscribe: "selectionChanged",
      emit: "onSelectionChanged"
    }, {
      subscribe: "showing",
      emit: "onShowing"
    }, {
      subscribe: "shown",
      emit: "onShown"
    }, {
      emit: "accessKeyChange"
    }, {
      emit: "activeStateEnabledChange"
    }, {
      emit: "animationChange"
    }, {
      emit: "closeOnOutsideClickChange"
    }, {
      emit: "cssClassChange"
    }, {
      emit: "dataSourceChange"
    }, {
      emit: "disabledChange"
    }, {
      emit: "disabledExprChange"
    }, {
      emit: "displayExprChange"
    }, {
      emit: "elementAttrChange"
    }, {
      emit: "focusStateEnabledChange"
    }, {
      emit: "heightChange"
    }, {
      emit: "hideOnOutsideClickChange"
    }, {
      emit: "hintChange"
    }, {
      emit: "hoverStateEnabledChange"
    }, {
      emit: "itemsChange"
    }, {
      emit: "itemsExprChange"
    }, {
      emit: "itemTemplateChange"
    }, {
      emit: "positionChange"
    }, {
      emit: "rtlEnabledChange"
    }, {
      emit: "selectByClickChange"
    }, {
      emit: "selectedExprChange"
    }, {
      emit: "selectedItemChange"
    }, {
      emit: "selectionModeChange"
    }, {
      emit: "showEventChange"
    }, {
      emit: "showSubmenuModeChange"
    }, {
      emit: "submenuDirectionChange"
    }, {
      emit: "tabIndexChange"
    }, {
      emit: "targetChange"
    }, {
      emit: "visibleChange"
    }, {
      emit: "widthChange"
    }]);
    this._idh.setHost(this);
    optionHost.setHost(this);
  }
  _createInstance(element, options) {
    return new context_menu_default(element, options);
  }
  ngOnDestroy() {
    this._destroyWidget();
  }
  ngOnChanges(changes) {
    super.ngOnChanges(changes);
    this.setupChanges("dataSource", changes);
    this.setupChanges("items", changes);
  }
  setupChanges(prop, changes) {
    if (!(prop in this._optionsToUpdate)) {
      this._idh.setup(prop, changes);
    }
  }
  ngDoCheck() {
    this._idh.doCheck("dataSource");
    this._idh.doCheck("items");
    this._watcherHelper.checkWatchers();
    super.ngDoCheck();
    super.clearChangedOptions();
  }
  _setOption(name2, value) {
    let isSetup = this._idh.setupSingle(name2, value);
    let isChanged = this._idh.getChanges(name2, value) !== null;
    if (isSetup || isChanged) {
      super._setOption(name2, value);
    }
  }
  /** @nocollapse */
  static ɵfac = function DxContextMenuComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxContextMenuComponent)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(DxTemplateHost), ɵɵdirectiveInject(WatcherHelper), ɵɵdirectiveInject(IterableDifferHelper), ɵɵdirectiveInject(NestedOptionHost), ɵɵdirectiveInject(TransferState), ɵɵdirectiveInject(PLATFORM_ID));
  };
  /** @nocollapse */
  static ɵcmp = ɵɵdefineComponent({
    type: _DxContextMenuComponent,
    selectors: [["dx-context-menu"]],
    contentQueries: function DxContextMenuComponent_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuery(dirIndex, DxiItemComponent, 4);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.itemsChildren = _t);
      }
    },
    inputs: {
      accessKey: "accessKey",
      activeStateEnabled: "activeStateEnabled",
      animation: "animation",
      closeOnOutsideClick: "closeOnOutsideClick",
      cssClass: "cssClass",
      dataSource: "dataSource",
      disabled: "disabled",
      disabledExpr: "disabledExpr",
      displayExpr: "displayExpr",
      elementAttr: "elementAttr",
      focusStateEnabled: "focusStateEnabled",
      height: "height",
      hideOnOutsideClick: "hideOnOutsideClick",
      hint: "hint",
      hoverStateEnabled: "hoverStateEnabled",
      items: "items",
      itemsExpr: "itemsExpr",
      itemTemplate: "itemTemplate",
      position: "position",
      rtlEnabled: "rtlEnabled",
      selectByClick: "selectByClick",
      selectedExpr: "selectedExpr",
      selectedItem: "selectedItem",
      selectionMode: "selectionMode",
      showEvent: "showEvent",
      showSubmenuMode: "showSubmenuMode",
      submenuDirection: "submenuDirection",
      tabIndex: "tabIndex",
      target: "target",
      visible: "visible",
      width: "width"
    },
    outputs: {
      onContentReady: "onContentReady",
      onDisposing: "onDisposing",
      onHidden: "onHidden",
      onHiding: "onHiding",
      onInitialized: "onInitialized",
      onItemClick: "onItemClick",
      onItemContextMenu: "onItemContextMenu",
      onItemRendered: "onItemRendered",
      onOptionChanged: "onOptionChanged",
      onPositioning: "onPositioning",
      onSelectionChanged: "onSelectionChanged",
      onShowing: "onShowing",
      onShown: "onShown",
      accessKeyChange: "accessKeyChange",
      activeStateEnabledChange: "activeStateEnabledChange",
      animationChange: "animationChange",
      closeOnOutsideClickChange: "closeOnOutsideClickChange",
      cssClassChange: "cssClassChange",
      dataSourceChange: "dataSourceChange",
      disabledChange: "disabledChange",
      disabledExprChange: "disabledExprChange",
      displayExprChange: "displayExprChange",
      elementAttrChange: "elementAttrChange",
      focusStateEnabledChange: "focusStateEnabledChange",
      heightChange: "heightChange",
      hideOnOutsideClickChange: "hideOnOutsideClickChange",
      hintChange: "hintChange",
      hoverStateEnabledChange: "hoverStateEnabledChange",
      itemsChange: "itemsChange",
      itemsExprChange: "itemsExprChange",
      itemTemplateChange: "itemTemplateChange",
      positionChange: "positionChange",
      rtlEnabledChange: "rtlEnabledChange",
      selectByClickChange: "selectByClickChange",
      selectedExprChange: "selectedExprChange",
      selectedItemChange: "selectedItemChange",
      selectionModeChange: "selectionModeChange",
      showEventChange: "showEventChange",
      showSubmenuModeChange: "showSubmenuModeChange",
      submenuDirectionChange: "submenuDirectionChange",
      tabIndexChange: "tabIndexChange",
      targetChange: "targetChange",
      visibleChange: "visibleChange",
      widthChange: "widthChange"
    },
    features: [ɵɵProvidersFeature([DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]), ɵɵInheritDefinitionFeature, ɵɵNgOnChangesFeature],
    decls: 0,
    vars: 0,
    template: function DxContextMenuComponent_Template(rf, ctx) {
    },
    encapsulation: 2
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxContextMenuComponent, [{
    type: Component,
    args: [{
      selector: "dx-context-menu",
      template: "",
      providers: [DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: NgZone
    }, {
      type: DxTemplateHost
    }, {
      type: WatcherHelper
    }, {
      type: IterableDifferHelper
    }, {
      type: NestedOptionHost
    }, {
      type: TransferState
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }];
  }, {
    accessKey: [{
      type: Input
    }],
    activeStateEnabled: [{
      type: Input
    }],
    animation: [{
      type: Input
    }],
    closeOnOutsideClick: [{
      type: Input
    }],
    cssClass: [{
      type: Input
    }],
    dataSource: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    disabledExpr: [{
      type: Input
    }],
    displayExpr: [{
      type: Input
    }],
    elementAttr: [{
      type: Input
    }],
    focusStateEnabled: [{
      type: Input
    }],
    height: [{
      type: Input
    }],
    hideOnOutsideClick: [{
      type: Input
    }],
    hint: [{
      type: Input
    }],
    hoverStateEnabled: [{
      type: Input
    }],
    items: [{
      type: Input
    }],
    itemsExpr: [{
      type: Input
    }],
    itemTemplate: [{
      type: Input
    }],
    position: [{
      type: Input
    }],
    rtlEnabled: [{
      type: Input
    }],
    selectByClick: [{
      type: Input
    }],
    selectedExpr: [{
      type: Input
    }],
    selectedItem: [{
      type: Input
    }],
    selectionMode: [{
      type: Input
    }],
    showEvent: [{
      type: Input
    }],
    showSubmenuMode: [{
      type: Input
    }],
    submenuDirection: [{
      type: Input
    }],
    tabIndex: [{
      type: Input
    }],
    target: [{
      type: Input
    }],
    visible: [{
      type: Input
    }],
    width: [{
      type: Input
    }],
    onContentReady: [{
      type: Output
    }],
    onDisposing: [{
      type: Output
    }],
    onHidden: [{
      type: Output
    }],
    onHiding: [{
      type: Output
    }],
    onInitialized: [{
      type: Output
    }],
    onItemClick: [{
      type: Output
    }],
    onItemContextMenu: [{
      type: Output
    }],
    onItemRendered: [{
      type: Output
    }],
    onOptionChanged: [{
      type: Output
    }],
    onPositioning: [{
      type: Output
    }],
    onSelectionChanged: [{
      type: Output
    }],
    onShowing: [{
      type: Output
    }],
    onShown: [{
      type: Output
    }],
    accessKeyChange: [{
      type: Output
    }],
    activeStateEnabledChange: [{
      type: Output
    }],
    animationChange: [{
      type: Output
    }],
    closeOnOutsideClickChange: [{
      type: Output
    }],
    cssClassChange: [{
      type: Output
    }],
    dataSourceChange: [{
      type: Output
    }],
    disabledChange: [{
      type: Output
    }],
    disabledExprChange: [{
      type: Output
    }],
    displayExprChange: [{
      type: Output
    }],
    elementAttrChange: [{
      type: Output
    }],
    focusStateEnabledChange: [{
      type: Output
    }],
    heightChange: [{
      type: Output
    }],
    hideOnOutsideClickChange: [{
      type: Output
    }],
    hintChange: [{
      type: Output
    }],
    hoverStateEnabledChange: [{
      type: Output
    }],
    itemsChange: [{
      type: Output
    }],
    itemsExprChange: [{
      type: Output
    }],
    itemTemplateChange: [{
      type: Output
    }],
    positionChange: [{
      type: Output
    }],
    rtlEnabledChange: [{
      type: Output
    }],
    selectByClickChange: [{
      type: Output
    }],
    selectedExprChange: [{
      type: Output
    }],
    selectedItemChange: [{
      type: Output
    }],
    selectionModeChange: [{
      type: Output
    }],
    showEventChange: [{
      type: Output
    }],
    showSubmenuModeChange: [{
      type: Output
    }],
    submenuDirectionChange: [{
      type: Output
    }],
    tabIndexChange: [{
      type: Output
    }],
    targetChange: [{
      type: Output
    }],
    visibleChange: [{
      type: Output
    }],
    widthChange: [{
      type: Output
    }],
    itemsChildren: [{
      type: ContentChildren,
      args: [DxiItemComponent]
    }]
  });
})();
var DxContextMenuModule = class _DxContextMenuModule {
  /** @nocollapse */
  static ɵfac = function DxContextMenuModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxContextMenuModule)();
  };
  /** @nocollapse */
  static ɵmod = ɵɵdefineNgModule({
    type: _DxContextMenuModule,
    declarations: [DxContextMenuComponent],
    imports: [DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule, DxoShowEventModule, DxoShowSubmenuModeModule, DxoDelayModule, DxIntegrationModule, DxTemplateModule],
    exports: [DxContextMenuComponent, DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule, DxoShowEventModule, DxoShowSubmenuModeModule, DxoDelayModule, DxTemplateModule]
  });
  /** @nocollapse */
  static ɵinj = ɵɵdefineInjector({
    imports: [DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule, DxoShowEventModule, DxoShowSubmenuModeModule, DxoDelayModule, DxIntegrationModule, DxTemplateModule, DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule, DxoShowEventModule, DxoShowSubmenuModeModule, DxoDelayModule, DxTemplateModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxContextMenuModule, [{
    type: NgModule,
    args: [{
      imports: [DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule, DxoShowEventModule, DxoShowSubmenuModeModule, DxoDelayModule, DxIntegrationModule, DxTemplateModule],
      declarations: [DxContextMenuComponent],
      exports: [DxContextMenuComponent, DxoAnimationModule, DxoHideModule, DxoFromModule, DxoPositionModule, DxoAtModule, DxoBoundaryOffsetModule, DxoCollisionModule, DxoMyModule, DxoOffsetModule, DxoToModule, DxoShowModule, DxiItemModule, DxoShowEventModule, DxoShowSubmenuModeModule, DxoDelayModule, DxTemplateModule]
    }]
  }], null, null);
})();

export {
  m_menu_base_default,
  m_context_menu_default,
  context_menu_default,
  DxContextMenuComponent,
  DxContextMenuModule
};
/*! Bundled license information:

devextreme-angular/fesm2022/devextreme-angular-ui-context-menu.mjs:
  (*!
   * devextreme-angular
   * Version: 24.1.4
   * Build date: Mon Jul 15 2024
   *
   * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
   *
   * This software may be modified and distributed under the terms
   * of the MIT license. See the LICENSE file in the root of the project for details.
   *
   * https://github.com/DevExpress/devextreme-angular
   *)
*/
//# sourceMappingURL=chunk-FJ3U3IHZ.js.map
