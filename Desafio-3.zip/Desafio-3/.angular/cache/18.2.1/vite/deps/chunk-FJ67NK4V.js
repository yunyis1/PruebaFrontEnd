import {
  check_box_default
} from "./chunk-X7C6WMP5.js";
import {
  ListBase,
  SWIPE_END_EVENT,
  SWIPE_EVENT,
  SWIPE_START_EVENT
} from "./chunk-7MX4NZCL.js";
import {
  editor_default,
  ui_search_box_mixin_default
} from "./chunk-T7YQMDRE.js";
import {
  m_collection_widget_edit_strategy_plain_default
} from "./chunk-7WJHXR3Y.js";
import {
  query_default,
  store_helper_default
} from "./chunk-NB6G4GLF.js";
import {
  message_default
} from "./chunk-CSW63CAV.js";
import {
  CLICK_EVENT_NAME,
  addNamespace,
  component_registrator_default,
  isTouchEvent
} from "./chunk-X73RLF6Y.js";
import {
  devices_default,
  ui_errors_default
} from "./chunk-25VDHZLA.js";
import {
  getWidth,
  renderer_default
} from "./chunk-M4HNHSVV.js";
import {
  events_engine_default
} from "./chunk-PJXMQ5JC.js";
import {
  class_default,
  each,
  extend,
  isNumeric,
  noop
} from "./chunk-V6EUNM2D.js";

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator_registry.js
var registry = {};
function register(option, type, decoratorClass) {
  const decoratorsRegistry = registry;
  const decoratorConfig = {};
  decoratorConfig[option] = decoratorsRegistry[option] ? decoratorsRegistry[option] : {};
  decoratorConfig[option][type] = decoratorClass;
  extend(decoratorsRegistry, decoratorConfig);
}

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.provider.js
var editOptionsRegistry = [];
var registerOption = function(enabledFunc, decoratorTypeFunc, decoratorSubTypeFunc) {
  editOptionsRegistry.push({
    enabled: enabledFunc,
    decoratorType: decoratorTypeFunc,
    decoratorSubType: decoratorSubTypeFunc
  });
};
registerOption(function() {
  return this.option("menuItems").length;
}, () => "menu", function() {
  return this.option("menuMode");
});
registerOption(function() {
  return !this.option("menuItems").length && this.option("allowItemDeleting");
}, function() {
  const mode = this.option("itemDeleteMode");
  return "toggle" === mode || "slideButton" === mode || "swipe" === mode || "static" === mode ? "delete" : "menu";
}, function() {
  let mode = this.option("itemDeleteMode");
  if ("slideItem" === mode) {
    mode = "slide";
  }
  return mode;
});
registerOption(function() {
  return "none" !== this.option("selectionMode") && this.option("showSelectionControls");
}, () => "selection", () => "default");
registerOption(function() {
  return this.option("itemDragging.allowReordering") || this.option("itemDragging.allowDropInsideItem") || this.option("itemDragging.group");
}, () => "reorder", () => "default");
var EditProvider = class_default.inherit({
  ctor(list) {
    this._list = list;
    this._fetchRequiredDecorators();
  },
  dispose() {
    if (this._decorators && this._decorators.length) {
      each(this._decorators, (_, decorator) => {
        decorator.dispose();
      });
    }
  },
  _fetchRequiredDecorators() {
    this._decorators = [];
    each(editOptionsRegistry, (_, option) => {
      const optionEnabled = option.enabled.call(this._list);
      if (optionEnabled) {
        const decoratorType = option.decoratorType.call(this._list);
        const decoratorSubType = option.decoratorSubType.call(this._list);
        const decorator = this._createDecorator(decoratorType, decoratorSubType);
        this._decorators.push(decorator);
      }
    });
  },
  _createDecorator(type, subType) {
    const decoratorClass = this._findDecorator(type, subType);
    return new decoratorClass(this._list);
  },
  _findDecorator(type, subType) {
    var _registry$type;
    const foundDecorator = null === (_registry$type = registry[type]) || void 0 === _registry$type ? void 0 : _registry$type[subType];
    if (!foundDecorator) {
      throw ui_errors_default.Error("E1012", type, subType);
    }
    return foundDecorator;
  },
  modifyItemElement(args) {
    const $itemElement = renderer_default(args.itemElement);
    const config = {
      $itemElement
    };
    this._prependBeforeBags($itemElement, config);
    this._appendAfterBags($itemElement, config);
    this._applyDecorators("modifyElement", config);
  },
  afterItemsRendered() {
    this._applyDecorators("afterRender");
  },
  _prependBeforeBags($itemElement, config) {
    const $beforeBags = this._collectDecoratorsMarkup("beforeBag", config, "dx-list-item-before-bag");
    $itemElement.prepend($beforeBags);
  },
  _appendAfterBags($itemElement, config) {
    const $afterBags = this._collectDecoratorsMarkup("afterBag", config, "dx-list-item-after-bag");
    $itemElement.append($afterBags);
  },
  _collectDecoratorsMarkup(method, config, containerClass) {
    const $collector = renderer_default("<div>");
    each(this._decorators, function() {
      const $container = renderer_default("<div>").addClass(containerClass);
      this[method](extend({
        $container
      }, config));
      if ($container.children().length) {
        $collector.append($container);
      }
    });
    return $collector.children();
  },
  _applyDecorators(method, config) {
    each(this._decorators, function() {
      this[method](config);
    });
  },
  _handlerExists(name) {
    if (!this._decorators) {
      return false;
    }
    const decorators = this._decorators;
    const {
      length
    } = decorators;
    for (let i = 0; i < length; i++) {
      if (decorators[i][name] !== noop) {
        return true;
      }
    }
    return false;
  },
  _eventHandler(name, $itemElement, e) {
    if (!this._decorators) {
      return false;
    }
    let response = false;
    const decorators = this._decorators;
    const {
      length
    } = decorators;
    for (let i = 0; i < length; i++) {
      response = decorators[i][name]($itemElement, e);
      if (response) {
        break;
      }
    }
    return response;
  },
  handleClick($itemElement, e) {
    return this._eventHandler("handleClick", $itemElement, e);
  },
  handleKeyboardEvents(currentFocusedIndex, moveFocusUp) {
    return this._eventHandler("handleKeyboardEvents", currentFocusedIndex, moveFocusUp);
  },
  handleEnterPressing(e) {
    return this._eventHandler("handleEnterPressing", e);
  },
  contextMenuHandlerExists() {
    return this._handlerExists("handleContextMenu");
  },
  handleContextMenu($itemElement, e) {
    return this._eventHandler("handleContextMenu", $itemElement, e);
  },
  getExcludedItemSelectors() {
    const excludedSelectors = [];
    this._applyDecorators("getExcludedSelectors", excludedSelectors);
    return excludedSelectors.join(",");
  }
});
var m_list_edit_provider_default = EditProvider;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.strategy.grouped.js
var combineIndex = function(indices) {
  return (indices.group << 20) + indices.item;
};
var splitIndex = function(combinedIndex) {
  return {
    group: combinedIndex >> 20,
    item: 1048575 & combinedIndex
  };
};
var GroupedEditStrategy = m_collection_widget_edit_strategy_plain_default.inherit({
  _groupElements() {
    return this._collectionWidget._itemContainer().find(".dx-list-group");
  },
  _groupItemElements: ($group) => $group.find(".dx-list-item"),
  getIndexByItemData(itemData) {
    const groups = this._collectionWidget.option("items");
    let index = false;
    if (!itemData) {
      return false;
    }
    if (itemData.items && itemData.items.length) {
      itemData = itemData.items[0];
    }
    each(groups, (groupIndex, group) => {
      if (!group.items) {
        return false;
      }
      each(group.items, (itemIndex, item) => {
        if (item !== itemData) {
          return true;
        }
        index = {
          group: groupIndex,
          item: itemIndex
        };
        return false;
      });
      if (index) {
        return false;
      }
    });
    return index;
  },
  getItemDataByIndex(index) {
    const items = this._collectionWidget.option("items");
    if (isNumeric(index)) {
      return this.itemsGetter()[index];
    }
    return index && items[index.group] && items[index.group].items[index.item] || null;
  },
  itemsGetter() {
    let resultItems = [];
    const items = this._collectionWidget.option("items");
    for (let i = 0; i < items.length; i++) {
      if (items[i] && items[i].items) {
        resultItems = resultItems.concat(items[i].items);
      } else {
        resultItems.push(items[i]);
      }
    }
    return resultItems;
  },
  deleteItemAtIndex(index) {
    const indices = splitIndex(index);
    const itemGroup = this._collectionWidget.option("items")[indices.group].items;
    itemGroup.splice(indices.item, 1);
  },
  getKeysByItems(items) {
    let plainItems = [];
    let i;
    for (i = 0; i < items.length; i++) {
      if (items[i] && items[i].items) {
        plainItems = plainItems.concat(items[i].items);
      } else {
        plainItems.push(items[i]);
      }
    }
    const result = [];
    for (i = 0; i < plainItems.length; i++) {
      result.push(this._collectionWidget.keyOf(plainItems[i]));
    }
    return result;
  },
  getIndexByKey(key, items) {
    const groups = items || this._collectionWidget.option("items");
    let index = -1;
    const that = this;
    each(groups, (groupIndex, group) => {
      if (!group.items) {
        return;
      }
      each(group.items, (itemIndex, item) => {
        const itemKey = that._collectionWidget.keyOf(item);
        if (that._equalKeys(itemKey, key)) {
          index = {
            group: groupIndex,
            item: itemIndex
          };
          return false;
        }
      });
      if (-1 !== index) {
        return false;
      }
    });
    return index;
  },
  _getGroups(items) {
    const dataController = this._collectionWidget._dataController;
    const group = dataController.group();
    if (group) {
      return store_helper_default.queryByOptions(query_default(items), {
        group
      }).toArray();
    }
    return this._collectionWidget.option("items");
  },
  getItemsByKeys(keys, items) {
    const result = [];
    const groups = this._getGroups(items);
    const groupItemByKeyMap = {};
    const getItemMeta = (key) => {
      const index = this.getIndexByKey(key, groups);
      const group = index && groups[index.group];
      if (!group) {
        return;
      }
      return {
        groupKey: group.key,
        item: group.items[index.item]
      };
    };
    each(keys, (_, key) => {
      const itemMeta = getItemMeta(key);
      if (!itemMeta) {
        return;
      }
      const {
        groupKey
      } = itemMeta;
      const {
        item
      } = itemMeta;
      let selectedGroup = groupItemByKeyMap[groupKey];
      if (!selectedGroup) {
        selectedGroup = {
          key: groupKey,
          items: []
        };
        groupItemByKeyMap[groupKey] = selectedGroup;
        result.push(selectedGroup);
      }
      selectedGroup.items.push(item);
    });
    return result;
  },
  moveItemAtIndexToIndex(movingIndex, destinationIndex) {
    const items = this._collectionWidget.option("items");
    const movingIndices = splitIndex(movingIndex);
    const destinationIndices = splitIndex(destinationIndex);
    const movingItemGroup = items[movingIndices.group].items;
    const destinationItemGroup = items[destinationIndices.group].items;
    const movedItemData = movingItemGroup[movingIndices.item];
    movingItemGroup.splice(movingIndices.item, 1);
    destinationItemGroup.splice(destinationIndices.item, 0, movedItemData);
  },
  _isItemIndex: (index) => index && isNumeric(index.group) && isNumeric(index.item),
  _getNormalizedItemIndex(itemElement) {
    const $item = renderer_default(itemElement);
    const $group = $item.closest(".dx-list-group");
    if (!$group.length) {
      return -1;
    }
    return combineIndex({
      group: this._groupElements().index($group),
      item: this._groupItemElements($group).index($item)
    });
  },
  _normalizeItemIndex: (index) => combineIndex(index),
  _denormalizeItemIndex: (index) => splitIndex(index),
  _getItemByNormalizedIndex(index) {
    const indices = splitIndex(index);
    const $group = this._groupElements().eq(indices.group);
    return this._groupItemElements($group).eq(indices.item);
  },
  _itemsFromSameParent: (firstIndex, secondIndex) => splitIndex(firstIndex).group === splitIndex(secondIndex).group
});
var m_list_edit_strategy_grouped_default = GroupedEditStrategy;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.js
var ListEdit = ListBase.inherit({
  _supportedKeys() {
    const that = this;
    const parent = this.callBase();
    const moveFocusedItem = (e, moveUp) => {
      const editStrategy = this._editStrategy;
      const focusedElement = this.option("focusedElement");
      const focusedItemIndex = editStrategy.getNormalizedIndex(focusedElement);
      const isLastIndexFocused = focusedItemIndex === this._getLastItemIndex();
      if (isLastIndexFocused && this._dataController.isLoading()) {
        return;
      }
      if (e.shiftKey && that.option("itemDragging.allowReordering")) {
        const nextItemIndex = focusedItemIndex + (moveUp ? -1 : 1);
        const $nextItem = editStrategy.getItemElement(nextItemIndex);
        this.reorderItem(focusedElement, $nextItem);
        this.scrollToItem(focusedElement);
        e.preventDefault();
      } else {
        const editProvider = this._editProvider;
        const isInternalMoving = editProvider.handleKeyboardEvents(focusedItemIndex, moveUp);
        if (!isInternalMoving) {
          moveUp ? parent.upArrow(e) : parent.downArrow(e);
        }
      }
    };
    return extend({}, parent, {
      del: (e) => {
        if (that.option("allowItemDeleting")) {
          e.preventDefault();
          that.deleteItem(that.option("focusedElement"));
        }
      },
      upArrow: (e) => moveFocusedItem(e, true),
      downArrow: (e) => moveFocusedItem(e),
      enter: function(e) {
        if (!this._editProvider.handleEnterPressing(e)) {
          parent.enter.apply(this, arguments);
        }
      },
      space: function(e) {
        if (!this._editProvider.handleEnterPressing(e)) {
          parent.space.apply(this, arguments);
        }
      }
    });
  },
  _updateSelection() {
    this._editProvider.afterItemsRendered();
    this.callBase();
  },
  _getLastItemIndex() {
    return this._itemElements().length - 1;
  },
  _refreshItemElements() {
    this.callBase();
    const excludedSelectors = this._editProvider.getExcludedItemSelectors();
    if (excludedSelectors.length) {
      this._itemElementsCache = this._itemElementsCache.not(excludedSelectors);
    }
  },
  _isItemStrictEquals(item1, item2) {
    const privateKey = item1 && item1.__dx_key__;
    if (privateKey && !this.key() && this._selection.isItemSelected(privateKey)) {
      return false;
    }
    return this.callBase(item1, item2);
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      showSelectionControls: false,
      selectionMode: "none",
      selectAllMode: "page",
      onSelectAllValueChanged: null,
      selectAllText: message_default.format("dxList-selectAll"),
      menuItems: [],
      menuMode: "context",
      allowItemDeleting: false,
      itemDeleteMode: "static",
      itemDragging: {}
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: (device) => "ios" === device.platform,
      options: {
        menuMode: "slide",
        itemDeleteMode: "slideItem"
      }
    }, {
      device: {
        platform: "android"
      },
      options: {
        itemDeleteMode: "swipe"
      }
    }]);
  },
  _init() {
    this.callBase();
    this._initEditProvider();
  },
  _initDataSource() {
    this.callBase();
    if (!this._isPageSelectAll()) {
      this._dataSource && this._dataSource.requireTotalCount(true);
    }
  },
  _isPageSelectAll() {
    return "page" === this.option("selectAllMode");
  },
  _initEditProvider() {
    this._editProvider = new m_list_edit_provider_default(this);
  },
  _disposeEditProvider() {
    if (this._editProvider) {
      this._editProvider.dispose();
    }
  },
  _refreshEditProvider() {
    this._disposeEditProvider();
    this._initEditProvider();
  },
  _initEditStrategy() {
    if (this.option("grouped")) {
      this._editStrategy = new m_list_edit_strategy_grouped_default(this);
    } else {
      this.callBase();
    }
  },
  _initMarkup() {
    this._refreshEditProvider();
    this.callBase();
  },
  _renderItems() {
    this.callBase(...arguments);
    this._editProvider.afterItemsRendered();
  },
  _selectedItemClass: () => "dx-list-item-selected",
  _itemResponseWaitClass: () => "dx-list-item-response-wait",
  _itemClickHandler(e) {
    const $itemElement = renderer_default(e.currentTarget);
    if ($itemElement.is(".dx-state-disabled, .dx-state-disabled *")) {
      return;
    }
    const handledByEditProvider = this._editProvider.handleClick($itemElement, e);
    if (handledByEditProvider) {
      return;
    }
    this._saveSelectionChangeEvent(e);
    this.callBase(...arguments);
  },
  _shouldFireContextMenuEvent() {
    return this.callBase(...arguments) || this._editProvider.contextMenuHandlerExists();
  },
  _itemHoldHandler(e) {
    const $itemElement = renderer_default(e.currentTarget);
    if ($itemElement.is(".dx-state-disabled, .dx-state-disabled *")) {
      return;
    }
    const handledByEditProvider = isTouchEvent(e) && this._editProvider.handleContextMenu($itemElement, e);
    if (handledByEditProvider) {
      e.handledByEditProvider = true;
      return;
    }
    this.callBase(...arguments);
  },
  _getItemContainer(changeData) {
    if (this.option("grouped")) {
      var _this$_editStrategy$g;
      const groupIndex = null === (_this$_editStrategy$g = this._editStrategy.getIndexByItemData(changeData)) || void 0 === _this$_editStrategy$g ? void 0 : _this$_editStrategy$g.group;
      return this._getGroupContainerByIndex(groupIndex);
    }
    return this.callBase(changeData);
  },
  _itemContextMenuHandler(e) {
    const $itemElement = renderer_default(e.currentTarget);
    if ($itemElement.is(".dx-state-disabled, .dx-state-disabled *")) {
      return;
    }
    const handledByEditProvider = !e.handledByEditProvider && this._editProvider.handleContextMenu($itemElement, e);
    if (handledByEditProvider) {
      e.preventDefault();
      return;
    }
    this.callBase(...arguments);
  },
  _postprocessRenderItem(args) {
    this.callBase(...arguments);
    this._editProvider.modifyItemElement(args);
  },
  _clean() {
    this._disposeEditProvider();
    this.callBase();
  },
  focusListItem(index) {
    const $item = this._editStrategy.getItemElement(index);
    this.option("focusedElement", $item);
    this.focus();
    this.scrollToItem(this.option("focusedElement"));
  },
  _optionChanged(args) {
    switch (args.name) {
      case "selectAllMode":
        this._initDataSource();
        this._dataController.pageIndex(0);
        this._dataController.load();
        break;
      case "grouped":
        this._clearSelectedItems();
        delete this._renderingGroupIndex;
        this._initEditStrategy();
        this.callBase(args);
        break;
      case "showSelectionControls":
      case "menuItems":
      case "menuMode":
      case "allowItemDeleting":
      case "itemDeleteMode":
      case "itemDragging":
      case "selectAllText":
        this._invalidate();
        break;
      case "onSelectAllValueChanged":
        break;
      default:
        this.callBase(args);
    }
  },
  selectAll() {
    return this._selection.selectAll(this._isPageSelectAll());
  },
  unselectAll() {
    return this._selection.deselectAll(this._isPageSelectAll());
  },
  isSelectAll() {
    return this._selection.getSelectAllState(this._isPageSelectAll());
  },
  getFlatIndexByItemElement(itemElement) {
    return this._itemElements().index(itemElement);
  },
  getItemElementByFlatIndex(flatIndex) {
    const $itemElements = this._itemElements();
    if (flatIndex < 0 || flatIndex >= $itemElements.length) {
      return renderer_default();
    }
    return $itemElements.eq(flatIndex);
  },
  getItemByIndex(index) {
    return this._editStrategy.getItemDataByIndex(index);
  },
  deleteItem(itemElement) {
    const editStrategy = this._editStrategy;
    const deletingElementIndex = editStrategy.getNormalizedIndex(itemElement);
    const focusedElement = this.option("focusedElement");
    const focusStateEnabled = this.option("focusStateEnabled");
    const focusedItemIndex = focusedElement ? editStrategy.getNormalizedIndex(focusedElement) : deletingElementIndex;
    const isLastIndexFocused = focusedItemIndex === this._getLastItemIndex();
    const nextFocusedItem = isLastIndexFocused || deletingElementIndex < focusedItemIndex ? focusedItemIndex - 1 : focusedItemIndex;
    const promise = this.callBase(itemElement);
    return promise.done(function() {
      if (focusStateEnabled) {
        this.focusListItem(nextFocusedItem);
      }
    });
  }
});
var m_list_edit_default = ListEdit;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.search.js
var ListSearch = m_list_edit_default.inherit(ui_search_box_mixin_default).inherit({
  _addWidgetPrefix: (className) => `dx-list-${className}`,
  _getCombinedFilter() {
    const dataController = this._dataController;
    const storeLoadOptions = {
      filter: dataController.filter()
    };
    dataController.addSearchFilter(storeLoadOptions);
    const {
      filter
    } = storeLoadOptions;
    return filter;
  },
  _initDataSource() {
    const value = this.option("searchValue");
    const expr = this.option("searchExpr");
    const mode = this.option("searchMode");
    this.callBase();
    const dataController = this._dataController;
    value && value.length && dataController.searchValue(value);
    mode.length && dataController.searchOperation(ui_search_box_mixin_default.getOperationBySearchMode(mode));
    expr && dataController.searchExpr(expr);
  }
});
var m_list_edit_search_default = ListSearch;

// node_modules/devextreme/esm/ui/list_light.js
component_registrator_default("dxList", m_list_edit_search_default);
var list_light_default = m_list_edit_search_default;

// node_modules/devextreme/esm/__internal/ui/radio_group/m_radio_button.js
var RadioButton = editor_default.inherit({
  _supportedKeys() {
    return extend(this.callBase(), {
      space: function(e) {
        e.preventDefault();
        this._clickAction({
          event: e
        });
      }
    });
  },
  _getDefaultOptions() {
    return extend(this.callBase(), {
      hoverStateEnabled: true,
      activeStateEnabled: true,
      value: false
    });
  },
  _canValueBeChangedByClick: () => true,
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: () => "desktop" === devices_default.real().deviceType && !devices_default.isSimulator(),
      options: {
        focusStateEnabled: true
      }
    }]);
  },
  _init() {
    this.callBase();
    this.$element().addClass("dx-radiobutton");
  },
  _initMarkup() {
    this.callBase();
    this._renderIcon();
    this._renderCheckedState(this.option("value"));
    this._renderClick();
    this.setAria("role", "radio");
  },
  _renderIcon() {
    this._$icon = renderer_default("<div>").addClass("dx-radiobutton-icon");
    renderer_default("<div>").addClass("dx-radiobutton-icon-dot").appendTo(this._$icon);
    this.$element().append(this._$icon);
  },
  _renderCheckedState(checked) {
    this.$element().toggleClass("dx-radiobutton-checked", checked).find(".dx-radiobutton-icon").toggleClass("dx-radiobutton-icon-checked", checked);
    this.setAria("checked", checked);
  },
  _renderClick() {
    const eventName = addNamespace(CLICK_EVENT_NAME, this.NAME);
    this._clickAction = this._createAction((args) => {
      this._clickHandler(args.event);
    });
    events_engine_default.off(this.$element(), eventName);
    events_engine_default.on(this.$element(), eventName, (e) => {
      this._clickAction({
        event: e
      });
    });
  },
  _clickHandler(e) {
    this._saveValueChangeEvent(e);
    this.option("value", true);
  },
  _optionChanged(args) {
    if ("value" === args.name) {
      this._renderCheckedState(args.value);
      this.callBase(args);
    } else {
      this.callBase(args);
    }
  }
});
component_registrator_default("dxRadioButton", RadioButton);
var m_radio_button_default = RadioButton;

// node_modules/devextreme/esm/ui/radio_group/radio_button.js
var radio_button_default = m_radio_button_default;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.js
var LIST_EDIT_DECORATOR = "dxListEditDecorator";
var SWIPE_START_EVENT_NAME = addNamespace(SWIPE_START_EVENT, LIST_EDIT_DECORATOR);
var SWIPE_UPDATE_EVENT_NAME = addNamespace(SWIPE_EVENT, LIST_EDIT_DECORATOR);
var SWIPE_END_EVENT_NAME = addNamespace(SWIPE_END_EVENT, LIST_EDIT_DECORATOR);
var EditDecorator = class_default.inherit({
  ctor(list) {
    this._list = list;
    this._init();
  },
  _init: noop,
  _shouldHandleSwipe: false,
  _attachSwipeEvent(config) {
    const swipeConfig = {
      itemSizeFunc: (function() {
        if (this._clearSwipeCache) {
          this._itemWidthCache = getWidth(this._list.$element());
          this._clearSwipeCache = false;
        }
        return this._itemWidthCache;
      }).bind(this)
    };
    events_engine_default.on(config.$itemElement, SWIPE_START_EVENT_NAME, swipeConfig, this._itemSwipeStartHandler.bind(this));
    events_engine_default.on(config.$itemElement, SWIPE_UPDATE_EVENT_NAME, this._itemSwipeUpdateHandler.bind(this));
    events_engine_default.on(config.$itemElement, SWIPE_END_EVENT_NAME, this._itemSwipeEndHandler.bind(this));
  },
  _itemSwipeStartHandler(e) {
    const $itemElement = renderer_default(e.currentTarget);
    if ($itemElement.is(".dx-state-disabled, .dx-state-disabled *")) {
      e.cancel = true;
      return;
    }
    clearTimeout(this._list._inkRippleTimer);
    this._swipeStartHandler($itemElement, e);
  },
  _itemSwipeUpdateHandler(e) {
    const $itemElement = renderer_default(e.currentTarget);
    this._swipeUpdateHandler($itemElement, e);
  },
  _itemSwipeEndHandler(e) {
    const $itemElement = renderer_default(e.currentTarget);
    this._swipeEndHandler($itemElement, e);
    this._clearSwipeCache = true;
  },
  beforeBag: noop,
  afterBag: noop,
  _commonOptions() {
    return {
      activeStateEnabled: this._list.option("activeStateEnabled"),
      hoverStateEnabled: this._list.option("hoverStateEnabled"),
      focusStateEnabled: this._list.option("focusStateEnabled")
    };
  },
  modifyElement(config) {
    if (this._shouldHandleSwipe) {
      this._attachSwipeEvent(config);
      this._clearSwipeCache = true;
    }
  },
  afterRender: noop,
  handleClick: noop,
  handleKeyboardEvents: noop,
  handleEnterPressing: noop,
  handleContextMenu: noop,
  _swipeStartHandler: noop,
  _swipeUpdateHandler: noop,
  _swipeEndHandler: noop,
  visibilityChange: noop,
  getExcludedSelectors: noop,
  dispose: noop
});
var m_list_edit_decorator_default = EditDecorator;

// node_modules/devextreme/esm/__internal/ui/list/m_list.edit.decorator.selection.js
var SELECT_DECORATOR_ENABLED_CLASS = "dx-list-select-decorator-enabled";
var SELECT_CHECKBOX_CONTAINER_CLASS = "dx-list-select-checkbox-container";
var SELECT_CHECKBOX_CLASS = "dx-list-select-checkbox";
var SELECT_RADIO_BUTTON_CONTAINER_CLASS = "dx-list-select-radiobutton-container";
var SELECT_RADIO_BUTTON_CLASS = "dx-list-select-radiobutton";
var CLICK_EVENT_NAME2 = addNamespace(CLICK_EVENT_NAME, "dxListEditDecorator");
register("selection", "default", m_list_edit_decorator_default.inherit({
  _init() {
    this.callBase.apply(this, arguments);
    const selectionMode = this._list.option("selectionMode");
    this._singleStrategy = "single" === selectionMode;
    this._containerClass = this._singleStrategy ? SELECT_RADIO_BUTTON_CONTAINER_CLASS : SELECT_CHECKBOX_CONTAINER_CLASS;
    this._controlClass = this._singleStrategy ? SELECT_RADIO_BUTTON_CLASS : SELECT_CHECKBOX_CLASS;
    this._controlWidget = this._singleStrategy ? radio_button_default : check_box_default;
    this._list.$element().addClass(SELECT_DECORATOR_ENABLED_CLASS);
  },
  beforeBag(config) {
    const {
      $itemElement
    } = config;
    const $container = config.$container.addClass(this._containerClass);
    const $control = renderer_default("<div>").addClass(this._controlClass).appendTo($container);
    new this._controlWidget($control, extend(this._commonOptions(), {
      value: this._isSelected($itemElement),
      elementAttr: {
        "aria-label": "Check State"
      },
      focusStateEnabled: false,
      hoverStateEnabled: false,
      onValueChanged: (function(e) {
        e.event && this._list._saveSelectionChangeEvent(e.event);
        this._processCheckedState($itemElement, e.value);
        e.event && e.event.stopPropagation();
      }).bind(this)
    }));
  },
  modifyElement(config) {
    this.callBase.apply(this, arguments);
    const {
      $itemElement
    } = config;
    const control = this._controlWidget.getInstance($itemElement.find(`.${this._controlClass}`));
    events_engine_default.on($itemElement, "stateChanged", (e, state) => {
      control.option("value", state);
    });
  },
  _updateSelectAllState() {
    if (!this._$selectAll) {
      return;
    }
    this._selectAllCheckBox.option("value", this._list.isSelectAll());
  },
  afterRender() {
    if ("all" !== this._list.option("selectionMode")) {
      return;
    }
    if (!this._$selectAll) {
      this._renderSelectAll();
    } else {
      this._updateSelectAllState();
    }
  },
  handleKeyboardEvents(currentFocusedIndex, moveFocusUp) {
    const moveFocusDown = !moveFocusUp;
    const list = this._list;
    const $selectAll = this._$selectAll;
    const lastItemIndex = list._getLastItemIndex();
    const isFocusOutOfList = moveFocusUp && 0 === currentFocusedIndex || moveFocusDown && currentFocusedIndex === lastItemIndex;
    const hasSelectAllItem = !!$selectAll;
    if (hasSelectAllItem && isFocusOutOfList) {
      list.option("focusedElement", $selectAll);
      list.scrollToItem(list.option("focusedElement"));
      return true;
    }
    return false;
  },
  handleEnterPressing(e) {
    if (this._$selectAll && this._$selectAll.hasClass("dx-state-focused")) {
      e.target = this._$selectAll.get(0);
      this._list._saveSelectionChangeEvent(e);
      this._selectAllCheckBox.option("value", !this._selectAllCheckBox.option("value"));
      return true;
    }
  },
  _renderSelectAll() {
    this._$selectAll = renderer_default("<div>").addClass("dx-list-select-all");
    const downArrowHandler = this._list._supportedKeys().downArrow.bind(this._list);
    const selectAllCheckBoxElement = renderer_default("<div>").addClass("dx-list-select-all-checkbox").appendTo(this._$selectAll);
    this._selectAllCheckBox = this._list._createComponent(selectAllCheckBoxElement, check_box_default, {
      elementAttr: {
        "aria-label": message_default.format("dxList-selectAll")
      },
      focusStateEnabled: false,
      hoverStateEnabled: false
    });
    this._selectAllCheckBox.registerKeyHandler("downArrow", downArrowHandler);
    renderer_default("<div>").addClass("dx-list-select-all-label").text(this._list.option("selectAllText")).appendTo(this._$selectAll);
    this._list.itemsContainer().prepend(this._$selectAll);
    this._updateSelectAllState();
    this._updateSelectAllAriaLabel();
    this._attachSelectAllHandler();
  },
  _attachSelectAllHandler() {
    this._selectAllCheckBox.option("onValueChanged", this._selectAllHandler.bind(this));
    events_engine_default.off(this._$selectAll, CLICK_EVENT_NAME2);
    events_engine_default.on(this._$selectAll, CLICK_EVENT_NAME2, this._selectAllClickHandler.bind(this));
  },
  _updateSelectAllAriaLabel() {
    if (!this._$selectAll) {
      return;
    }
    const {
      value
    } = this._selectAllCheckBox.option();
    const indeterminate = void 0 === value;
    const checkedText = indeterminate ? "half checked" : value ? "checked" : "not checked";
    const label = `${message_default.format("dxList-selectAll")}, ${checkedText}`;
    this._$selectAll.attr({
      "aria-label": label
    });
  },
  _selectAllHandler(e) {
    e.event && e.event.stopPropagation();
    e.event && this._list._saveSelectionChangeEvent(e.event);
    const {
      value
    } = this._selectAllCheckBox.option();
    if (value) {
      this._selectAllItems();
    } else if (false === value) {
      this._unselectAllItems();
    }
    this._updateSelectAllAriaLabel();
    this._list._createActionByOption("onSelectAllValueChanged")({
      value
    });
  },
  _checkSelectAllCapability() {
    const list = this._list;
    const dataController = list._dataController;
    if ("allPages" === list.option("selectAllMode") && list.option("grouped") && !dataController.group()) {
      ui_errors_default.log("W1010");
      return false;
    }
    return true;
  },
  _selectAllItems() {
    if (!this._checkSelectAllCapability()) {
      return;
    }
    this._list._selection.selectAll("page" === this._list.option("selectAllMode"));
  },
  _unselectAllItems() {
    if (!this._checkSelectAllCapability()) {
      return;
    }
    this._list._selection.deselectAll("page" === this._list.option("selectAllMode"));
  },
  _selectAllClickHandler(e) {
    this._list._saveSelectionChangeEvent(e);
    this._selectAllCheckBox.option("value", !this._selectAllCheckBox.option("value"));
  },
  _isSelected($itemElement) {
    return this._list.isItemSelected($itemElement);
  },
  _processCheckedState($itemElement, checked) {
    if (checked) {
      this._list.selectItem($itemElement);
    } else {
      this._list.unselectItem($itemElement);
    }
  },
  dispose() {
    this._disposeSelectAll();
    this._list.$element().removeClass(SELECT_DECORATOR_ENABLED_CLASS);
    this.callBase.apply(this, arguments);
  },
  _disposeSelectAll() {
    if (this._$selectAll) {
      this._$selectAll.remove();
      this._$selectAll = null;
    }
  }
}));

export {
  register,
  m_list_edit_default,
  list_light_default,
  m_list_edit_decorator_default
};
//# sourceMappingURL=chunk-FJ67NK4V.js.map
