import {
  isMaterialBased
} from "./chunk-ZLMLMAKO.js";
import {
  ui_overlay_default
} from "./chunk-MY7IBGWI.js";
import {
  component_registrator_default,
  pointer_default
} from "./chunk-X73RLF6Y.js";
import {
  value
} from "./chunk-25VDHZLA.js";
import {
  renderer_default
} from "./chunk-M4HNHSVV.js";
import {
  events_engine_default
} from "./chunk-PJXMQ5JC.js";
import {
  ready_callbacks_default
} from "./chunk-IY7TXKCY.js";
import {
  _extends,
  dom_adapter_default,
  extend,
  getWindow,
  isPlainObject,
  isString
} from "./chunk-V6EUNM2D.js";

// node_modules/devextreme/esm/__internal/ui/toast/m_toast.js
var ready = ready_callbacks_default.add;
var toastTypes = ["info", "warning", "error", "success"];
var TOAST_STACK = [];
var POSITION_ALIASES = {
  top: {
    my: "top",
    at: "top",
    of: null,
    offset: "0 0"
  },
  bottom: {
    my: "bottom",
    at: "bottom",
    of: null,
    offset: "0 -20"
  },
  center: {
    my: "center",
    at: "center",
    of: null,
    offset: "0 0"
  },
  right: {
    my: "center right",
    at: "center right",
    of: null,
    offset: "0 0"
  },
  left: {
    my: "center left",
    at: "center left",
    of: null,
    offset: "0 0"
  }
};
var DEFAULT_BOUNDARY_OFFSET = {
  h: 0,
  v: 0
};
ready(() => {
  events_engine_default.subscribeGlobal(dom_adapter_default.getDocument(), pointer_default.down, (e) => {
    for (let i = TOAST_STACK.length - 1; i >= 0; i--) {
      if (!TOAST_STACK[i]._proxiedDocumentDownHandler(e)) {
        return;
      }
    }
  });
});
var Toast = ui_overlay_default.inherit({
  _getDefaultOptions() {
    return extend(this.callBase(), {
      message: "",
      type: "info",
      displayTime: 2e3,
      position: "bottom center",
      animation: {
        show: {
          type: "fade",
          duration: 400,
          from: 0,
          to: 1
        },
        hide: {
          type: "fade",
          duration: 400,
          from: 1,
          to: 0
        }
      },
      shading: false,
      height: "auto",
      hideTopOverlayHandler: null,
      preventScrollEvents: false,
      closeOnSwipe: true,
      closeOnClick: false
    });
  },
  _defaultOptionsRules() {
    const tabletAndMobileCommonOptions = {
      displayTime: isMaterialBased() ? 4e3 : 2e3,
      hideOnOutsideClick: true,
      animation: {
        show: {
          type: "fade",
          duration: 200,
          from: 0,
          to: 1
        },
        hide: {
          type: "fade",
          duration: 200,
          from: 1,
          to: 0
        }
      }
    };
    return this.callBase().concat([{
      device: (device) => "phone" === device.deviceType,
      options: _extends({
        width: "calc(100vw - 40px)"
      }, tabletAndMobileCommonOptions)
    }, {
      device: (device) => "tablet" === device.deviceType,
      options: _extends({
        width: "auto",
        maxWidth: "80vw"
      }, tabletAndMobileCommonOptions)
    }, {
      device: (device) => isMaterialBased() && "desktop" === device.deviceType,
      options: {
        minWidth: 344,
        maxWidth: 568,
        displayTime: 4e3
      }
    }]);
  },
  _init() {
    this.callBase();
    this._posStringToObject();
  },
  _renderContentImpl() {
    this._message = renderer_default("<div>").addClass("dx-toast-message").text(this.option("message")).appendTo(this.$content());
    this.setAria("role", "alert", this._message);
    if (toastTypes.includes(this.option("type").toLowerCase())) {
      this.$content().prepend(renderer_default("<div>").addClass("dx-toast-icon"));
    }
    this.callBase();
  },
  _render() {
    this.callBase();
    this.$element().addClass("dx-toast");
    this.$wrapper().addClass("dx-toast-wrapper");
    this.$content().addClass("dx-toast-" + String(this.option("type")).toLowerCase());
    this.$content().addClass("dx-toast-content");
    this._toggleCloseEvents("Swipe");
    this._toggleCloseEvents("Click");
  },
  _toggleCloseEvents(event) {
    const dxEvent = `dx${event.toLowerCase()}`;
    events_engine_default.off(this.$content(), dxEvent);
    this.option(`closeOn${event}`) && events_engine_default.on(this.$content(), dxEvent, this.hide.bind(this));
  },
  _posStringToObject() {
    if (!isString(this.option("position"))) {
      return;
    }
    const verticalPosition = this.option("position").split(" ")[0];
    const horizontalPosition = this.option("position").split(" ")[1];
    this.option("position", extend({
      boundaryOffset: DEFAULT_BOUNDARY_OFFSET
    }, POSITION_ALIASES[verticalPosition]));
    switch (horizontalPosition) {
      case "center":
      case "left":
      case "right":
        this.option("position").at += ` ${horizontalPosition}`;
        this.option("position").my += ` ${horizontalPosition}`;
    }
  },
  _show() {
    return this.callBase.apply(this, arguments).always(() => {
      clearTimeout(this._hideTimeout);
      this._hideTimeout = setTimeout(this.hide.bind(this), this.option("displayTime"));
    });
  },
  _overlayStack: () => TOAST_STACK,
  _zIndexInitValue() {
    return this.callBase() + 8e3;
  },
  _dispose() {
    clearTimeout(this._hideTimeout);
    this.callBase();
  },
  _optionChanged(args) {
    switch (args.name) {
      case "type":
        this.$content().removeClass("dx-toast-" + args.previousValue);
        this.$content().addClass("dx-toast-" + String(args.value).toLowerCase());
        break;
      case "message":
        if (this._message) {
          this._message.text(args.value);
        }
        break;
      case "closeOnSwipe":
        this._toggleCloseEvents("Swipe");
        break;
      case "closeOnClick":
        this._toggleCloseEvents("Click");
        break;
      case "displayTime":
        break;
      default:
        this.callBase(args);
    }
  }
});
component_registrator_default("dxToast", Toast);
var m_toast_default = Toast;

// node_modules/devextreme/esm/ui/toast.js
var toast_default = m_toast_default;

// node_modules/devextreme/esm/__internal/ui/m_notify.js
var window = getWindow();
var $notify = null;
var $containers = {};
function notify(message, typeOrStack, displayTime) {
  const options = isPlainObject(message) ? message : {
    message
  };
  const stack = isPlainObject(typeOrStack) ? typeOrStack : void 0;
  const type = isPlainObject(typeOrStack) ? void 0 : typeOrStack;
  const {
    onHidden: userOnHidden
  } = options;
  if (null !== stack && void 0 !== stack && stack.position) {
    const {
      position
    } = stack;
    const direction = stack.direction || getDefaultDirection(position);
    const containerKey = isString(position) ? position : `${position.top}-${position.left}-${position.bottom}-${position.right}`;
    const {
      onShowing: userOnShowing
    } = options;
    const $container = getStackContainer(containerKey);
    setContainerClasses($container, direction);
    extend(options, {
      container: $container,
      _skipContentPositioning: true,
      onShowing(args) {
        setContainerStyles($container, direction, position);
        null === userOnShowing || void 0 === userOnShowing || userOnShowing(args);
      }
    });
  }
  extend(options, {
    type,
    displayTime,
    onHidden(args) {
      renderer_default(args.element).remove();
      null === userOnHidden || void 0 === userOnHidden || userOnHidden(args);
    }
  });
  $notify = renderer_default("<div>").appendTo(value());
  new toast_default($notify, options).show();
}
var getDefaultDirection = (position) => isString(position) && position.includes("top") ? "down-push" : "up-push";
var createStackContainer = (key) => {
  const $container = renderer_default("<div>").appendTo(value());
  $containers[key] = $container;
  return $container;
};
var getStackContainer = (key) => {
  const $container = $containers[key];
  return $container || createStackContainer(key);
};
var setContainerClasses = (container, direction) => {
  const containerClasses = `dx-toast-stack dx-toast-stack-${direction}-direction`;
  container.removeAttr("class").addClass(containerClasses);
};
var setContainerStyles = (container, direction, position) => {
  const {
    offsetWidth: toastWidth,
    offsetHeight: toastHeight
  } = container.children().first().get(0);
  const dimensions = {
    toastWidth,
    toastHeight,
    windowHeight: window.innerHeight,
    windowWidth: window.innerWidth
  };
  const coordinates = isString(position) ? getCoordinatesByAlias(position, dimensions) : position;
  const styles = getPositionStylesByCoordinates(direction, coordinates, dimensions);
  container.css(styles);
};
var getCoordinatesByAlias = (alias, _ref) => {
  let {
    toastWidth,
    toastHeight,
    windowHeight,
    windowWidth
  } = _ref;
  switch (alias) {
    case "top left":
      return {
        top: 10,
        left: 10
      };
    case "top right":
      return {
        top: 10,
        right: 10
      };
    case "bottom left":
      return {
        bottom: 10,
        left: 10
      };
    case "bottom right":
      return {
        bottom: 10,
        right: 10
      };
    case "top center":
      return {
        top: 10,
        left: Math.round(windowWidth / 2 - toastWidth / 2)
      };
    case "left center":
      return {
        top: Math.round(windowHeight / 2 - toastHeight / 2),
        left: 10
      };
    case "right center":
      return {
        top: Math.round(windowHeight / 2 - toastHeight / 2),
        right: 10
      };
    case "center":
      return {
        top: Math.round(windowHeight / 2 - toastHeight / 2),
        left: Math.round(windowWidth / 2 - toastWidth / 2)
      };
    default:
      return {
        bottom: 10,
        left: Math.round(windowWidth / 2 - toastWidth / 2)
      };
  }
};
var getPositionStylesByCoordinates = (direction, coordinates, dimensions) => {
  const {
    toastWidth,
    toastHeight,
    windowHeight,
    windowWidth
  } = dimensions;
  switch (direction.replace(/-push|-stack/g, "")) {
    case "up":
      return {
        bottom: coordinates.bottom ?? windowHeight - toastHeight - coordinates.top,
        top: "",
        left: coordinates.left ?? "",
        right: coordinates.right ?? ""
      };
    case "down":
      return {
        top: coordinates.top ?? windowHeight - toastHeight - coordinates.bottom,
        bottom: "",
        left: coordinates.left ?? "",
        right: coordinates.right ?? ""
      };
    case "left":
      return {
        right: coordinates.right ?? windowWidth - toastWidth - coordinates.left,
        left: "",
        top: coordinates.top ?? "",
        bottom: coordinates.bottom ?? ""
      };
    case "right":
      return {
        left: coordinates.left ?? windowWidth - toastWidth - coordinates.right,
        right: "",
        top: coordinates.top ?? "",
        bottom: coordinates.bottom ?? ""
      };
  }
};
var m_notify_default = notify;

// node_modules/devextreme/esm/ui/notify.js
var notify_default = m_notify_default;

export {
  toast_default,
  notify_default
};
//# sourceMappingURL=chunk-IWOFADVS.js.map
