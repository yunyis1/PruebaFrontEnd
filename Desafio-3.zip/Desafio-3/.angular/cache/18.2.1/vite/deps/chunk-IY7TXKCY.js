import {
  call_once_default
} from "./chunk-E4ZFM5M7.js";
import {
  dependency_injector_default,
  dom_adapter_default,
  hasWindow
} from "./chunk-V6EUNM2D.js";

// node_modules/devextreme/esm/core/utils/ready_callbacks.js
var callbacks = [];
var subscribeReady = call_once_default(() => {
  const removeListener = dom_adapter_default.listen(dom_adapter_default.getDocument(), "DOMContentLoaded", () => {
    readyCallbacks.fire();
    removeListener();
  });
});
var readyCallbacks = {
  add: (callback) => {
    const windowExists = hasWindow();
    if (windowExists && "loading" !== dom_adapter_default.getReadyState()) {
      callback();
    } else {
      callbacks.push(callback);
      windowExists && subscribeReady();
    }
  },
  fire: () => {
    callbacks.forEach((callback) => callback());
    callbacks = [];
  }
};
var ready_callbacks_default = dependency_injector_default(readyCallbacks);

export {
  ready_callbacks_default
};
//# sourceMappingURL=chunk-IY7TXKCY.js.map
