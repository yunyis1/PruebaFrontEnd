import {
  EventsStrategy
} from "./chunk-IMMMCDPJ.js";
import {
  ready_callbacks_default
} from "./chunk-IY7TXKCY.js";
import {
  Deferred,
  _extends,
  class_default,
  compileGetter,
  dom_adapter_default,
  each,
  equalByValue,
  error_default,
  errors_default,
  extend,
  getWindow,
  grep,
  isDefined,
  isEmptyObject,
  isFunction,
  isString,
  map,
  noop,
  toComparable,
  when
} from "./chunk-V6EUNM2D.js";

// node_modules/devextreme/esm/data/errors.js
var errors = error_default(errors_default.ERROR_MESSAGES, {
  E4000: "[DevExpress.data]: {0}",
  E4001: "Unknown aggregating function is detected: '{0}'",
  E4002: "Unsupported OData protocol version is used",
  E4003: "Unknown filter operation is used: {0}",
  E4004: "The thenby() method is called before the sortby() method",
  E4005: "Store requires a key expression for this operation",
  E4006: "ArrayStore 'data' option must be an array",
  E4007: "Compound keys cannot be auto-generated",
  E4008: "Attempt to insert an item with a duplicated key",
  E4009: "Data item cannot be found",
  E4010: "CustomStore does not support creating queries",
  E4011: "Custom Store method is not implemented or is not a function: {0}",
  E4012: "Custom Store method returns an invalid value: {0}",
  E4013: "Local Store requires the 'name' configuration option is specified",
  E4014: "Unknown data type is specified for ODataStore: {0}",
  E4015: "Unknown entity name or alias is used: {0}",
  E4016: "The compileSetter(expr) method is called with 'self' passed as a parameter",
  E4017: "Keys cannot be modified",
  E4018: "The server has returned a non-numeric value in a response to an item count request",
  E4019: "Mixing of group operators inside a single group of filter expression is not allowed",
  E4020: "Unknown store type is detected: {0}",
  E4021: "The server response does not provide the totalCount value",
  E4022: "The server response does not provide the groupCount value",
  E4023: "Could not parse the following XML: {0}",
  E4024: "String function {0} cannot be used with the data field {1} of type {2}.",
  W4000: "Data returned from the server has an incorrect structure",
  W4001: 'The {0} field is listed in both "keyType" and "fieldTypes". The value of "fieldTypes" is used.',
  W4002: "Data loading has failed for some cells due to the following error: {0}"
});
var errorHandler = null;
var handleError = function(error) {
  var _errorHandler;
  null === (_errorHandler = errorHandler) || void 0 === _errorHandler || _errorHandler(error);
};

// node_modules/devextreme/esm/data/utils.js
var ready = ready_callbacks_default.add;
var XHR_ERROR_UNLOAD = "DEVEXTREME_XHR_ERROR_UNLOAD";
var normalizeBinaryCriterion = function(crit) {
  return [crit[0], crit.length < 3 ? "=" : String(crit[1]).toLowerCase(), crit.length < 2 ? true : crit[crit.length - 1]];
};
var normalizeSortingInfo = function(info) {
  if (!Array.isArray(info)) {
    info = [info];
  }
  return map(info, function(i) {
    const result = {
      selector: isFunction(i) || "string" === typeof i ? i : i.getter || i.field || i.selector,
      desc: !!(i.desc || "d" === String(i.dir).charAt(0).toLowerCase())
    };
    if (i.compare) {
      result.compare = i.compare;
    }
    return result;
  });
};
var errorMessageFromXhr = function() {
  const textStatusMessages = {
    timeout: "Network connection timeout",
    error: "Unspecified network error",
    parsererror: "Unexpected server response"
  };
  let unloading;
  ready(function() {
    const window = getWindow();
    dom_adapter_default.listen(window, "beforeunload", function() {
      unloading = true;
    });
  });
  return function(xhr, textStatus) {
    if (unloading) {
      return XHR_ERROR_UNLOAD;
    }
    if (xhr.status < 400) {
      return function(textStatus2) {
        let result = textStatusMessages[textStatus2];
        if (!result) {
          return textStatus2;
        }
        return result;
      }(textStatus);
    }
    return xhr.statusText;
  };
}();
var aggregators = {
  count: {
    seed: 0,
    step: function(count) {
      return 1 + count;
    }
  },
  sum: {
    seed: 0,
    step: function(sum, item) {
      return sum + item;
    }
  },
  min: {
    step: function(min, item) {
      return item < min ? item : min;
    }
  },
  max: {
    step: function(max, item) {
      return item > max ? item : max;
    }
  },
  avg: {
    seed: [0, 0],
    step: function(pair, value) {
      return [pair[0] + value, pair[1] + 1];
    },
    finalize: function(pair) {
      return pair[1] ? pair[0] / pair[1] : NaN;
    }
  }
};
var processRequestResultLock = /* @__PURE__ */ function() {
  let lockCount = 0;
  let lockDeferred;
  return {
    obtain: function() {
      if (0 === lockCount) {
        lockDeferred = new Deferred();
      }
      lockCount++;
    },
    release: function() {
      lockCount--;
      if (lockCount < 1) {
        lockDeferred.resolve();
      }
    },
    promise: function() {
      const deferred = 0 === lockCount ? new Deferred().resolve() : lockDeferred;
      return deferred.promise();
    },
    reset: function() {
      lockCount = 0;
      if (lockDeferred) {
        lockDeferred.resolve();
      }
    }
  };
}();
function isConjunctiveOperator(condition) {
  return /^(and|&&|&)$/i.test(condition);
}
var keysEqual = function(keyExpr, key1, key2) {
  if (Array.isArray(keyExpr)) {
    const names = map(key1, function(v, k) {
      return k;
    });
    let name;
    for (let i = 0; i < names.length; i++) {
      name = names[i];
      if (!equalByValue(key1[name], key2[name], {
        strict: false
      })) {
        return false;
      }
    }
    return true;
  }
  return equalByValue(key1, key2, {
    strict: false
  });
};
var isUnaryOperation = function(crit) {
  return "!" === crit[0] && Array.isArray(crit[1]);
};
var isGroupOperator = function(value) {
  return "and" === value || "or" === value;
};
var isUniformEqualsByOr = function(crit) {
  if (crit.length > 2 && Array.isArray(crit[0]) && "or" === crit[1] && "string" === typeof crit[0][0] && "=" === crit[0][1]) {
    const [prop] = crit[0];
    return !crit.find((el, i) => i % 2 !== 0 ? "or" !== el : !Array.isArray(el) || 3 !== el.length || el[0] !== prop || "=" !== el[1]);
  }
  return false;
};
var isGroupCriterion = function(crit) {
  const first = crit[0];
  const second = crit[1];
  if (Array.isArray(first)) {
    return true;
  }
  if (isFunction(first)) {
    if (Array.isArray(second) || isFunction(second) || isGroupOperator(second)) {
      return true;
    }
  }
  return false;
};
var trivialPromise = function() {
  const d = new Deferred();
  return d.resolve.apply(d, arguments).promise();
};
var rejectedPromise = function() {
  const d = new Deferred();
  return d.reject.apply(d, arguments).promise();
};
function throttle(func, timeout) {
  let timeoutId;
  return function() {
    if (!timeoutId) {
      timeoutId = setTimeout(() => {
        timeoutId = void 0;
        func.call(this);
      }, isFunction(timeout) ? timeout() : timeout);
    }
    return timeoutId;
  };
}
function throttleChanges(func, timeout) {
  let cache = [];
  const throttled = throttle(function() {
    func.call(this, cache);
    cache = [];
  }, timeout);
  return function(changes) {
    if (Array.isArray(changes)) {
      cache.push(...changes);
    }
    return throttled.call(this, cache);
  };
}

// node_modules/devextreme/esm/data/array_query.js
var Iterator = class_default.inherit({
  toArray: function() {
    const result = [];
    this.reset();
    while (this.next()) {
      result.push(this.current());
    }
    return result;
  },
  countable: function() {
    return false;
  }
});
var ArrayIterator = Iterator.inherit({
  ctor: function(array) {
    this.array = array;
    this.index = -1;
  },
  next: function() {
    if (this.index + 1 < this.array.length) {
      this.index++;
      return true;
    }
    return false;
  },
  current: function() {
    return this.array[this.index];
  },
  reset: function() {
    this.index = -1;
  },
  toArray: function() {
    return this.array.slice(0);
  },
  countable: function() {
    return true;
  },
  count: function() {
    return this.array.length;
  }
});
var WrappedIterator = Iterator.inherit({
  ctor: function(iter) {
    this.iter = iter;
  },
  next: function() {
    return this.iter.next();
  },
  current: function() {
    return this.iter.current();
  },
  reset: function() {
    return this.iter.reset();
  }
});
var MapIterator = WrappedIterator.inherit({
  ctor: function(iter, mapper) {
    this.callBase(iter);
    this.index = -1;
    this.mapper = mapper;
  },
  current: function() {
    return this.mapper(this.callBase(), this.index);
  },
  next: function() {
    const hasNext = this.callBase();
    if (hasNext) {
      this.index++;
    }
    return hasNext;
  }
});
var defaultCompare = function(xValue, yValue, options) {
  if (isString(xValue) && isString(yValue) && (null !== options && void 0 !== options && options.locale || null !== options && void 0 !== options && options.collatorOptions)) {
    return new Intl.Collator((null === options || void 0 === options ? void 0 : options.locale) || void 0, (null === options || void 0 === options ? void 0 : options.collatorOptions) || void 0).compare(xValue, yValue);
  }
  xValue = toComparable(xValue, false, options);
  yValue = toComparable(yValue, false, options);
  if (null === xValue && null !== yValue) {
    return -1;
  }
  if (null !== xValue && null === yValue) {
    return 1;
  }
  if (void 0 === xValue && void 0 !== yValue) {
    return 1;
  }
  if (void 0 !== xValue && void 0 === yValue) {
    return -1;
  }
  if (xValue < yValue) {
    return -1;
  }
  if (xValue > yValue) {
    return 1;
  }
  return 0;
};
var SortIterator = Iterator.inherit({
  ctor: function(iter, getter, desc, compare) {
    this.langParams = iter.langParams;
    if (!(iter instanceof MapIterator)) {
      iter = new MapIterator(iter, this._wrap);
      iter.langParams = this.langParams;
    }
    this.iter = iter;
    this.rules = [{
      getter,
      desc,
      compare,
      langParams: this.langParams
    }];
  },
  thenBy: function(getter, desc, compare) {
    const result = new SortIterator(this.sortedIter || this.iter, getter, desc, compare);
    if (!this.sortedIter) {
      result.rules = this.rules.concat(result.rules);
    }
    return result;
  },
  next: function() {
    this._ensureSorted();
    return this.sortedIter.next();
  },
  current: function() {
    this._ensureSorted();
    return this.sortedIter.current();
  },
  reset: function() {
    delete this.sortedIter;
  },
  countable: function() {
    return this.sortedIter || this.iter.countable();
  },
  count: function() {
    if (this.sortedIter) {
      return this.sortedIter.count();
    }
    return this.iter.count();
  },
  _ensureSorted: function() {
    const that = this;
    if (that.sortedIter) {
      return;
    }
    each(that.rules, function() {
      this.getter = compileGetter(this.getter);
    });
    that.sortedIter = new MapIterator(new ArrayIterator(this.iter.toArray().sort(function(x, y) {
      return that._compare(x, y);
    })), that._unwrap);
  },
  _wrap: function(record, index) {
    return {
      index,
      value: record
    };
  },
  _unwrap: function(wrappedItem) {
    return wrappedItem.value;
  },
  _getDefaultCompare: (langParams) => (xValue, yValue) => defaultCompare(xValue, yValue, langParams),
  _compare: function(x, y) {
    const xIndex = x.index;
    const yIndex = y.index;
    x = x.value;
    y = y.value;
    if (x === y) {
      return xIndex - yIndex;
    }
    for (let i = 0, rulesCount = this.rules.length; i < rulesCount; i++) {
      const rule = this.rules[i];
      const xValue = rule.getter(x);
      const yValue = rule.getter(y);
      const compare = rule.compare || this._getDefaultCompare(rule.langParams);
      const compareResult = compare(xValue, yValue);
      if (compareResult) {
        return rule.desc ? -compareResult : compareResult;
      }
    }
    return xIndex - yIndex;
  }
});
var compileCriteria = /* @__PURE__ */ function() {
  let langParams = {};
  const _toComparable = (value) => toComparable(value, false, langParams);
  const compileGroup = function(crit) {
    if (isUniformEqualsByOr(crit)) {
      return ((crit2) => {
        const getter = compileGetter(crit2[0][0]);
        const filterValues = crit2.reduce((acc, item, i) => {
          if (i % 2 === 0) {
            acc.push(_toComparable(item[2]));
          }
          return acc;
        }, []);
        return (obj) => {
          const value = _toComparable(getter(obj));
          return filterValues.some((filterValue) => useStrictComparison(filterValue) ? value === filterValue : value == filterValue);
        };
      })(crit);
    }
    const ops = [];
    let isConjunctiveOperator2 = false;
    let isConjunctiveNextOperator = false;
    each(crit, function() {
      if (Array.isArray(this) || isFunction(this)) {
        if (ops.length > 1 && isConjunctiveOperator2 !== isConjunctiveNextOperator) {
          throw new errors.Error("E4019");
        }
        ops.push(compileCriteria(this, langParams));
        isConjunctiveOperator2 = isConjunctiveNextOperator;
        isConjunctiveNextOperator = true;
      } else {
        isConjunctiveNextOperator = isConjunctiveOperator(this);
      }
    });
    return function(d) {
      let result = isConjunctiveOperator2;
      for (let i = 0; i < ops.length; i++) {
        if (ops[i](d) !== isConjunctiveOperator2) {
          result = !isConjunctiveOperator2;
          break;
        }
      }
      return result;
    };
  };
  const toString = function(value) {
    var _langParams;
    return isDefined(value) ? null !== (_langParams = langParams) && void 0 !== _langParams && _langParams.locale ? value.toLocaleString(langParams.locale) : value.toString() : "";
  };
  function compileEquals(getter, value, negate) {
    return function(obj) {
      obj = _toComparable(getter(obj));
      let result = useStrictComparison(value) ? obj === value : obj == value;
      if (negate) {
        result = !result;
      }
      return result;
    };
  }
  function useStrictComparison(value) {
    return "" === value || 0 === value || false === value;
  }
  return function(crit, options) {
    langParams = options || {};
    if (isFunction(crit)) {
      return crit;
    }
    if (isGroupCriterion(crit)) {
      return compileGroup(crit);
    }
    if (isUnaryOperation(crit)) {
      return function(crit2) {
        const op = crit2[0];
        const criteria = compileCriteria(crit2[1], langParams);
        if ("!" === op) {
          return function(obj) {
            return !criteria(obj);
          };
        }
        throw errors.Error("E4003", op);
      }(crit);
    }
    return function(crit2) {
      crit2 = normalizeBinaryCriterion(crit2);
      const getter = compileGetter(crit2[0]);
      const op = crit2[1];
      let value = crit2[2];
      value = _toComparable(value);
      const compare = (obj, operatorFn) => {
        obj = _toComparable(getter(obj));
        return (null == value || null == obj) && value !== obj ? false : operatorFn(obj, value);
      };
      switch (op.toLowerCase()) {
        case "=":
          return compileEquals(getter, value);
        case "<>":
          return compileEquals(getter, value, true);
        case ">":
          return (obj) => compare(obj, (a, b) => a > b);
        case "<":
          return (obj) => compare(obj, (a, b) => a < b);
        case ">=":
          return (obj) => compare(obj, (a, b) => a >= b);
        case "<=":
          return (obj) => compare(obj, (a, b) => a <= b);
        case "startswith":
          return function(obj) {
            return 0 === _toComparable(toString(getter(obj))).indexOf(value);
          };
        case "endswith":
          return function(obj) {
            const getterValue = _toComparable(toString(getter(obj)));
            const searchValue = toString(value);
            if (getterValue.length < searchValue.length) {
              return false;
            }
            const index = getterValue.lastIndexOf(value);
            return -1 !== index && index === getterValue.length - value.length;
          };
        case "contains":
          return function(obj) {
            return _toComparable(toString(getter(obj))).indexOf(value) > -1;
          };
        case "notcontains":
          return function(obj) {
            return -1 === _toComparable(toString(getter(obj))).indexOf(value);
          };
      }
      throw errors.Error("E4003", op);
    }(crit);
  };
}();
var FilterIterator = WrappedIterator.inherit({
  ctor: function(iter, criteria) {
    this.callBase(iter);
    this.langParams = iter.langParams;
    this.criteria = compileCriteria(criteria, this.langParams);
  },
  next: function() {
    while (this.iter.next()) {
      if (this.criteria(this.current())) {
        return true;
      }
    }
    return false;
  }
});
var GroupIterator = Iterator.inherit({
  ctor: function(iter, getter) {
    this.iter = iter;
    this.getter = getter;
  },
  next: function() {
    this._ensureGrouped();
    return this.groupedIter.next();
  },
  current: function() {
    this._ensureGrouped();
    return this.groupedIter.current();
  },
  reset: function() {
    delete this.groupedIter;
  },
  countable: function() {
    return !!this.groupedIter;
  },
  count: function() {
    return this.groupedIter.count();
  },
  _ensureGrouped: function() {
    if (this.groupedIter) {
      return;
    }
    const hash = {};
    const keys = [];
    const iter = this.iter;
    const getter = compileGetter(this.getter);
    iter.reset();
    while (iter.next()) {
      const current = iter.current();
      const key = getter(current);
      if (key in hash) {
        hash[key].push(current);
      } else {
        hash[key] = [current];
        keys.push(key);
      }
    }
    this.groupedIter = new ArrayIterator(map(keys, function(key) {
      return {
        key,
        items: hash[key]
      };
    }));
  }
});
var SelectIterator = WrappedIterator.inherit({
  ctor: function(iter, getter) {
    this.callBase(iter);
    this.getter = compileGetter(getter);
  },
  current: function() {
    return this.getter(this.callBase());
  },
  countable: function() {
    return this.iter.countable();
  },
  count: function() {
    return this.iter.count();
  }
});
var SliceIterator = WrappedIterator.inherit({
  ctor: function(iter, skip, take) {
    this.callBase(iter);
    this.skip = Math.max(0, skip);
    this.take = Math.max(0, take);
    this.pos = 0;
  },
  next: function() {
    if (this.pos >= this.skip + this.take) {
      return false;
    }
    while (this.pos < this.skip && this.iter.next()) {
      this.pos++;
    }
    this.pos++;
    return this.iter.next();
  },
  reset: function() {
    this.callBase();
    this.pos = 0;
  },
  countable: function() {
    return this.iter.countable();
  },
  count: function() {
    return Math.min(this.iter.count() - this.skip, this.take);
  }
});
var arrayQueryImpl = function(iter, queryOptions) {
  queryOptions = queryOptions || {};
  if (!(iter instanceof Iterator)) {
    iter = new ArrayIterator(iter);
  }
  if (queryOptions.langParams) {
    iter.langParams = queryOptions.langParams;
  }
  const handleError2 = function(error) {
    const handler = queryOptions.errorHandler;
    if (handler) {
      handler(error);
    }
    handleError(error);
  };
  const aggregateCore = function(aggregator) {
    const d = new Deferred().fail(handleError2);
    let seed;
    const step = aggregator.step;
    const finalize = aggregator.finalize;
    try {
      iter.reset();
      if ("seed" in aggregator) {
        seed = aggregator.seed;
      } else {
        seed = iter.next() ? iter.current() : NaN;
      }
      let accumulator = seed;
      while (iter.next()) {
        accumulator = step(accumulator, iter.current());
      }
      d.resolve(finalize ? finalize(accumulator) : accumulator);
    } catch (x) {
      d.reject(x);
    }
    return d.promise();
  };
  const standardAggregate = function(name) {
    return aggregateCore(aggregators[name]);
  };
  const select = function(getter) {
    if (!isFunction(getter) && !Array.isArray(getter)) {
      getter = [].slice.call(arguments);
    }
    return chainQuery(new SelectIterator(iter, getter));
  };
  const selectProp = function(name) {
    return select(compileGetter(name));
  };
  function chainQuery(iter2) {
    return arrayQueryImpl(iter2, queryOptions);
  }
  return {
    toArray: function() {
      return iter.toArray();
    },
    enumerate: function() {
      const d = new Deferred().fail(handleError2);
      try {
        d.resolve(iter.toArray());
      } catch (x) {
        d.reject(x);
      }
      return d.promise();
    },
    setLangParams(options) {
      iter.langParams = options;
    },
    sortBy: function(getter, desc, compare) {
      return chainQuery(new SortIterator(iter, getter, desc, compare));
    },
    thenBy: function(getter, desc, compare) {
      if (iter instanceof SortIterator) {
        return chainQuery(iter.thenBy(getter, desc, compare));
      }
      throw errors.Error("E4004");
    },
    filter: function(criteria) {
      if (!Array.isArray(criteria)) {
        criteria = [].slice.call(arguments);
      }
      return chainQuery(new FilterIterator(iter, criteria));
    },
    slice: function(skip, take) {
      if (void 0 === take) {
        take = Number.MAX_VALUE;
      }
      return chainQuery(new SliceIterator(iter, skip, take));
    },
    select,
    groupBy: function(getter) {
      return chainQuery(new GroupIterator(iter, getter));
    },
    aggregate: function(seed, step, finalize) {
      if (arguments.length < 2) {
        return aggregateCore({
          step: arguments[0]
        });
      }
      return aggregateCore({
        seed,
        step,
        finalize
      });
    },
    count: function() {
      if (iter.countable()) {
        const d = new Deferred().fail(handleError2);
        try {
          d.resolve(iter.count());
        } catch (x) {
          d.reject(x);
        }
        return d.promise();
      }
      return standardAggregate("count");
    },
    sum: function(getter) {
      if (getter) {
        return selectProp(getter).sum();
      }
      return standardAggregate("sum");
    },
    min: function(getter) {
      if (getter) {
        return selectProp(getter).min();
      }
      return standardAggregate("min");
    },
    max: function(getter) {
      if (getter) {
        return selectProp(getter).max();
      }
      return standardAggregate("max");
    },
    avg: function(getter) {
      if (getter) {
        return selectProp(getter).avg();
      }
      return standardAggregate("avg");
    }
  };
};
var array_query_default = arrayQueryImpl;

// node_modules/devextreme/esm/data/store_helper.js
function multiLevelGroup(query2, groupInfo) {
  query2 = query2.groupBy(groupInfo[0].selector);
  if (groupInfo.length > 1) {
    query2 = query2.select(function(g) {
      return extend({}, g, {
        items: multiLevelGroup(array_query_default(g.items), groupInfo.slice(1)).toArray()
      });
    });
  }
  return query2;
}
function arrangeSortingInfo(groupInfo, sortInfo) {
  const filteredGroup = [];
  each(groupInfo, function(_, group) {
    const collision = grep(sortInfo, function(sort) {
      return group.selector === sort.selector;
    });
    if (collision.length < 1) {
      filteredGroup.push(group);
    }
  });
  return filteredGroup.concat(sortInfo);
}
function queryByOptions(query2, options, isCountQuery) {
  var _options;
  options = options || {};
  const filter = options.filter;
  if (null !== (_options = options) && void 0 !== _options && _options.langParams) {
    var _query$setLangParams, _query;
    null === (_query$setLangParams = (_query = query2).setLangParams) || void 0 === _query$setLangParams || _query$setLangParams.call(_query, options.langParams);
  }
  if (filter) {
    query2 = query2.filter(filter);
  }
  if (isCountQuery) {
    return query2;
  }
  let sort = options.sort;
  const select = options.select;
  let group = options.group;
  const skip = options.skip;
  const take = options.take;
  if (group) {
    group = normalizeSortingInfo(group);
    group.keepInitialKeyOrder = !!options.group.keepInitialKeyOrder;
  }
  if (sort || group) {
    sort = normalizeSortingInfo(sort || []);
    if (group && !group.keepInitialKeyOrder) {
      sort = arrangeSortingInfo(group, sort);
    }
    each(sort, function(index) {
      query2 = query2[index ? "thenBy" : "sortBy"](this.selector, this.desc, this.compare);
    });
  }
  if (select) {
    query2 = query2.select(select);
  }
  if (group) {
    query2 = multiLevelGroup(query2, group);
  }
  if (take || skip) {
    query2 = query2.slice(skip || 0, take);
  }
  return query2;
}
var store_helper_default = {
  multiLevelGroup,
  arrangeSortingInfo,
  queryByOptions
};

// node_modules/devextreme/esm/data/abstract_store.js
var abstract = class_default.abstract;
var queryByOptions2 = store_helper_default.queryByOptions;
var storeImpl = {};
var Store = class_default.inherit({
  _langParams: {},
  ctor: function(options) {
    const that = this;
    options = options || {};
    this._eventsStrategy = new EventsStrategy(this);
    each(["onLoaded", "onLoading", "onInserted", "onInserting", "onUpdated", "onUpdating", "onPush", "onRemoved", "onRemoving", "onModified", "onModifying"], function(_, optionName) {
      if (optionName in options) {
        that.on(optionName.slice(2).toLowerCase(), options[optionName]);
      }
    });
    this._key = options.key;
    this._errorHandler = options.errorHandler;
    this._useDefaultSearch = true;
  },
  _clearCache: noop,
  _customLoadOptions: function() {
    return null;
  },
  key: function() {
    return this._key;
  },
  keyOf: function(obj) {
    if (!this._keyGetter) {
      this._keyGetter = compileGetter(this.key());
    }
    return this._keyGetter(obj);
  },
  _requireKey: function() {
    if (!this.key()) {
      throw errors.Error("E4005");
    }
  },
  load: function(options) {
    const that = this;
    options = options || {};
    this._eventsStrategy.fireEvent("loading", [options]);
    return this._withLock(this._loadImpl(options)).done(function(result) {
      that._eventsStrategy.fireEvent("loaded", [result, options]);
    });
  },
  _loadImpl: function(options) {
    if (!isEmptyObject(this._langParams)) {
      options = options || {};
      options._langParams = _extends({}, this._langParams, options._langParams);
    }
    return queryByOptions2(this.createQuery(options), options).enumerate();
  },
  _withLock: function(task) {
    const result = new Deferred();
    task.done(function() {
      const that = this;
      const args = arguments;
      processRequestResultLock.promise().done(function() {
        result.resolveWith(that, args);
      });
    }).fail(function() {
      result.rejectWith(this, arguments);
    });
    return result;
  },
  createQuery: abstract,
  totalCount: function(options) {
    return this._totalCountImpl(options);
  },
  _totalCountImpl: function(options) {
    return queryByOptions2(this.createQuery(options), options, true).count();
  },
  byKey: function(key, extraOptions) {
    return this._addFailHandlers(this._withLock(this._byKeyImpl(key, extraOptions)));
  },
  _byKeyImpl: abstract,
  insert: function(values) {
    const that = this;
    that._eventsStrategy.fireEvent("modifying");
    that._eventsStrategy.fireEvent("inserting", [values]);
    return that._addFailHandlers(that._insertImpl(values).done(function(callbackValues, callbackKey) {
      that._eventsStrategy.fireEvent("inserted", [callbackValues, callbackKey]);
      that._eventsStrategy.fireEvent("modified");
    }));
  },
  _insertImpl: abstract,
  update: function(key, values) {
    const that = this;
    that._eventsStrategy.fireEvent("modifying");
    that._eventsStrategy.fireEvent("updating", [key, values]);
    return that._addFailHandlers(that._updateImpl(key, values).done(function() {
      that._eventsStrategy.fireEvent("updated", [key, values]);
      that._eventsStrategy.fireEvent("modified");
    }));
  },
  _updateImpl: abstract,
  push: function(changes) {
    const beforePushArgs = {
      changes,
      waitFor: []
    };
    this._eventsStrategy.fireEvent("beforePushAggregation", [beforePushArgs]);
    when(...beforePushArgs.waitFor).done(() => {
      this._pushImpl(changes);
      this._eventsStrategy.fireEvent("beforePush", [{
        changes
      }]);
      this._eventsStrategy.fireEvent("push", [changes]);
    });
  },
  _pushImpl: noop,
  remove: function(key) {
    const that = this;
    that._eventsStrategy.fireEvent("modifying");
    that._eventsStrategy.fireEvent("removing", [key]);
    return that._addFailHandlers(that._removeImpl(key).done(function(callbackKey) {
      that._eventsStrategy.fireEvent("removed", [callbackKey]);
      that._eventsStrategy.fireEvent("modified");
    }));
  },
  _removeImpl: abstract,
  _addFailHandlers: function(deferred) {
    return deferred.fail(this._errorHandler).fail(handleError);
  },
  on(eventName, eventHandler) {
    this._eventsStrategy.on(eventName, eventHandler);
    return this;
  },
  off(eventName, eventHandler) {
    this._eventsStrategy.off(eventName, eventHandler);
    return this;
  }
});
Store.create = function(alias, options) {
  if (!(alias in storeImpl)) {
    throw errors.Error("E4020", alias);
  }
  return new storeImpl[alias](options);
};
Store.registerClass = function(type, alias) {
  if (alias) {
    storeImpl[alias] = type;
  }
  return type;
};
Store.inherit = /* @__PURE__ */ function(inheritor) {
  return function(members, alias) {
    const type = inheritor.apply(this, [members]);
    Store.registerClass(type, alias);
    return type;
  };
}(Store.inherit);
var abstract_store_default = Store;

// node_modules/devextreme/esm/data/query_adapters.js
var query_adapters_default = {};

// node_modules/devextreme/esm/data/remote_query.js
var remoteQueryImpl = function(url, queryOptions, tasks) {
  tasks = tasks || [];
  queryOptions = queryOptions || {};
  const createTask = function(name, args) {
    return {
      name,
      args
    };
  };
  const exec = function(executorTask) {
    const d = new Deferred();
    let _adapterFactory;
    let _adapter;
    let _taskQueue;
    let _currentTask;
    let _mergedSortArgs;
    const rejectWithNotify = function(error) {
      const handler = queryOptions.errorHandler;
      if (handler) {
        handler(error);
      }
      handleError(error);
      d.reject(error);
    };
    function mergeSortTask(task) {
      switch (task.name) {
        case "sortBy":
          _mergedSortArgs = [task.args];
          return true;
        case "thenBy":
          if (!_mergedSortArgs) {
            throw errors.Error("E4004");
          }
          _mergedSortArgs.push(task.args);
          return true;
      }
      return false;
    }
    try {
      _adapterFactory = queryOptions.adapter;
      if (!isFunction(_adapterFactory)) {
        _adapterFactory = query_adapters_default[_adapterFactory];
      }
      _adapter = _adapterFactory(queryOptions);
      _taskQueue = [].concat(tasks).concat(executorTask);
      const optimize = _adapter.optimize;
      if (optimize) {
        optimize(_taskQueue);
      }
      while (_taskQueue.length) {
        _currentTask = _taskQueue[0];
        if (!mergeSortTask(_currentTask)) {
          if (_mergedSortArgs) {
            _taskQueue.unshift(createTask("multiSort", [_mergedSortArgs]));
            _mergedSortArgs = null;
            continue;
          }
          if ("enumerate" !== String(_currentTask.name)) {
            if (!_adapter[_currentTask.name] || false === _adapter[_currentTask.name].apply(_adapter, _currentTask.args)) {
              break;
            }
          }
        }
        _taskQueue.shift();
      }
      !function() {
        const head = _taskQueue[0];
        const unmergedTasks = [];
        if (head && "multiSort" === head.name) {
          _taskQueue.shift();
          each(head.args[0], function() {
            unmergedTasks.push(createTask(unmergedTasks.length ? "thenBy" : "sortBy", this));
          });
        }
        _taskQueue = unmergedTasks.concat(_taskQueue);
      }();
      _adapter.exec(url).done(function(result, extra) {
        if (!_taskQueue.length) {
          d.resolve(result, extra);
        } else {
          let clientChain = array_query_default(result, {
            errorHandler: queryOptions.errorHandler
          });
          each(_taskQueue, function() {
            clientChain = clientChain[this.name].apply(clientChain, this.args);
          });
          clientChain.done(d.resolve).fail(d.reject);
        }
      }).fail(rejectWithNotify);
    } catch (x) {
      rejectWithNotify(x);
    }
    return d.promise();
  };
  const query2 = {};
  each(["sortBy", "thenBy", "filter", "slice", "select", "groupBy"], function() {
    const name = String(this);
    query2[name] = function() {
      return remoteQueryImpl(url, queryOptions, tasks.concat(createTask(name, arguments)));
    };
  });
  each(["count", "min", "max", "sum", "avg", "aggregate", "enumerate"], function() {
    const name = String(this);
    query2[name] = function() {
      return exec.call(this, createTask(name, arguments));
    };
  });
  return query2;
};
var remote_query_default = remoteQueryImpl;

// node_modules/devextreme/esm/data/query_implementation.js
var queryImpl = {
  array: array_query_default,
  remote: remote_query_default
};

// node_modules/devextreme/esm/data/query.js
var query = function() {
  const impl = Array.isArray(arguments[0]) ? "array" : "remote";
  return queryImpl[impl].apply(this, arguments);
};
var query_default = query;

export {
  errors,
  XHR_ERROR_UNLOAD,
  normalizeBinaryCriterion,
  normalizeSortingInfo,
  errorMessageFromXhr,
  aggregators,
  isConjunctiveOperator,
  keysEqual,
  isUnaryOperation,
  trivialPromise,
  rejectedPromise,
  throttleChanges,
  array_query_default,
  store_helper_default,
  abstract_store_default,
  query_adapters_default,
  query_default
};
//# sourceMappingURL=chunk-NB6G4GLF.js.map
