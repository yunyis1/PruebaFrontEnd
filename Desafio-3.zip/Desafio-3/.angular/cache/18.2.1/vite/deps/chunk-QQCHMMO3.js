import {
  DBLCLICK_EVENT_NAME
} from "./chunk-QIILLVT5.js";
import {
  check_box_default
} from "./chunk-X7C6WMP5.js";
import {
  ui_hierarchical_collection_widget_default
} from "./chunk-G3IF5HS3.js";
import {
  ui_scrollable_default
} from "./chunk-VRGBSUXM.js";
import {
  text_box_default,
  ui_search_box_mixin_default
} from "./chunk-T7YQMDRE.js";
import {
  DxiButtonModule,
  DxiItemComponent,
  DxiItemModule,
  DxoOptionsModule,
  DxoSearchEditorOptionsModule
} from "./chunk-FU2NNGS6.js";
import {
  DIRECTION_HORIZONTAL,
  DIRECTION_VERTICAL,
  SCROLLABLE_CONTENT_CLASS,
  getRelativeOffset
} from "./chunk-X3V77ZBF.js";
import {
  load_indicator_default
} from "./chunk-G6YLJM3X.js";
import {
  getImageContainer
} from "./chunk-H4MEN2W7.js";
import {
  message_default
} from "./chunk-CSW63CAV.js";
import {
  fx_default
} from "./chunk-MY7IBGWI.js";
import {
  CLICK_EVENT_NAME,
  addNamespace,
  component_registrator_default,
  getPublicElement,
  nativeScrolling,
  pointer_default
} from "./chunk-X73RLF6Y.js";
import {
  DxComponent,
  DxIntegrationModule,
  DxTemplateHost,
  DxTemplateModule,
  IterableDifferHelper,
  NestedOptionHost,
  WatcherHelper
} from "./chunk-JWCECMBJ.js";
import {
  getHeight,
  renderer_default
} from "./chunk-M4HNHSVV.js";
import {
  events_engine_default
} from "./chunk-PJXMQ5JC.js";
import {
  Deferred,
  asyncNoop,
  dom_adapter_default,
  each,
  extend,
  fromPromise,
  hasWindow,
  isDefined,
  isFunction,
  isPrimitive,
  isString,
  noop,
  when
} from "./chunk-V6EUNM2D.js";
import {
  Component,
  ContentChildren,
  ElementRef,
  Inject,
  Input,
  NgModule,
  NgZone,
  Output,
  PLATFORM_ID,
  TransferState,
  setClassMetadata,
  ɵɵInheritDefinitionFeature,
  ɵɵNgOnChangesFeature,
  ɵɵProvidersFeature,
  ɵɵcontentQuery,
  ɵɵdefineComponent,
  ɵɵdefineInjector,
  ɵɵdefineNgModule,
  ɵɵdirectiveInject,
  ɵɵloadQuery,
  ɵɵqueryRefresh
} from "./chunk-I2242OIJ.js";

// node_modules/devextreme/esm/__internal/ui/tree_view/m_tree_view.base.js
var WIDGET_CLASS = "dx-treeview";
var NODE_CLASS = `${WIDGET_CLASS}-node`;
var NODE_CONTAINER_CLASS = `${NODE_CLASS}-container`;
var NODE_LOAD_INDICATOR_CLASS = `${NODE_CLASS}-loadindicator`;
var OPENED_NODE_CONTAINER_CLASS = `${NODE_CLASS}-container-opened`;
var IS_LEAF = `${NODE_CLASS}-is-leaf`;
var ITEM_CLASS = `${WIDGET_CLASS}-item`;
var ITEM_WITH_CHECKBOX_CLASS = `${ITEM_CLASS}-with-checkbox`;
var ITEM_WITH_CUSTOM_EXPANDER_ICON_CLASS = `${ITEM_CLASS}-with-custom-expander-icon`;
var CUSTOM_EXPANDER_ICON_ITEM_CONTAINER_CLASS = `${WIDGET_CLASS}-custom-expander-icon-item-container`;
var ITEM_WITHOUT_CHECKBOX_CLASS = `${ITEM_CLASS}-without-checkbox`;
var ITEM_DATA_KEY = `${ITEM_CLASS}-data`;
var TOGGLE_ITEM_VISIBILITY_CLASS = `${WIDGET_CLASS}-toggle-item-visibility`;
var CUSTOM_COLLAPSE_ICON_CLASS = `${WIDGET_CLASS}-custom-collapse-icon`;
var CUSTOM_EXPAND_ICON_CLASS = `${WIDGET_CLASS}-custom-expand-icon`;
var LOAD_INDICATOR_CLASS = `${WIDGET_CLASS}-loadindicator`;
var LOAD_INDICATOR_WRAPPER_CLASS = `${WIDGET_CLASS}-loadindicator-wrapper`;
var TOGGLE_ITEM_VISIBILITY_OPENED_CLASS = `${WIDGET_CLASS}-toggle-item-visibility-opened`;
var SELECT_ALL_ITEM_CLASS = `${WIDGET_CLASS}-select-all-item`;
var DATA_ITEM_ID = "data-item-id";
var ROOT_NODE_CLASS = `${WIDGET_CLASS}-root-node`;
var EXPANDER_ICON_STUB_CLASS = `${WIDGET_CLASS}-expander-icon-stub`;
var TreeViewBase = ui_hierarchical_collection_widget_default.inherit({
  _supportedKeys(e) {
    const click = (e2) => {
      const $itemElement = renderer_default(this.option("focusedElement"));
      if (!$itemElement.length) {
        return;
      }
      e2.target = $itemElement;
      e2.currentTarget = $itemElement;
      this._itemClickHandler(e2, $itemElement.children(`.${ITEM_CLASS}`));
      const expandEventName = this._getEventNameByOption(this.option("expandEvent"));
      const expandByClick = expandEventName === addNamespace(CLICK_EVENT_NAME, "dxTreeView_expand");
      if (expandByClick) {
        this._expandEventHandler(e2);
      }
    };
    const select = (e2) => {
      e2.preventDefault();
      const $focusedElement = renderer_default(this.option("focusedElement"));
      const checkboxInstance = this._getCheckBoxInstance($focusedElement);
      if (!checkboxInstance.option("disabled")) {
        const currentState = checkboxInstance.option("value");
        this._updateItemSelection(!currentState, $focusedElement.find(`.${ITEM_CLASS}`).get(0), true);
      }
    };
    const toggleExpandedNestedItems = function(state, e2) {
      if (!this.option("expandAllEnabled")) {
        return;
      }
      e2.preventDefault();
      const $rootElement = renderer_default(this.option("focusedElement"));
      if (!$rootElement.length) {
        return;
      }
      const rootItem = this._getItemData($rootElement.find(`.${ITEM_CLASS}`));
      this._toggleExpandedNestedItems([rootItem], state);
    };
    return extend(this.callBase(), {
      enter: this._showCheckboxes() ? select : click,
      space: this._showCheckboxes() ? select : click,
      asterisk: toggleExpandedNestedItems.bind(this, true),
      minus: toggleExpandedNestedItems.bind(this, false)
    });
  },
  _toggleExpandedNestedItems(items, state) {
    if (!items) {
      return;
    }
    for (let i = 0, len = items.length; i < len; i++) {
      const item = items[i];
      const node = this._dataAdapter.getNodeByItem(item);
      this._toggleExpandedState(node, state);
      this._toggleExpandedNestedItems(item.items, state);
    }
  },
  _getNodeElement(node, cache) {
    const key = this._encodeString(node.internalFields.key);
    if (cache) {
      if (!cache.$nodeByKey) {
        cache.$nodeByKey = {};
        this.$element().find(`.${NODE_CLASS}`).each(function() {
          const $node = renderer_default(this);
          const key2 = $node.attr(DATA_ITEM_ID);
          cache.$nodeByKey[key2] = $node;
        });
      }
      return cache.$nodeByKey[key] || renderer_default();
    }
    const element = this.$element().get(0).querySelector(`[${DATA_ITEM_ID}="${key}"]`);
    return renderer_default(element);
  },
  _activeStateUnit: `.${ITEM_CLASS}`,
  _widgetClass: () => WIDGET_CLASS,
  _getDefaultOptions() {
    const defaultOptions = extend(this.callBase(), {
      animationEnabled: true,
      dataStructure: "tree",
      deferRendering: true,
      expandAllEnabled: false,
      hasItemsExpr: "hasItems",
      selectNodesRecursive: true,
      expandNodesRecursive: true,
      showCheckBoxesMode: "none",
      expandIcon: null,
      collapseIcon: null,
      selectAllText: message_default.format("dxList-selectAll"),
      onItemSelectionChanged: null,
      onItemExpanded: null,
      onItemCollapsed: null,
      scrollDirection: "vertical",
      useNativeScrolling: true,
      virtualModeEnabled: false,
      rootValue: 0,
      focusStateEnabled: false,
      selectionMode: "multiple",
      expandEvent: "dblclick",
      selectByClick: false,
      createChildren: null,
      onSelectAllValueChanged: null,
      _supportItemUrl: false
    });
    return extend(true, defaultOptions, {
      integrationOptions: {
        useDeferUpdateForTemplates: false
      }
    });
  },
  _defaultOptionsRules() {
    return this.callBase().concat([{
      device: () => !nativeScrolling,
      options: {
        useNativeScrolling: false
      }
    }]);
  },
  _initSelectedItems: noop,
  _syncSelectionOptions: asyncNoop,
  _fireSelectionChanged() {
    const selectionChangePromise = this._selectionChangePromise;
    when(selectionChangePromise).done(() => {
      this._createActionByOption("onSelectionChanged", {
        excludeValidators: ["disabled", "readOnly"]
      })();
    });
  },
  _createSelectAllValueChangedAction() {
    this._selectAllValueChangedAction = this._createActionByOption("onSelectAllValueChanged", {
      excludeValidators: ["disabled", "readOnly"]
    });
  },
  _fireSelectAllValueChanged(value) {
    this._selectAllValueChangedAction({
      value
    });
  },
  _checkBoxModeChange(value, previousValue) {
    const searchEnabled = this.option("searchEnabled");
    const previousSelectAllEnabled = this._selectAllEnabled(previousValue);
    const previousItemsContainer = this._itemContainer(searchEnabled, previousSelectAllEnabled);
    this._detachClickEvent(previousItemsContainer);
    this._detachExpandEvent(previousItemsContainer);
    if ("none" === previousValue || "none" === value) {
      return;
    }
    const selectAllExists = this._$selectAllItem && this._$selectAllItem.length;
    switch (value) {
      case "selectAll":
        if (!selectAllExists) {
          this._createSelectAllValueChangedAction();
          this._renderSelectAllItem();
        }
        break;
      case "normal":
        if (selectAllExists) {
          this._$selectAllItem.remove();
          delete this._$selectAllItem;
        }
    }
  },
  _removeSelection() {
    const that = this;
    each(this._dataAdapter.getFullData(), (_, node) => {
      if (!that._hasChildren(node)) {
        return;
      }
      that._dataAdapter.toggleSelection(node.internalFields.key, false, true);
    });
  },
  _optionChanged(args) {
    const {
      name,
      value,
      previousValue
    } = args;
    switch (name) {
      case "selectAllText":
        if (this._$selectAllItem) {
          this._$selectAllItem.dxCheckBox("instance").option("text", value);
        }
        break;
      case "showCheckBoxesMode":
        this._checkBoxModeChange(value, previousValue);
        this._invalidate();
        break;
      case "scrollDirection":
        this.getScrollable().option("direction", value);
        break;
      case "useNativeScrolling":
        this.getScrollable().option("useNative", value);
        break;
      case "items":
        delete this._$selectAllItem;
        this.callBase(args);
        break;
      case "dataSource":
        this.callBase(args);
        this._initDataAdapter();
        this._filter = {};
        break;
      case "hasItemsExpr":
        this._initAccessors();
        this.repaint();
        break;
      case "expandEvent":
        this._attachExpandEvent();
        break;
      case "deferRendering":
      case "dataStructure":
      case "rootValue":
      case "createChildren":
      case "expandNodesRecursive":
      case "onItemSelectionChanged":
      case "onItemExpanded":
      case "onItemCollapsed":
      case "expandAllEnabled":
      case "animationEnabled":
      case "virtualModeEnabled":
      case "selectByClick":
      case "_supportItemUrl":
        break;
      case "selectionMode":
        this._initDataAdapter();
        this.callBase(args);
        break;
      case "onSelectAllValueChanged":
        this._createSelectAllValueChangedAction();
        break;
      case "selectNodesRecursive":
        this._dataAdapter.setOption("recursiveSelection", args.value);
        this.repaint();
        break;
      case "expandIcon":
      case "collapseIcon":
        this.repaint();
        break;
      default:
        this.callBase(args);
    }
  },
  _initDataSource() {
    if (this._useCustomChildrenLoader()) {
      this._loadChildrenByCustomLoader(null).done((newItems) => {
        if (newItems && newItems.length) {
          this.option("items", newItems);
        }
      });
    } else {
      this.callBase();
      this._isVirtualMode() && this._initVirtualMode();
    }
  },
  _initVirtualMode() {
    const filter = this._filter;
    if (!filter.custom) {
      filter.custom = this._dataSource.filter();
    }
    if (!filter.internal) {
      filter.internal = [this.option("parentIdExpr"), this.option("rootValue")];
    }
  },
  _useCustomChildrenLoader() {
    return isFunction(this.option("createChildren")) && this._isDataStructurePlain();
  },
  _loadChildrenByCustomLoader(parentNode) {
    const invocationResult = this.option("createChildren").call(this, parentNode);
    if (Array.isArray(invocationResult)) {
      return Deferred().resolve(invocationResult).promise();
    }
    if (invocationResult && isFunction(invocationResult.then)) {
      return fromPromise(invocationResult);
    }
    return Deferred().resolve([]).promise();
  },
  _combineFilter() {
    if (!this._filter.custom || !this._filter.custom.length) {
      return this._filter.internal;
    }
    return [this._filter.custom, this._filter.internal];
  },
  _dataSourceLoadErrorHandler() {
    this._renderEmptyMessage();
  },
  _init() {
    this._filter = {};
    this.callBase();
    this._initStoreChangeHandlers();
  },
  _dataSourceChangedHandler(newItems) {
    const items = this.option("items");
    if (this._initialized && this._isVirtualMode() && items.length) {
      return;
    }
    this.option("items", newItems);
  },
  _removeTreeViewLoadIndicator() {
    if (!this._treeViewLoadIndicator) {
      return;
    }
    this._treeViewLoadIndicator.remove();
    this._treeViewLoadIndicator = null;
  },
  _createTreeViewLoadIndicator() {
    this._treeViewLoadIndicator = renderer_default("<div>").addClass(LOAD_INDICATOR_CLASS);
    this._createComponent(this._treeViewLoadIndicator, load_indicator_default, {});
    return this._treeViewLoadIndicator;
  },
  _dataSourceLoadingChangedHandler(isLoading) {
    let resultFilter;
    if (this._isVirtualMode()) {
      resultFilter = this._combineFilter();
      this._dataSource.filter(resultFilter);
    }
    if (isLoading && !this._dataSource.isLoaded()) {
      this.option("items", []);
      const $wrapper = renderer_default("<div>").addClass(LOAD_INDICATOR_WRAPPER_CLASS);
      this._createTreeViewLoadIndicator().appendTo($wrapper);
      this.itemsContainer().append($wrapper);
      if (this._isVirtualMode() && this._dataSource.filter() !== resultFilter) {
        this._dataSource.filter([]);
      }
    } else {
      this._removeTreeViewLoadIndicator();
    }
  },
  _initStoreChangeHandlers() {
    if ("plain" !== this.option("dataStructure")) {
      return;
    }
    this._dataSource && this._dataSource.store().on("inserted", (newItem) => {
      this.option().items = this.option("items").concat(newItem);
      this._dataAdapter.addItem(newItem);
      if (!this._dataAdapter.isFiltered(newItem)) {
        return;
      }
      this._updateLevel(this._parentIdGetter(newItem));
    }).on("removed", (removedKey) => {
      const node = this._dataAdapter.getNodeByKey(removedKey);
      if (isDefined(node)) {
        this.option("items")[this._dataAdapter.getIndexByKey(node.internalFields.key)] = 0;
        this._markChildrenItemsToRemove(node);
        this._removeItems();
        this._dataAdapter.removeItem(removedKey);
        this._updateLevel(this._parentIdGetter(node));
      }
    });
  },
  _markChildrenItemsToRemove(node) {
    const keys = node.internalFields.childrenKeys;
    each(keys, (_, key) => {
      this.option("items")[this._dataAdapter.getIndexByKey(key)] = 0;
      this._markChildrenItemsToRemove(this._dataAdapter.getNodeByKey(key));
    });
  },
  _removeItems() {
    const items = extend(true, [], this.option("items"));
    let counter = 0;
    each(items, (index, item) => {
      if (!item) {
        this.option("items").splice(index - counter, 1);
        counter++;
      }
    });
  },
  _updateLevel(parentId) {
    const $container = this._getContainerByParentKey(parentId);
    this._renderItems($container, this._dataAdapter.getChildrenNodes(parentId));
  },
  _getOldContainer($itemElement) {
    if ($itemElement.length) {
      return $itemElement.children(`.${NODE_CONTAINER_CLASS}`);
    }
    const scrollable = this.getScrollable();
    if (scrollable) {
      return renderer_default(scrollable.content()).children();
    }
    return renderer_default();
  },
  _getContainerByParentKey(parentId) {
    const node = this._dataAdapter.getNodeByKey(parentId);
    const $itemElement = node ? this._getNodeElement(node) : [];
    this._getOldContainer($itemElement).remove();
    const $container = this._renderNodeContainer($itemElement);
    if (this._isRootLevel(parentId)) {
      const scrollable = this.getScrollable();
      if (!scrollable) {
        this._renderScrollableContainer();
      }
      renderer_default(scrollable.content()).append($container);
    }
    return $container;
  },
  _isRootLevel(parentId) {
    return parentId === this.option("rootValue");
  },
  _getAccessors() {
    const accessors = this.callBase();
    accessors.push("hasItems");
    return accessors;
  },
  _getDataAdapterOptions() {
    var _this$_dataSource, _this$_dataSource$loa;
    return {
      rootValue: this.option("rootValue"),
      multipleSelection: !this._isSingleSelection(),
      recursiveSelection: this._isRecursiveSelection(),
      recursiveExpansion: this.option("expandNodesRecursive"),
      selectionRequired: this.option("selectionRequired"),
      dataType: this.option("dataStructure"),
      sort: this._dataSource && this._dataSource.sort(),
      langParams: null === (_this$_dataSource = this._dataSource) || void 0 === _this$_dataSource || null === (_this$_dataSource$loa = _this$_dataSource.loadOptions) || void 0 === _this$_dataSource$loa || null === (_this$_dataSource$loa = _this$_dataSource$loa.call(_this$_dataSource)) || void 0 === _this$_dataSource$loa ? void 0 : _this$_dataSource$loa.langParams
    };
  },
  _initMarkup() {
    this._renderScrollableContainer();
    this._renderEmptyMessage(this._dataAdapter.getRootNodes());
    this.callBase();
    this._setAriaRole();
  },
  _setAriaRole() {
    const {
      items
    } = this.option();
    if (null !== items && void 0 !== items && items.length) {
      this.setAria({
        role: "tree"
      });
    }
  },
  _renderContentImpl() {
    const $nodeContainer = this._renderNodeContainer();
    renderer_default(this.getScrollable().content()).append($nodeContainer);
    if (!this.option("items") || !this.option("items").length) {
      return;
    }
    this._renderItems($nodeContainer, this._dataAdapter.getRootNodes());
    this._attachExpandEvent();
    if (this._selectAllEnabled()) {
      this._createSelectAllValueChangedAction();
      this._renderSelectAllItem($nodeContainer);
    }
  },
  _isVirtualMode() {
    return this.option("virtualModeEnabled") && this._isDataStructurePlain() && !!this.option("dataSource");
  },
  _isDataStructurePlain() {
    return "plain" === this.option("dataStructure");
  },
  _fireContentReadyAction() {
    const dataSource = this.getDataSource();
    const skipContentReadyAction = dataSource && !dataSource.isLoaded() || this._skipContentReadyAndItemExpanded;
    const scrollable = this.getScrollable();
    if (scrollable && hasWindow()) {
      scrollable.update();
    }
    if (!skipContentReadyAction) {
      this.callBase();
    }
    if (scrollable && hasWindow()) {
      scrollable.update();
    }
  },
  _renderScrollableContainer() {
    this._scrollable = this._createComponent(renderer_default("<div>").appendTo(this.$element()), ui_scrollable_default, {
      useNative: this.option("useNativeScrolling"),
      direction: this.option("scrollDirection"),
      useKeyboard: false
    });
  },
  _renderNodeContainer($parent) {
    const $container = renderer_default("<ul>").addClass(NODE_CONTAINER_CLASS);
    this.setAria("role", "group", $container);
    if ($parent && $parent.length) {
      const itemData = this._getItemData($parent.children(`.${ITEM_CLASS}`));
      if (this._expandedGetter(itemData)) {
        $container.addClass(OPENED_NODE_CONTAINER_CLASS);
      }
      $container.appendTo($parent);
    }
    return $container;
  },
  _createDOMElement($nodeContainer, node) {
    var _node$internalFields;
    const $node = renderer_default("<li>").addClass(NODE_CLASS).attr(DATA_ITEM_ID, this._encodeString(node.internalFields.key)).prependTo($nodeContainer);
    const attrs = {
      role: "treeitem",
      label: this._displayGetter(node.internalFields.item) || "",
      level: this._getLevel($nodeContainer)
    };
    const hasChildNodes = !!(null !== node && void 0 !== node && null !== (_node$internalFields = node.internalFields) && void 0 !== _node$internalFields && null !== (_node$internalFields = _node$internalFields.childrenKeys) && void 0 !== _node$internalFields && _node$internalFields.length);
    if (hasChildNodes) {
      attrs.expanded = node.internalFields.expanded || false;
    }
    this.setAria(attrs, $node);
    return $node;
  },
  _getLevel($nodeContainer) {
    const parent = $nodeContainer.parent();
    return parent.hasClass("dx-scrollable-content") ? 1 : parseInt(parent.attr("aria-level")) + 1;
  },
  _showCheckboxes() {
    return "none" !== this.option("showCheckBoxesMode");
  },
  _hasCustomExpanderIcons() {
    return this.option("expandIcon") || this.option("collapseIcon");
  },
  _selectAllEnabled(showCheckBoxesMode) {
    const mode = showCheckBoxesMode ?? this.option("showCheckBoxesMode");
    return "selectAll" === mode && !this._isSingleSelection();
  },
  _renderItems($nodeContainer, nodes) {
    const length = nodes.length - 1;
    for (let i = length; i >= 0; i--) {
      this._renderItem(i, nodes[i], $nodeContainer);
    }
    this._renderedItemsCount += nodes.length;
  },
  _renderItem(nodeIndex, node, $nodeContainer) {
    const $node = this._createDOMElement($nodeContainer, node);
    const nodeData = node.internalFields;
    const showCheckBox = this._showCheckboxes();
    $node.addClass(showCheckBox ? ITEM_WITH_CHECKBOX_CLASS : ITEM_WITHOUT_CHECKBOX_CLASS);
    $node.toggleClass("dx-state-invisible", false === nodeData.item.visible);
    if (this._hasCustomExpanderIcons()) {
      $node.addClass(ITEM_WITH_CUSTOM_EXPANDER_ICON_CLASS);
      $nodeContainer.addClass(CUSTOM_EXPANDER_ICON_ITEM_CONTAINER_CLASS);
    }
    this.setAria("selected", nodeData.selected, $node);
    this._toggleSelectedClass($node, nodeData.selected);
    if (nodeData.disabled) {
      this.setAria("disabled", nodeData.disabled, $node);
    }
    this.callBase(this._renderedItemsCount + nodeIndex, nodeData.item, $node);
    const parent = this._getNode(node.internalFields.parentKey);
    if (!parent) {
      $node.addClass(ROOT_NODE_CLASS);
    }
    if (false !== nodeData.item.visible) {
      this._renderChildren($node, node);
    }
  },
  _setAriaSelectionAttribute: noop,
  _renderChildren($node, node) {
    if (!this._hasChildren(node)) {
      this._addLeafClass($node);
      renderer_default("<div>").addClass(EXPANDER_ICON_STUB_CLASS).appendTo(this._getItem($node));
      return;
    }
    if (this._hasCustomExpanderIcons()) {
      this._renderCustomExpanderIcons($node, node);
    } else {
      this._renderDefaultExpanderIcons($node, node);
    }
    if (this._shouldRenderSublevel(node.internalFields.expanded)) {
      this._loadSublevel(node).done((childNodes) => {
        this._renderSublevel($node, this._getActualNode(node), childNodes);
      });
    }
  },
  _shouldRenderSublevel(expanded) {
    return expanded || !this.option("deferRendering");
  },
  _getActualNode(cachedNode) {
    return this._dataAdapter.getNodeByKey(cachedNode.internalFields.key);
  },
  _hasChildren(node) {
    if (this._isVirtualMode() || this._useCustomChildrenLoader()) {
      return false !== this._hasItemsGetter(node.internalFields.item);
    }
    return this.callBase(node);
  },
  _loadSublevel(node) {
    const deferred = Deferred();
    const childrenNodes = this._getChildNodes(node);
    if (childrenNodes.length) {
      deferred.resolve(childrenNodes);
    } else {
      this._loadNestedItems(node).done((items) => {
        deferred.resolve(this._dataAdapter.getNodesByItems(items));
      });
    }
    return deferred.promise();
  },
  _getItemExtraPropNames: () => ["url", "linkAttr"],
  _addContent($container, itemData) {
    const {
      html,
      url
    } = itemData;
    if (this.option("_supportItemUrl") && url) {
      $container.html(html);
      const link = this._getLinkContainer(this._getIconContainer(itemData), this._getTextContainer(itemData), itemData);
      $container.append(link);
    } else {
      this.callBase($container, itemData);
    }
  },
  _postprocessRenderItem(args) {
    const {
      itemData,
      itemElement
    } = args;
    if (this._showCheckboxes()) {
      this._renderCheckBox(itemElement, this._getNode(itemData));
    }
    this.callBase(args);
  },
  _renderSublevel($node, node, childNodes) {
    const $nestedNodeContainer = this._renderNodeContainer($node, node);
    const childNodesByChildrenKeys = childNodes.filter((childNode) => -1 !== node.internalFields.childrenKeys.indexOf(childNode.internalFields.key));
    this._renderItems($nestedNodeContainer, childNodesByChildrenKeys);
    if (childNodesByChildrenKeys.length && !node.internalFields.selected) {
      const firstChild = childNodesByChildrenKeys[0];
      this._updateParentsState(firstChild, this._getNodeElement(firstChild));
    }
    this._normalizeIconState($node, childNodesByChildrenKeys.length);
    if (node.internalFields.expanded) {
      $nestedNodeContainer.addClass(OPENED_NODE_CONTAINER_CLASS);
    }
  },
  _executeItemRenderAction(itemIndex, itemData, itemElement) {
    const node = this._getNode(itemElement);
    this._getItemRenderAction()({
      itemElement,
      itemIndex,
      itemData,
      node: this._dataAdapter.getPublicNode(node)
    });
  },
  _addLeafClass($node) {
    $node.addClass(IS_LEAF);
  },
  _expandEventHandler(e) {
    const $nodeElement = renderer_default(e.currentTarget.parentNode);
    if (!$nodeElement.hasClass(IS_LEAF)) {
      this._toggleExpandedState(e.currentTarget, void 0, e);
    }
  },
  _attachExpandEvent() {
    const expandedEventName = this._getEventNameByOption(this.option("expandEvent"));
    const $itemsContainer = this._itemContainer();
    this._detachExpandEvent($itemsContainer);
    events_engine_default.on($itemsContainer, expandedEventName, this._itemSelector(), this._expandEventHandler.bind(this));
  },
  _detachExpandEvent(itemsContainer) {
    events_engine_default.off(itemsContainer, ".dxTreeView_expand", this._itemSelector());
  },
  _getEventNameByOption(name) {
    const event = "click" === name ? CLICK_EVENT_NAME : DBLCLICK_EVENT_NAME;
    return addNamespace(event, "dxTreeView_expand");
  },
  _getNode(identifier) {
    if (!isDefined(identifier)) {
      return null;
    }
    if (identifier.internalFields) {
      return identifier;
    }
    if (isPrimitive(identifier)) {
      return this._dataAdapter.getNodeByKey(identifier);
    }
    const itemElement = renderer_default(identifier).get(0);
    if (!itemElement) {
      return null;
    }
    if (dom_adapter_default.isElementNode(itemElement)) {
      return this._getNodeByElement(itemElement);
    }
    return this._dataAdapter.getNodeByItem(itemElement);
  },
  _getNodeByElement(itemElement) {
    const $node = renderer_default(itemElement).closest(`.${NODE_CLASS}`);
    const key = this._decodeString($node.attr(DATA_ITEM_ID));
    return this._dataAdapter.getNodeByKey(key);
  },
  _toggleExpandedState(itemElement, state, e) {
    const node = this._getNode(itemElement);
    if (!node) {
      return Deferred().reject().promise();
    }
    if (node.internalFields.disabled) {
      return Deferred().reject().promise();
    }
    const currentState = node.internalFields.expanded;
    if (currentState === state) {
      return Deferred().resolve().promise();
    }
    if (this._hasChildren(node)) {
      const $node = this._getNodeElement(node);
      if ($node.find(`.${NODE_LOAD_INDICATOR_CLASS}:not(.dx-state-invisible)`).length) {
        return Deferred().reject().promise();
      }
      if (!currentState && !this._nodeHasRenderedChildren($node)) {
        this._createLoadIndicator($node);
      }
    }
    if (!isDefined(state)) {
      state = !currentState;
    }
    this._dataAdapter.toggleExpansion(node.internalFields.key, state);
    return this._updateExpandedItemsUI(node, state, e);
  },
  _nodeHasRenderedChildren($node) {
    const $nodeContainer = $node.children(`.${NODE_CONTAINER_CLASS}`);
    return $nodeContainer.not(":empty").length;
  },
  _getItem: ($node) => $node.children(`.${ITEM_CLASS}`).eq(0),
  _createLoadIndicator($node) {
    const $treeviewItem = this._getItem($node);
    this._createComponent(renderer_default("<div>").addClass(NODE_LOAD_INDICATOR_CLASS), load_indicator_default, {}).$element().appendTo($treeviewItem);
    const $icon = $treeviewItem.children(`.${TOGGLE_ITEM_VISIBILITY_CLASS},.${CUSTOM_EXPAND_ICON_CLASS}`);
    $icon.hide();
  },
  _renderExpanderIcon($node, node, $icon, iconClass) {
    $icon.appendTo(this._getItem($node));
    $icon.addClass(iconClass);
    if (node.internalFields.disabled) {
      $icon.addClass("dx-state-disabled");
    }
    this._renderToggleItemVisibilityIconClick($icon, node);
  },
  _renderDefaultExpanderIcons($node, node) {
    const $treeViewItem = this._getItem($node);
    const $icon = renderer_default("<div>").addClass(TOGGLE_ITEM_VISIBILITY_CLASS).appendTo($treeViewItem);
    if (node.internalFields.expanded) {
      $icon.addClass(TOGGLE_ITEM_VISIBILITY_OPENED_CLASS);
      $node.parent().addClass(OPENED_NODE_CONTAINER_CLASS);
    }
    if (node.internalFields.disabled) {
      $icon.addClass("dx-state-disabled");
    }
    this._renderToggleItemVisibilityIconClick($icon, node);
  },
  _renderCustomExpanderIcons($node, node) {
    const {
      expandIcon,
      collapseIcon
    } = this.option();
    const $expandIcon = getImageContainer(expandIcon ?? collapseIcon);
    const $collapseIcon = getImageContainer(collapseIcon ?? expandIcon);
    this._renderExpanderIcon($node, node, $expandIcon, CUSTOM_EXPAND_ICON_CLASS);
    this._renderExpanderIcon($node, node, $collapseIcon, CUSTOM_COLLAPSE_ICON_CLASS);
    const isNodeExpanded = node.internalFields.expanded;
    if (isNodeExpanded) {
      $node.parent().addClass(OPENED_NODE_CONTAINER_CLASS);
    }
    this._toggleCustomExpanderIcons($expandIcon, $collapseIcon, isNodeExpanded);
  },
  _renderToggleItemVisibilityIconClick($icon, node) {
    const eventName = addNamespace(CLICK_EVENT_NAME, this.NAME);
    events_engine_default.off($icon, eventName);
    events_engine_default.on($icon, eventName, (e) => {
      this._toggleExpandedState(node.internalFields.key, void 0, e);
      return false;
    });
  },
  _toggleCustomExpanderIcons($expandIcon, $collapseIcon, isNodeExpanded) {
    $collapseIcon.toggle(isNodeExpanded);
    $expandIcon.toggle(!isNodeExpanded);
  },
  _updateExpandedItemsUI(node, state, e) {
    const $node = this._getNodeElement(node);
    const isHiddenNode = !$node.length || state && $node.is(":hidden");
    if (this.option("expandNodesRecursive") && isHiddenNode) {
      const parentNode = this._getNode(node.internalFields.parentKey);
      if (parentNode) {
        this._updateExpandedItemsUI(parentNode, state, e);
      }
    }
    if (!this._hasCustomExpanderIcons()) {
      const $icon = this._getItem($node).children(`.${TOGGLE_ITEM_VISIBILITY_CLASS}`);
      $icon.toggleClass(TOGGLE_ITEM_VISIBILITY_OPENED_CLASS, state);
    } else if (this._nodeHasRenderedChildren($node)) {
      const $item = this._getItem($node);
      const $childExpandIcons = $item.children(`.${CUSTOM_EXPAND_ICON_CLASS}`);
      const $childCollapseIcons = $item.children(`.${CUSTOM_COLLAPSE_ICON_CLASS}`);
      this._toggleCustomExpanderIcons($childExpandIcons, $childCollapseIcons, state);
    }
    const $nodeContainer = $node.children(`.${NODE_CONTAINER_CLASS}`);
    const nodeContainerExists = $nodeContainer.length > 0;
    const completionCallback = Deferred();
    if (!state || nodeContainerExists && !$nodeContainer.is(":empty")) {
      this._animateNodeContainer(node, state, e, completionCallback);
      return completionCallback.promise();
    }
    if (0 === node.internalFields.childrenKeys.length && (this._isVirtualMode() || this._useCustomChildrenLoader())) {
      this._loadNestedItemsWithUpdate(node, state, e, completionCallback);
      return completionCallback.promise();
    }
    this._renderSublevel($node, node, this._getChildNodes(node));
    this._fireContentReadyAction();
    this._animateNodeContainer(node, state, e, completionCallback);
    return completionCallback.promise();
  },
  _loadNestedItemsWithUpdate(node, state, e, completionCallback) {
    const $node = this._getNodeElement(node);
    this._loadNestedItems(node).done((items) => {
      const actualNodeData = this._getActualNode(node);
      this._renderSublevel($node, actualNodeData, this._dataAdapter.getNodesByItems(items));
      if (!items || !items.length) {
        completionCallback.resolve();
        return;
      }
      this._fireContentReadyAction();
      this._animateNodeContainer(actualNodeData, state, e, completionCallback);
    });
  },
  _loadNestedItems(node) {
    if (this._useCustomChildrenLoader()) {
      const publicNode = this._dataAdapter.getPublicNode(node);
      return this._loadChildrenByCustomLoader(publicNode).done((newItems) => {
        if (!this._areNodesExists(newItems)) {
          this._appendItems(newItems);
        }
      });
    }
    if (!this._isVirtualMode()) {
      return Deferred().resolve([]).promise();
    }
    this._filter.internal = [this.option("parentIdExpr"), node.internalFields.key];
    this._dataSource.filter(this._combineFilter());
    return this._dataSource.load().done((newItems) => {
      if (!this._areNodesExists(newItems)) {
        this._appendItems(newItems);
      }
    });
  },
  _areNodesExists(newItems, items) {
    const keyOfRootItem = this.keyOf(newItems[0]);
    const fullData = this._dataAdapter.getFullData();
    return !!this._dataAdapter.getNodeByKey(keyOfRootItem, fullData);
  },
  _appendItems(newItems) {
    this.option().items = this.option("items").concat(newItems);
    this._initDataAdapter();
  },
  _animateNodeContainer(node, state, e, completionCallback) {
    const $node = this._getNodeElement(node);
    const $nodeContainer = $node.children(`.${NODE_CONTAINER_CLASS}`);
    if (node && completionCallback && 0 === $nodeContainer.length) {
      completionCallback.resolve();
    }
    $nodeContainer.addClass(OPENED_NODE_CONTAINER_CLASS);
    const nodeHeight = getHeight($nodeContainer);
    fx_default.stop($nodeContainer, true);
    fx_default.animate($nodeContainer, {
      type: "custom",
      duration: this.option("animationEnabled") ? 400 : 0,
      from: {
        maxHeight: state ? 0 : nodeHeight
      },
      to: {
        maxHeight: state ? nodeHeight : 0
      },
      complete: (function() {
        $nodeContainer.css("maxHeight", "none");
        $nodeContainer.toggleClass(OPENED_NODE_CONTAINER_CLASS, state);
        this.setAria("expanded", state, $node);
        this.getScrollable().update();
        this._fireExpandedStateUpdatedEvent(state, node, e);
        if (completionCallback) {
          completionCallback.resolve();
        }
      }).bind(this)
    });
  },
  _fireExpandedStateUpdatedEvent(isExpanded, node, e) {
    if (!this._hasChildren(node) || this._skipContentReadyAndItemExpanded) {
      return;
    }
    const optionName = isExpanded ? "onItemExpanded" : "onItemCollapsed";
    if (isDefined(e)) {
      this._itemDXEventHandler(e, optionName, {
        node: this._dataAdapter.getPublicNode(node)
      });
    } else {
      const target = this._getNodeElement(node);
      this._itemEventHandler(target, optionName, {
        event: e,
        node: this._dataAdapter.getPublicNode(node)
      });
    }
  },
  _normalizeIconState($node, hasNewItems) {
    const $loadIndicator = $node.find(`.${NODE_LOAD_INDICATOR_CLASS}`);
    if ($loadIndicator.length) {
      var _LoadIndicator$getIns;
      null === (_LoadIndicator$getIns = load_indicator_default.getInstance($loadIndicator)) || void 0 === _LoadIndicator$getIns || _LoadIndicator$getIns.option("visible", false);
    }
    const $treeViewItem = this._getItem($node);
    const $toggleItem = $treeViewItem.children(`.${CUSTOM_COLLAPSE_ICON_CLASS},.${TOGGLE_ITEM_VISIBILITY_CLASS}`);
    if (hasNewItems) {
      $toggleItem.show();
      return;
    }
    $toggleItem.removeClass(TOGGLE_ITEM_VISIBILITY_CLASS);
    $node.addClass(IS_LEAF);
  },
  _emptyMessageContainer() {
    const scrollable = this.getScrollable();
    return scrollable ? renderer_default(scrollable.content()) : this.callBase();
  },
  _renderContent() {
    const items = this.option("items");
    if (items && items.length) {
      this._contentAlreadyRendered = true;
    }
    this.callBase();
  },
  _renderSelectAllItem($container) {
    const {
      selectAllText,
      focusStateEnabled
    } = this.option();
    $container = $container || this.$element().find(`.${NODE_CONTAINER_CLASS}`).first();
    this._$selectAllItem = renderer_default("<div>").addClass(SELECT_ALL_ITEM_CLASS);
    const value = this._dataAdapter.isAllSelected();
    this._createComponent(this._$selectAllItem, check_box_default, {
      value,
      elementAttr: {
        "aria-label": "Select All"
      },
      text: selectAllText,
      focusStateEnabled,
      onValueChanged: this._onSelectAllCheckboxValueChanged.bind(this),
      onInitialized: (_ref) => {
        let {
          component
        } = _ref;
        component.registerKeyHandler("enter", () => {
          component.option("value", !component.option("value"));
        });
      }
    });
    this._toggleSelectedClass(this._$selectAllItem, value);
    $container.before(this._$selectAllItem);
  },
  _onSelectAllCheckboxValueChanged(args) {
    this._toggleSelectAll(args);
    this._fireSelectAllValueChanged(args.value);
  },
  _toggleSelectAll(args) {
    this._dataAdapter.toggleSelectAll(args.value);
    this._updateItemsUI();
    this._fireSelectionChanged();
  },
  _renderCheckBox($node, node) {
    const $checkbox = renderer_default("<div>").appendTo($node);
    this._createComponent($checkbox, check_box_default, {
      value: node.internalFields.selected,
      onValueChanged: this._changeCheckboxValue.bind(this),
      focusStateEnabled: false,
      elementAttr: {
        "aria-label": "Check State"
      },
      disabled: this._disabledGetter(node)
    });
  },
  _toggleSelectedClass($node, value) {
    $node.toggleClass("dx-state-selected", !!value);
  },
  _toggleNodeDisabledState(node, state) {
    const $node = this._getNodeElement(node);
    const $item = $node.find(`.${ITEM_CLASS}`).eq(0);
    this._dataAdapter.toggleNodeDisabledState(node.internalFields.key, state);
    $item.toggleClass("dx-state-disabled", !!state);
    if (this._showCheckboxes()) {
      const checkbox = this._getCheckBoxInstance($node);
      checkbox.option("disabled", !!state);
    }
  },
  _itemOptionChanged(item, property, value) {
    const node = this._dataAdapter.getNodeByItem(item);
    if (property === this.option("disabledExpr")) {
      this._toggleNodeDisabledState(node, value);
    }
  },
  _changeCheckboxValue(e) {
    const $node = renderer_default(e.element).closest(`.${NODE_CLASS}`);
    const $item = this._getItem($node);
    const item = this._getItemData($item);
    const node = this._getNodeByElement($item);
    const {
      value
    } = e;
    if (node && node.internalFields.selected === value) {
      return;
    }
    this._updateItemSelection(value, item, e.event);
  },
  _isSingleSelection() {
    return "single" === this.option("selectionMode");
  },
  _isRecursiveSelection() {
    return this.option("selectNodesRecursive") && "single" !== this.option("selectionMode");
  },
  _isLastSelectedBranch(publicNode, selectedNodesKeys, deep) {
    const keyIndex = selectedNodesKeys.indexOf(publicNode.key);
    if (keyIndex >= 0) {
      selectedNodesKeys.splice(keyIndex, 1);
    }
    if (deep) {
      each(publicNode.children, (_, childNode) => {
        this._isLastSelectedBranch(childNode, selectedNodesKeys, true);
      });
    }
    if (publicNode.parent) {
      this._isLastSelectedBranch(publicNode.parent, selectedNodesKeys);
    }
    return 0 === selectedNodesKeys.length;
  },
  _isLastRequired(node) {
    const selectionRequired = this.option("selectionRequired");
    const isSingleMode = this._isSingleSelection();
    const selectedNodesKeys = this.getSelectedNodeKeys();
    if (!selectionRequired) {
      return;
    }
    if (isSingleMode) {
      return 1 === selectedNodesKeys.length;
    }
    return this._isLastSelectedBranch(node.internalFields.publicNode, selectedNodesKeys.slice(), true);
  },
  _updateItemSelection(value, itemElement, dxEvent) {
    const node = this._getNode(itemElement);
    if (!node || false === node.visible) {
      return false;
    }
    if (node.internalFields.selected === value) {
      return true;
    }
    if (!value && this._isLastRequired(node)) {
      if (this._showCheckboxes()) {
        const $node = this._getNodeElement(node);
        this._getCheckBoxInstance($node).option("value", true);
      }
      return false;
    }
    if (value && this._isSingleSelection()) {
      const selectedKeys = this.getSelectedNodeKeys();
      each(selectedKeys, (index, key) => {
        this._dataAdapter.toggleSelection(key, false);
        this._updateItemsUI();
        this._fireItemSelectionChanged(this._getNode(key));
      });
    }
    this._dataAdapter.toggleSelection(node.internalFields.key, value);
    const isAllSelected = this._dataAdapter.isAllSelected();
    const needFireSelectAllChanged = this._selectAllEnabled() && this._$selectAllItem.dxCheckBox("instance").option("value") !== isAllSelected;
    this._updateItemsUI();
    this._fireItemSelectionChanged(node, dxEvent);
    this._fireSelectionChanged();
    if (needFireSelectAllChanged) {
      this._fireSelectAllValueChanged(isAllSelected);
    }
    return true;
  },
  _fireItemSelectionChanged(node, dxEvent) {
    const initiator = dxEvent || this._findItemElementByItem(node.internalFields.item);
    const handler = dxEvent ? this._itemDXEventHandler : this._itemEventHandler;
    handler.call(this, initiator, "onItemSelectionChanged", {
      node: this._dataAdapter.getPublicNode(node),
      itemData: node.internalFields.item
    });
  },
  _getCheckBoxInstance($node) {
    const $treeViewItem = this._getItem($node);
    return $treeViewItem.children(".dx-checkbox").dxCheckBox("instance");
  },
  _updateItemsUI() {
    const cache = {};
    each(this._dataAdapter.getData(), (_, node) => {
      const $node = this._getNodeElement(node, cache);
      const nodeSelection = node.internalFields.selected;
      if (!$node.length) {
        return;
      }
      this._toggleSelectedClass($node, nodeSelection);
      this.setAria("selected", nodeSelection, $node);
      if (this._showCheckboxes()) {
        this._getCheckBoxInstance($node).option("value", nodeSelection);
      }
    });
    if (this._selectAllEnabled()) {
      const selectAllCheckbox = this._$selectAllItem.dxCheckBox("instance");
      selectAllCheckbox.option("onValueChanged", void 0);
      selectAllCheckbox.option("value", this._dataAdapter.isAllSelected());
      selectAllCheckbox.option("onValueChanged", this._onSelectAllCheckboxValueChanged.bind(this));
    }
  },
  _updateParentsState(node, $node) {
    if (!$node) {
      return;
    }
    const parentNode = this._dataAdapter.getNodeByKey(node.internalFields.parentKey);
    const $parentNode = renderer_default($node.parents(`.${NODE_CLASS}`)[0]);
    if (this._showCheckboxes()) {
      const parentValue = parentNode.internalFields.selected;
      this._getCheckBoxInstance($parentNode).option("value", parentValue);
      this._toggleSelectedClass($parentNode, parentValue);
    }
    if (parentNode.internalFields.parentKey !== this.option("rootValue")) {
      this._updateParentsState(parentNode, $parentNode);
    }
  },
  _itemEventHandlerImpl(initiator, action, actionArgs) {
    const $itemElement = renderer_default(initiator).closest(`.${NODE_CLASS}`).children(`.${ITEM_CLASS}`);
    return action(extend(this._extendActionArgs($itemElement), actionArgs));
  },
  _itemContextMenuHandler(e) {
    this._createEventHandler("onItemContextMenu", e);
  },
  _itemHoldHandler(e) {
    this._createEventHandler("onItemHold", e);
  },
  _createEventHandler(eventName, e) {
    const node = this._getNodeByElement(e.currentTarget);
    this._itemDXEventHandler(e, eventName, {
      node: this._dataAdapter.getPublicNode(node)
    });
  },
  _itemClass: () => ITEM_CLASS,
  _itemDataKey: () => ITEM_DATA_KEY,
  _attachClickEvent() {
    const $itemContainer = this._itemContainer();
    this._detachClickEvent($itemContainer);
    const {
      clickEventNamespace,
      itemSelector,
      pointerDownEventNamespace,
      nodeSelector
    } = this._getItemClickEventData();
    events_engine_default.on($itemContainer, clickEventNamespace, itemSelector, (e) => {
      if (renderer_default(e.target).hasClass("dx-checkbox-icon") || renderer_default(e.target).hasClass("dx-checkbox")) {
        return;
      }
      this._itemClickHandler(e, renderer_default(e.currentTarget));
    });
    events_engine_default.on($itemContainer, pointerDownEventNamespace, nodeSelector, (e) => {
      this._itemPointerDownHandler(e);
    });
  },
  _detachClickEvent(itemsContainer) {
    const {
      clickEventNamespace,
      itemSelector,
      pointerDownEventNamespace,
      nodeSelector
    } = this._getItemClickEventData();
    events_engine_default.off(itemsContainer, clickEventNamespace, itemSelector);
    events_engine_default.off(itemsContainer, pointerDownEventNamespace, nodeSelector);
  },
  _getItemClickEventData() {
    const itemSelector = `.${this._itemClass()}`;
    const nodeSelector = `.${NODE_CLASS}, .${SELECT_ALL_ITEM_CLASS}`;
    const clickEventNamespace = addNamespace(CLICK_EVENT_NAME, this.NAME);
    const pointerDownEventNamespace = addNamespace(pointer_default.down, this.NAME);
    return {
      clickEventNamespace,
      itemSelector,
      pointerDownEventNamespace,
      nodeSelector
    };
  },
  _itemClick(actionArgs) {
    const args = actionArgs.args[0];
    const target = args.event.target[0] || args.event.target;
    const link = target.getElementsByClassName("dx-item-url")[0];
    if (args.itemData.url && link) {
      link.click();
    }
  },
  _itemClickHandler(e, $item) {
    const itemData = this._getItemData($item);
    const node = this._getNodeByElement($item);
    this._itemDXEventHandler(e, "onItemClick", {
      node: this._dataAdapter.getPublicNode(node)
    }, {
      beforeExecute: this._itemClick
    });
    if (this.option("selectByClick") && !e.isDefaultPrevented()) {
      this._updateItemSelection(!node.internalFields.selected, itemData, e);
    }
  },
  _updateSelectionToFirstItem($items, startIndex) {
    let itemIndex = startIndex;
    while (itemIndex >= 0) {
      const $item = renderer_default($items[itemIndex]);
      this._updateItemSelection(true, $item.find(`.${ITEM_CLASS}`).get(0));
      itemIndex--;
    }
  },
  _updateSelectionToLastItem($items, startIndex) {
    const {
      length
    } = $items;
    let itemIndex = startIndex;
    while (itemIndex < length) {
      const $item = renderer_default($items[itemIndex]);
      this._updateItemSelection(true, $item.find(`.${ITEM_CLASS}`).get(0));
      itemIndex++;
    }
  },
  focus() {
    if (this._selectAllEnabled()) {
      events_engine_default.trigger(this._$selectAllItem, "focus");
      return;
    }
    this.callBase();
  },
  _focusInHandler(e) {
    this._updateFocusState(e, true);
    const isSelectAllItem = renderer_default(e.target).hasClass(SELECT_ALL_ITEM_CLASS);
    if (isSelectAllItem || this.option("focusedElement")) {
      clearTimeout(this._setFocusedItemTimeout);
      this._setFocusedItemTimeout = setTimeout(() => {
        const element = isSelectAllItem ? getPublicElement(this._$selectAllItem) : renderer_default(this.option("focusedElement"));
        this._setFocusedItem(element);
      });
      return;
    }
    const $activeItem = this._getActiveItem();
    this.option("focusedElement", getPublicElement($activeItem.closest(`.${NODE_CLASS}`)));
  },
  _itemPointerDownHandler(e) {
    if (!this.option("focusStateEnabled")) {
      return;
    }
    const $target = renderer_default(e.target).closest(`.${NODE_CLASS}, .${SELECT_ALL_ITEM_CLASS}`);
    if (!$target.length) {
      return;
    }
    const itemElement = $target.hasClass("dx-state-disabled") ? null : $target;
    this.option("focusedElement", getPublicElement(itemElement));
  },
  _findNonDisabledNodes: ($nodes) => $nodes.not(function() {
    return renderer_default(this).children(`.${ITEM_CLASS}`).hasClass("dx-state-disabled");
  }),
  _moveFocus(location, e) {
    const FOCUS_LEFT = this.option("rtlEnabled") ? "right" : "left";
    const FOCUS_RIGHT = this.option("rtlEnabled") ? "left" : "right";
    this.$element().find(`.${NODE_CONTAINER_CLASS}`).each(function() {
      fx_default.stop(this, true);
    });
    const $items = this._nodeElements();
    if (!$items || !$items.length) {
      return;
    }
    switch (location) {
      case "up": {
        const $prevItem = this._prevItem($items);
        this.option("focusedElement", getPublicElement($prevItem));
        const prevItemElement = this._getNodeItemElement($prevItem);
        this.getScrollable().scrollToElement(prevItemElement);
        if (e.shiftKey && this._showCheckboxes()) {
          this._updateItemSelection(true, prevItemElement);
        }
        break;
      }
      case "down": {
        const $nextItem = this._nextItem($items);
        this.option("focusedElement", getPublicElement($nextItem));
        const nextItemElement = this._getNodeItemElement($nextItem);
        this.getScrollable().scrollToElement(nextItemElement);
        if (e.shiftKey && this._showCheckboxes()) {
          this._updateItemSelection(true, nextItemElement);
        }
        break;
      }
      case "first": {
        const $firstItem = $items.first();
        if (e.shiftKey && this._showCheckboxes()) {
          this._updateSelectionToFirstItem($items, $items.index(this._prevItem($items)));
        }
        this.option("focusedElement", getPublicElement($firstItem));
        this.getScrollable().scrollToElement(this._getNodeItemElement($firstItem));
        break;
      }
      case "last": {
        const $lastItem = $items.last();
        if (e.shiftKey && this._showCheckboxes()) {
          this._updateSelectionToLastItem($items, $items.index(this._nextItem($items)));
        }
        this.option("focusedElement", getPublicElement($lastItem));
        this.getScrollable().scrollToElement(this._getNodeItemElement($lastItem));
        break;
      }
      case FOCUS_RIGHT:
        this._expandFocusedContainer();
        break;
      case FOCUS_LEFT:
        this._collapseFocusedContainer();
        break;
      default:
        this.callBase.apply(this, arguments);
    }
  },
  _getNodeItemElement: ($node) => $node.find(`.${ITEM_CLASS}`).get(0),
  _nodeElements() {
    return this.$element().find(`.${NODE_CLASS}`).not(":hidden");
  },
  _expandFocusedContainer() {
    const $focusedNode = renderer_default(this.option("focusedElement"));
    if (!$focusedNode.length || $focusedNode.hasClass(IS_LEAF)) {
      return;
    }
    const $node = $focusedNode.find(`.${NODE_CONTAINER_CLASS}`).eq(0);
    if ($node.hasClass(OPENED_NODE_CONTAINER_CLASS)) {
      const $nextItem = this._nextItem(this._findNonDisabledNodes(this._nodeElements()));
      this.option("focusedElement", getPublicElement($nextItem));
      this.getScrollable().scrollToElement(this._getNodeItemElement($nextItem));
      return;
    }
    const node = this._getNodeByElement(this._getItem($focusedNode));
    this._toggleExpandedState(node, true);
  },
  _getClosestNonDisabledNode($node) {
    do {
      $node = $node.parent().closest(`.${NODE_CLASS}`);
    } while ($node.children(".dx-treeview-item.dx-state-disabled").length);
    return $node;
  },
  _collapseFocusedContainer() {
    const $focusedNode = renderer_default(this.option("focusedElement"));
    if (!$focusedNode.length) {
      return;
    }
    const nodeElement = $focusedNode.find(`.${NODE_CONTAINER_CLASS}`).eq(0);
    if (!$focusedNode.hasClass(IS_LEAF) && nodeElement.hasClass(OPENED_NODE_CONTAINER_CLASS)) {
      const node = this._getNodeByElement(this._getItem($focusedNode));
      this._toggleExpandedState(node, false);
    } else {
      const collapsedNode = this._getClosestNonDisabledNode($focusedNode);
      collapsedNode.length && this.option("focusedElement", getPublicElement(collapsedNode));
      this.getScrollable().scrollToElement(this._getNodeItemElement(collapsedNode));
    }
  },
  _encodeString: (value) => isString(value) ? encodeURI(value) : value,
  _decodeString: (value) => isString(value) ? decodeURI(value) : value,
  getScrollable() {
    return this._scrollable;
  },
  updateDimensions() {
    const deferred = Deferred();
    const scrollable = this.getScrollable();
    if (scrollable) {
      scrollable.update().done(() => {
        deferred.resolveWith(this);
      });
    } else {
      deferred.resolveWith(this);
    }
    return deferred.promise();
  },
  selectItem(itemElement) {
    return this._updateItemSelection(true, itemElement);
  },
  unselectItem(itemElement) {
    return this._updateItemSelection(false, itemElement);
  },
  expandItem(itemElement) {
    return this._toggleExpandedState(itemElement, true);
  },
  collapseItem(itemElement) {
    return this._toggleExpandedState(itemElement, false);
  },
  getNodes() {
    return this._dataAdapter.getTreeNodes();
  },
  getSelectedNodes() {
    return this.getSelectedNodeKeys().map((key) => {
      const node = this._dataAdapter.getNodeByKey(key);
      return this._dataAdapter.getPublicNode(node);
    });
  },
  getSelectedNodeKeys() {
    return this._dataAdapter.getSelectedNodesKeys();
  },
  selectAll() {
    if (this._selectAllEnabled()) {
      this._$selectAllItem.dxCheckBox("instance").option("value", true);
    } else {
      this._toggleSelectAll({
        value: true
      });
    }
  },
  unselectAll() {
    if (this._selectAllEnabled()) {
      this._$selectAllItem.dxCheckBox("instance").option("value", false);
    } else {
      this._toggleSelectAll({
        value: false
      });
    }
  },
  _allItemsExpandedHandler() {
    this._skipContentReadyAndItemExpanded = false;
    this._fireContentReadyAction();
  },
  expandAll() {
    const nodes = this._dataAdapter.getData();
    const expandingPromises = [];
    this._skipContentReadyAndItemExpanded = true;
    nodes.forEach((node) => expandingPromises.push(this._toggleExpandedState(node.internalFields.key, true)));
    Promise.allSettled(expandingPromises).then(() => {
      var _this$_allItemsExpand;
      return null === (_this$_allItemsExpand = this._allItemsExpandedHandler) || void 0 === _this$_allItemsExpand ? void 0 : _this$_allItemsExpand.call(this);
    });
  },
  collapseAll() {
    each(this._dataAdapter.getExpandedNodesKeys(), (_, key) => {
      this._toggleExpandedState(key, false);
    });
  },
  scrollToItem(keyOrItemOrElement) {
    const node = this._getNode(keyOrItemOrElement);
    if (!node) {
      return Deferred().reject().promise();
    }
    const nodeKeysToExpand = [];
    let parentNode = node.internalFields.publicNode.parent;
    while (null != parentNode) {
      if (!parentNode.expanded) {
        nodeKeysToExpand.push(parentNode.key);
      }
      parentNode = parentNode.parent;
    }
    const scrollCallback = Deferred();
    this._expandNodes(nodeKeysToExpand.reverse()).always(() => {
      const $element = this._getNodeElement(node);
      if ($element && $element.length) {
        this.scrollToElementTopLeft($element.get(0));
        scrollCallback.resolve();
      } else {
        scrollCallback.reject();
      }
    });
    return scrollCallback.promise();
  },
  scrollToElementTopLeft(targetElement) {
    const scrollable = this.getScrollable();
    const {
      scrollDirection,
      rtlEnabled
    } = this.option();
    const targetLocation = {
      top: 0,
      left: 0
    };
    const relativeOffset = getRelativeOffset(SCROLLABLE_CONTENT_CLASS, targetElement);
    if (scrollDirection !== DIRECTION_VERTICAL) {
      const containerElement = renderer_default(scrollable.container()).get(0);
      targetLocation.left = rtlEnabled ? relativeOffset.left + targetElement.offsetWidth - containerElement.clientWidth : relativeOffset.left;
    }
    if (scrollDirection !== DIRECTION_HORIZONTAL) {
      targetLocation.top = relativeOffset.top;
    }
    scrollable.scrollTo(targetLocation);
  },
  _expandNodes(keysToExpand) {
    if (!keysToExpand || 0 === keysToExpand.length) {
      return Deferred().resolve().promise();
    }
    const resultCallback = Deferred();
    const callbacksByNodes = keysToExpand.map((key) => this.expandItem(key));
    when.apply(renderer_default, callbacksByNodes).done(() => resultCallback.resolve()).fail(() => resultCallback.reject());
    return resultCallback.promise();
  },
  _dispose() {
    this.callBase();
    clearTimeout(this._setFocusedItemTimeout);
    this._allItemsExpandedHandler = null;
  }
});
var m_tree_view_base_default = TreeViewBase;

// node_modules/devextreme/esm/__internal/ui/tree_view/m_tree_view.search.js
ui_search_box_mixin_default.setEditorClass(text_box_default);
var WIDGET_CLASS2 = "dx-treeview";
var NODE_CONTAINER_CLASS2 = `${WIDGET_CLASS2}-node-container`;
var TreeViewSearch = m_tree_view_base_default.inherit(ui_search_box_mixin_default).inherit({
  _addWidgetPrefix: (className) => `${WIDGET_CLASS2}-${className}`,
  _optionChanged(args) {
    switch (args.name) {
      case "searchValue":
        if (this._showCheckboxes() && this._isRecursiveSelection()) {
          this._removeSelection();
        }
        this._initDataAdapter();
        this._updateSearch();
        this._repaintContainer();
        this.option("focusedElement", null);
        break;
      case "searchExpr":
        this._initDataAdapter();
        this.repaint();
        break;
      case "searchMode":
        this.option("expandNodesRecursive") ? this._updateDataAdapter() : this._initDataAdapter();
        this.repaint();
        break;
      default:
        this.callBase(args);
    }
  },
  _updateDataAdapter() {
    this._setOptionWithoutOptionChange("expandNodesRecursive", false);
    this._initDataAdapter();
    this._setOptionWithoutOptionChange("expandNodesRecursive", true);
  },
  _getDataAdapterOptions() {
    return extend(this.callBase(), {
      searchValue: this.option("searchValue"),
      searchMode: this.option("searchMode") || "contains",
      searchExpr: this.option("searchExpr")
    });
  },
  _getNodeContainer() {
    return this.$element().find(`.${NODE_CONTAINER_CLASS2}`).first();
  },
  _updateSearch() {
    if (this._searchEditor) {
      const editorOptions = this._getSearchEditorOptions();
      this._searchEditor.option(editorOptions);
    }
  },
  _repaintContainer() {
    const $container = this._getNodeContainer();
    let rootNodes;
    if ($container.length) {
      $container.empty();
      rootNodes = this._dataAdapter.getRootNodes();
      this._renderEmptyMessage(rootNodes);
      this._renderItems($container, rootNodes);
      this._fireContentReadyAction();
    }
  },
  _focusTarget() {
    return this._itemContainer(this.option("searchEnabled"));
  },
  _cleanItemContainer() {
    this.$element().empty();
  },
  _itemContainer(isSearchMode, selectAllEnabled) {
    selectAllEnabled ?? (selectAllEnabled = this._selectAllEnabled());
    if (selectAllEnabled) {
      return this._getNodeContainer();
    }
    if (this._scrollable && isSearchMode) {
      return renderer_default(this._scrollable.content());
    }
    return this.callBase();
  },
  _addWidgetClass() {
    this.$element().addClass(this._widgetClass());
  },
  _clean() {
    this.callBase();
    this._removeSearchBox();
  }
});
component_registrator_default("dxTreeView", TreeViewSearch);
var m_tree_view_search_default = TreeViewSearch;

// node_modules/devextreme/esm/ui/tree_view.js
var tree_view_default = m_tree_view_search_default;

// node_modules/devextreme-angular/fesm2022/devextreme-angular-ui-tree-view.mjs
var DxTreeViewComponent = class _DxTreeViewComponent extends DxComponent {
  _watcherHelper;
  _idh;
  instance = null;
  /**
   * Specifies the shortcut key that sets focus on the UI component.
  
   */
  get accessKey() {
    return this._getOption("accessKey");
  }
  set accessKey(value) {
    this._setOption("accessKey", value);
  }
  /**
   * Specifies whether the UI component changes its visual state as a result of user interaction.
  
   */
  get activeStateEnabled() {
    return this._getOption("activeStateEnabled");
  }
  set activeStateEnabled(value) {
    this._setOption("activeStateEnabled", value);
  }
  /**
   * Specifies whether or not to animate item collapsing and expanding.
  
   */
  get animationEnabled() {
    return this._getOption("animationEnabled");
  }
  set animationEnabled(value) {
    this._setOption("animationEnabled", value);
  }
  /**
   * Specifies a custom collapse icon.
  
   */
  get collapseIcon() {
    return this._getOption("collapseIcon");
  }
  set collapseIcon(value) {
    this._setOption("collapseIcon", value);
  }
  /**
   * Allows you to load nodes on demand.
  
   */
  get createChildren() {
    return this._getOption("createChildren");
  }
  set createChildren(value) {
    this._setOption("createChildren", value);
  }
  /**
   * Binds the UI component to data.
  
   */
  get dataSource() {
    return this._getOption("dataSource");
  }
  set dataSource(value) {
    this._setOption("dataSource", value);
  }
  /**
   * Notifies the UI component of the used data structure.
  
   */
  get dataStructure() {
    return this._getOption("dataStructure");
  }
  set dataStructure(value) {
    this._setOption("dataStructure", value);
  }
  /**
   * Specifies whether the UI component responds to user interaction.
  
   */
  get disabled() {
    return this._getOption("disabled");
  }
  set disabled(value) {
    this._setOption("disabled", value);
  }
  /**
   * Specifies the name of the data source item field whose value defines whether or not the corresponding UI component item is disabled.
  
   */
  get disabledExpr() {
    return this._getOption("disabledExpr");
  }
  set disabledExpr(value) {
    this._setOption("disabledExpr", value);
  }
  /**
   * Specifies the data field whose values should be displayed.
  
   */
  get displayExpr() {
    return this._getOption("displayExpr");
  }
  set displayExpr(value) {
    this._setOption("displayExpr", value);
  }
  /**
   * Specifies the global attributes to be attached to the UI component&apos;s container element.
  
   */
  get elementAttr() {
    return this._getOption("elementAttr");
  }
  set elementAttr(value) {
    this._setOption("elementAttr", value);
  }
  /**
   * Specifies whether or not a user can expand all tree view items by the &apos;*&apos; hot key.
  
   */
  get expandAllEnabled() {
    return this._getOption("expandAllEnabled");
  }
  set expandAllEnabled(value) {
    this._setOption("expandAllEnabled", value);
  }
  /**
   * Specifies which data source field specifies whether an item is expanded.
  
   */
  get expandedExpr() {
    return this._getOption("expandedExpr");
  }
  set expandedExpr(value) {
    this._setOption("expandedExpr", value);
  }
  /**
   * Specifies the event on which to expand/collapse a node.
  
   */
  get expandEvent() {
    return this._getOption("expandEvent");
  }
  set expandEvent(value) {
    this._setOption("expandEvent", value);
  }
  /**
   * Specifies a custom expand icon.
  
   */
  get expandIcon() {
    return this._getOption("expandIcon");
  }
  set expandIcon(value) {
    this._setOption("expandIcon", value);
  }
  /**
   * Specifies whether or not all parent nodes of an initially expanded node are displayed expanded.
  
   */
  get expandNodesRecursive() {
    return this._getOption("expandNodesRecursive");
  }
  set expandNodesRecursive(value) {
    this._setOption("expandNodesRecursive", value);
  }
  /**
   * Specifies whether the UI component can be focused using keyboard navigation.
  
   */
  get focusStateEnabled() {
    return this._getOption("focusStateEnabled");
  }
  set focusStateEnabled(value) {
    this._setOption("focusStateEnabled", value);
  }
  /**
   * Specifies the name of the data source item field whose value defines whether or not the corresponding node includes child nodes.
  
   */
  get hasItemsExpr() {
    return this._getOption("hasItemsExpr");
  }
  set hasItemsExpr(value) {
    this._setOption("hasItemsExpr", value);
  }
  /**
   * Specifies the UI component&apos;s height.
  
   */
  get height() {
    return this._getOption("height");
  }
  set height(value) {
    this._setOption("height", value);
  }
  /**
   * Specifies text for a hint that appears when a user pauses on the UI component.
  
   */
  get hint() {
    return this._getOption("hint");
  }
  set hint(value) {
    this._setOption("hint", value);
  }
  /**
   * Specifies whether the UI component changes its state when a user pauses on it.
  
   */
  get hoverStateEnabled() {
    return this._getOption("hoverStateEnabled");
  }
  set hoverStateEnabled(value) {
    this._setOption("hoverStateEnabled", value);
  }
  /**
   * The time period in milliseconds before the onItemHold event is raised.
  
   */
  get itemHoldTimeout() {
    return this._getOption("itemHoldTimeout");
  }
  set itemHoldTimeout(value) {
    this._setOption("itemHoldTimeout", value);
  }
  /**
   * An array of items displayed by the UI component.
  
   */
  get items() {
    return this._getOption("items");
  }
  set items(value) {
    this._setOption("items", value);
  }
  /**
   * Specifies which data field contains nested items.
  
   */
  get itemsExpr() {
    return this._getOption("itemsExpr");
  }
  set itemsExpr(value) {
    this._setOption("itemsExpr", value);
  }
  /**
   * Specifies a custom template for items.
  
   */
  get itemTemplate() {
    return this._getOption("itemTemplate");
  }
  set itemTemplate(value) {
    this._setOption("itemTemplate", value);
  }
  /**
   * Specifies which data field provides keys for TreeView items.
  
   */
  get keyExpr() {
    return this._getOption("keyExpr");
  }
  set keyExpr(value) {
    this._setOption("keyExpr", value);
  }
  /**
   * Specifies the text or HTML markup displayed by the UI component if the item collection is empty.
  
   */
  get noDataText() {
    return this._getOption("noDataText");
  }
  set noDataText(value) {
    this._setOption("noDataText", value);
  }
  /**
   * Specifies the name of the data source item field for holding the parent key of the corresponding node.
  
   */
  get parentIdExpr() {
    return this._getOption("parentIdExpr");
  }
  set parentIdExpr(value) {
    this._setOption("parentIdExpr", value);
  }
  /**
   * Specifies the parent ID value of the root item.
  
   */
  get rootValue() {
    return this._getOption("rootValue");
  }
  set rootValue(value) {
    this._setOption("rootValue", value);
  }
  /**
   * Switches the UI component to a right-to-left representation.
  
   */
  get rtlEnabled() {
    return this._getOption("rtlEnabled");
  }
  set rtlEnabled(value) {
    this._setOption("rtlEnabled", value);
  }
  /**
   * A string value specifying available scrolling directions.
  
   */
  get scrollDirection() {
    return this._getOption("scrollDirection");
  }
  set scrollDirection(value) {
    this._setOption("scrollDirection", value);
  }
  /**
   * Configures the search panel.
  
   */
  get searchEditorOptions() {
    return this._getOption("searchEditorOptions");
  }
  set searchEditorOptions(value) {
    this._setOption("searchEditorOptions", value);
  }
  /**
   * Specifies whether the search panel is visible.
  
   */
  get searchEnabled() {
    return this._getOption("searchEnabled");
  }
  set searchEnabled(value) {
    this._setOption("searchEnabled", value);
  }
  /**
   * Specifies a data object&apos;s field name or an expression whose value is compared to the search string.
  
   */
  get searchExpr() {
    return this._getOption("searchExpr");
  }
  set searchExpr(value) {
    this._setOption("searchExpr", value);
  }
  /**
   * Specifies a comparison operation used to search UI component items.
  
   */
  get searchMode() {
    return this._getOption("searchMode");
  }
  set searchMode(value) {
    this._setOption("searchMode", value);
  }
  /**
   * Specifies a delay in milliseconds between when a user finishes typing, and the search is executed.
  
   */
  get searchTimeout() {
    return this._getOption("searchTimeout");
  }
  set searchTimeout(value) {
    this._setOption("searchTimeout", value);
  }
  /**
   * Specifies the current search string.
  
   */
  get searchValue() {
    return this._getOption("searchValue");
  }
  set searchValue(value) {
    this._setOption("searchValue", value);
  }
  /**
   * Specifies the text displayed at the &apos;Select All&apos; check box.
  
   */
  get selectAllText() {
    return this._getOption("selectAllText");
  }
  set selectAllText(value) {
    this._setOption("selectAllText", value);
  }
  /**
   * Specifies whether an item is selected if a user clicks it.
  
   */
  get selectByClick() {
    return this._getOption("selectByClick");
  }
  set selectByClick(value) {
    this._setOption("selectByClick", value);
  }
  /**
   * Specifies the name of the data source item field whose value defines whether or not the corresponding UI component items is selected.
  
   */
  get selectedExpr() {
    return this._getOption("selectedExpr");
  }
  set selectedExpr(value) {
    this._setOption("selectedExpr", value);
  }
  /**
   * Specifies item selection mode. Applies only if selection is enabled.
  
   */
  get selectionMode() {
    return this._getOption("selectionMode");
  }
  set selectionMode(value) {
    this._setOption("selectionMode", value);
  }
  /**
   * Specifies whether all child nodes should be selected when their parent node is selected. Applies only if the selectionMode is &apos;multiple&apos;.
  
   */
  get selectNodesRecursive() {
    return this._getOption("selectNodesRecursive");
  }
  set selectNodesRecursive(value) {
    this._setOption("selectNodesRecursive", value);
  }
  /**
   * Specifies the checkbox display mode.
  
   */
  get showCheckBoxesMode() {
    return this._getOption("showCheckBoxesMode");
  }
  set showCheckBoxesMode(value) {
    this._setOption("showCheckBoxesMode", value);
  }
  /**
   * Specifies the number of the element when the Tab key is used for navigating.
  
   */
  get tabIndex() {
    return this._getOption("tabIndex");
  }
  set tabIndex(value) {
    this._setOption("tabIndex", value);
  }
  /**
   * Specifies whether or not the UI component uses native scrolling.
  
   */
  get useNativeScrolling() {
    return this._getOption("useNativeScrolling");
  }
  set useNativeScrolling(value) {
    this._setOption("useNativeScrolling", value);
  }
  /**
   * Enables the virtual mode in which nodes are loaded on demand. Use it to enhance the performance on large datasets.
  
   */
  get virtualModeEnabled() {
    return this._getOption("virtualModeEnabled");
  }
  set virtualModeEnabled(value) {
    this._setOption("virtualModeEnabled", value);
  }
  /**
   * Specifies whether the UI component is visible.
  
   */
  get visible() {
    return this._getOption("visible");
  }
  set visible(value) {
    this._setOption("visible", value);
  }
  /**
   * Specifies the UI component&apos;s width.
  
   */
  get width() {
    return this._getOption("width");
  }
  set width(value) {
    this._setOption("width", value);
  }
  /**
  
   * A function that is executed when the UI component is rendered and each time the component is repainted.
  
  
   */
  onContentReady;
  /**
  
   * A function that is executed before the UI component is disposed of.
  
  
   */
  onDisposing;
  /**
  
   * A function used in JavaScript frameworks to save the UI component instance.
  
  
   */
  onInitialized;
  /**
  
   * A function that is executed when a collection item is clicked or tapped.
  
  
   */
  onItemClick;
  /**
  
   * A function that is executed when a tree view item is collapsed.
  
  
   */
  onItemCollapsed;
  /**
  
   * A function that is executed when a collection item is right-clicked or pressed.
  
  
   */
  onItemContextMenu;
  /**
  
   * A function that is executed when a tree view item is expanded.
  
  
   */
  onItemExpanded;
  /**
  
   * A function that is executed when a collection item has been held for a specified period.
  
  
   */
  onItemHold;
  /**
  
   * A function that is executed after a collection item is rendered.
  
  
   */
  onItemRendered;
  /**
  
   * A function that is executed when a single TreeView item is selected or selection is canceled.
  
  
   */
  onItemSelectionChanged;
  /**
  
   * A function that is executed after a UI component property is changed.
  
  
   */
  onOptionChanged;
  /**
  
   * A function that is executed when the &apos;Select All&apos; check box value is changed. Applies only if showCheckBoxesMode is &apos;selectAll&apos; and selectionMode is &apos;multiple&apos;.
  
  
   */
  onSelectAllValueChanged;
  /**
  
   * A function that is executed when a TreeView item is selected or selection is canceled.
  
  
   */
  onSelectionChanged;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  accessKeyChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  activeStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  animationEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  collapseIconChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  createChildrenChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  dataSourceChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  dataStructureChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  disabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  disabledExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  displayExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  elementAttrChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  expandAllEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  expandedExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  expandEventChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  expandIconChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  expandNodesRecursiveChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  focusStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hasItemsExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  heightChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hintChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  hoverStateEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemHoldTimeoutChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemsExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  itemTemplateChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  keyExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  noDataTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  parentIdExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  rootValueChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  rtlEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  scrollDirectionChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchEditorOptionsChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchTimeoutChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  searchValueChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectAllTextChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectByClickChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectedExprChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectionModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  selectNodesRecursiveChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  showCheckBoxesModeChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  tabIndexChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  useNativeScrollingChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  virtualModeEnabledChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  visibleChange;
  /**
  
   * This member supports the internal infrastructure and is not intended to be used directly from your code.
  
   */
  widthChange;
  get itemsChildren() {
    return this._getOption("items");
  }
  set itemsChildren(value) {
    this.setChildren("items", value);
  }
  constructor(elementRef, ngZone, templateHost, _watcherHelper, _idh, optionHost, transferState, platformId) {
    super(elementRef, ngZone, templateHost, _watcherHelper, transferState, platformId);
    this._watcherHelper = _watcherHelper;
    this._idh = _idh;
    this._createEventEmitters([{
      subscribe: "contentReady",
      emit: "onContentReady"
    }, {
      subscribe: "disposing",
      emit: "onDisposing"
    }, {
      subscribe: "initialized",
      emit: "onInitialized"
    }, {
      subscribe: "itemClick",
      emit: "onItemClick"
    }, {
      subscribe: "itemCollapsed",
      emit: "onItemCollapsed"
    }, {
      subscribe: "itemContextMenu",
      emit: "onItemContextMenu"
    }, {
      subscribe: "itemExpanded",
      emit: "onItemExpanded"
    }, {
      subscribe: "itemHold",
      emit: "onItemHold"
    }, {
      subscribe: "itemRendered",
      emit: "onItemRendered"
    }, {
      subscribe: "itemSelectionChanged",
      emit: "onItemSelectionChanged"
    }, {
      subscribe: "optionChanged",
      emit: "onOptionChanged"
    }, {
      subscribe: "selectAllValueChanged",
      emit: "onSelectAllValueChanged"
    }, {
      subscribe: "selectionChanged",
      emit: "onSelectionChanged"
    }, {
      emit: "accessKeyChange"
    }, {
      emit: "activeStateEnabledChange"
    }, {
      emit: "animationEnabledChange"
    }, {
      emit: "collapseIconChange"
    }, {
      emit: "createChildrenChange"
    }, {
      emit: "dataSourceChange"
    }, {
      emit: "dataStructureChange"
    }, {
      emit: "disabledChange"
    }, {
      emit: "disabledExprChange"
    }, {
      emit: "displayExprChange"
    }, {
      emit: "elementAttrChange"
    }, {
      emit: "expandAllEnabledChange"
    }, {
      emit: "expandedExprChange"
    }, {
      emit: "expandEventChange"
    }, {
      emit: "expandIconChange"
    }, {
      emit: "expandNodesRecursiveChange"
    }, {
      emit: "focusStateEnabledChange"
    }, {
      emit: "hasItemsExprChange"
    }, {
      emit: "heightChange"
    }, {
      emit: "hintChange"
    }, {
      emit: "hoverStateEnabledChange"
    }, {
      emit: "itemHoldTimeoutChange"
    }, {
      emit: "itemsChange"
    }, {
      emit: "itemsExprChange"
    }, {
      emit: "itemTemplateChange"
    }, {
      emit: "keyExprChange"
    }, {
      emit: "noDataTextChange"
    }, {
      emit: "parentIdExprChange"
    }, {
      emit: "rootValueChange"
    }, {
      emit: "rtlEnabledChange"
    }, {
      emit: "scrollDirectionChange"
    }, {
      emit: "searchEditorOptionsChange"
    }, {
      emit: "searchEnabledChange"
    }, {
      emit: "searchExprChange"
    }, {
      emit: "searchModeChange"
    }, {
      emit: "searchTimeoutChange"
    }, {
      emit: "searchValueChange"
    }, {
      emit: "selectAllTextChange"
    }, {
      emit: "selectByClickChange"
    }, {
      emit: "selectedExprChange"
    }, {
      emit: "selectionModeChange"
    }, {
      emit: "selectNodesRecursiveChange"
    }, {
      emit: "showCheckBoxesModeChange"
    }, {
      emit: "tabIndexChange"
    }, {
      emit: "useNativeScrollingChange"
    }, {
      emit: "virtualModeEnabledChange"
    }, {
      emit: "visibleChange"
    }, {
      emit: "widthChange"
    }]);
    this._idh.setHost(this);
    optionHost.setHost(this);
  }
  _createInstance(element, options) {
    return new tree_view_default(element, options);
  }
  ngOnDestroy() {
    this._destroyWidget();
  }
  ngOnChanges(changes) {
    super.ngOnChanges(changes);
    this.setupChanges("dataSource", changes);
    this.setupChanges("items", changes);
    this.setupChanges("searchExpr", changes);
  }
  setupChanges(prop, changes) {
    if (!(prop in this._optionsToUpdate)) {
      this._idh.setup(prop, changes);
    }
  }
  ngDoCheck() {
    this._idh.doCheck("dataSource");
    this._idh.doCheck("items");
    this._idh.doCheck("searchExpr");
    this._watcherHelper.checkWatchers();
    super.ngDoCheck();
    super.clearChangedOptions();
  }
  _setOption(name, value) {
    let isSetup = this._idh.setupSingle(name, value);
    let isChanged = this._idh.getChanges(name, value) !== null;
    if (isSetup || isChanged) {
      super._setOption(name, value);
    }
  }
  /** @nocollapse */
  static ɵfac = function DxTreeViewComponent_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxTreeViewComponent)(ɵɵdirectiveInject(ElementRef), ɵɵdirectiveInject(NgZone), ɵɵdirectiveInject(DxTemplateHost), ɵɵdirectiveInject(WatcherHelper), ɵɵdirectiveInject(IterableDifferHelper), ɵɵdirectiveInject(NestedOptionHost), ɵɵdirectiveInject(TransferState), ɵɵdirectiveInject(PLATFORM_ID));
  };
  /** @nocollapse */
  static ɵcmp = ɵɵdefineComponent({
    type: _DxTreeViewComponent,
    selectors: [["dx-tree-view"]],
    contentQueries: function DxTreeViewComponent_ContentQueries(rf, ctx, dirIndex) {
      if (rf & 1) {
        ɵɵcontentQuery(dirIndex, DxiItemComponent, 4);
      }
      if (rf & 2) {
        let _t;
        ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.itemsChildren = _t);
      }
    },
    inputs: {
      accessKey: "accessKey",
      activeStateEnabled: "activeStateEnabled",
      animationEnabled: "animationEnabled",
      collapseIcon: "collapseIcon",
      createChildren: "createChildren",
      dataSource: "dataSource",
      dataStructure: "dataStructure",
      disabled: "disabled",
      disabledExpr: "disabledExpr",
      displayExpr: "displayExpr",
      elementAttr: "elementAttr",
      expandAllEnabled: "expandAllEnabled",
      expandedExpr: "expandedExpr",
      expandEvent: "expandEvent",
      expandIcon: "expandIcon",
      expandNodesRecursive: "expandNodesRecursive",
      focusStateEnabled: "focusStateEnabled",
      hasItemsExpr: "hasItemsExpr",
      height: "height",
      hint: "hint",
      hoverStateEnabled: "hoverStateEnabled",
      itemHoldTimeout: "itemHoldTimeout",
      items: "items",
      itemsExpr: "itemsExpr",
      itemTemplate: "itemTemplate",
      keyExpr: "keyExpr",
      noDataText: "noDataText",
      parentIdExpr: "parentIdExpr",
      rootValue: "rootValue",
      rtlEnabled: "rtlEnabled",
      scrollDirection: "scrollDirection",
      searchEditorOptions: "searchEditorOptions",
      searchEnabled: "searchEnabled",
      searchExpr: "searchExpr",
      searchMode: "searchMode",
      searchTimeout: "searchTimeout",
      searchValue: "searchValue",
      selectAllText: "selectAllText",
      selectByClick: "selectByClick",
      selectedExpr: "selectedExpr",
      selectionMode: "selectionMode",
      selectNodesRecursive: "selectNodesRecursive",
      showCheckBoxesMode: "showCheckBoxesMode",
      tabIndex: "tabIndex",
      useNativeScrolling: "useNativeScrolling",
      virtualModeEnabled: "virtualModeEnabled",
      visible: "visible",
      width: "width"
    },
    outputs: {
      onContentReady: "onContentReady",
      onDisposing: "onDisposing",
      onInitialized: "onInitialized",
      onItemClick: "onItemClick",
      onItemCollapsed: "onItemCollapsed",
      onItemContextMenu: "onItemContextMenu",
      onItemExpanded: "onItemExpanded",
      onItemHold: "onItemHold",
      onItemRendered: "onItemRendered",
      onItemSelectionChanged: "onItemSelectionChanged",
      onOptionChanged: "onOptionChanged",
      onSelectAllValueChanged: "onSelectAllValueChanged",
      onSelectionChanged: "onSelectionChanged",
      accessKeyChange: "accessKeyChange",
      activeStateEnabledChange: "activeStateEnabledChange",
      animationEnabledChange: "animationEnabledChange",
      collapseIconChange: "collapseIconChange",
      createChildrenChange: "createChildrenChange",
      dataSourceChange: "dataSourceChange",
      dataStructureChange: "dataStructureChange",
      disabledChange: "disabledChange",
      disabledExprChange: "disabledExprChange",
      displayExprChange: "displayExprChange",
      elementAttrChange: "elementAttrChange",
      expandAllEnabledChange: "expandAllEnabledChange",
      expandedExprChange: "expandedExprChange",
      expandEventChange: "expandEventChange",
      expandIconChange: "expandIconChange",
      expandNodesRecursiveChange: "expandNodesRecursiveChange",
      focusStateEnabledChange: "focusStateEnabledChange",
      hasItemsExprChange: "hasItemsExprChange",
      heightChange: "heightChange",
      hintChange: "hintChange",
      hoverStateEnabledChange: "hoverStateEnabledChange",
      itemHoldTimeoutChange: "itemHoldTimeoutChange",
      itemsChange: "itemsChange",
      itemsExprChange: "itemsExprChange",
      itemTemplateChange: "itemTemplateChange",
      keyExprChange: "keyExprChange",
      noDataTextChange: "noDataTextChange",
      parentIdExprChange: "parentIdExprChange",
      rootValueChange: "rootValueChange",
      rtlEnabledChange: "rtlEnabledChange",
      scrollDirectionChange: "scrollDirectionChange",
      searchEditorOptionsChange: "searchEditorOptionsChange",
      searchEnabledChange: "searchEnabledChange",
      searchExprChange: "searchExprChange",
      searchModeChange: "searchModeChange",
      searchTimeoutChange: "searchTimeoutChange",
      searchValueChange: "searchValueChange",
      selectAllTextChange: "selectAllTextChange",
      selectByClickChange: "selectByClickChange",
      selectedExprChange: "selectedExprChange",
      selectionModeChange: "selectionModeChange",
      selectNodesRecursiveChange: "selectNodesRecursiveChange",
      showCheckBoxesModeChange: "showCheckBoxesModeChange",
      tabIndexChange: "tabIndexChange",
      useNativeScrollingChange: "useNativeScrollingChange",
      virtualModeEnabledChange: "virtualModeEnabledChange",
      visibleChange: "visibleChange",
      widthChange: "widthChange"
    },
    features: [ɵɵProvidersFeature([DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]), ɵɵInheritDefinitionFeature, ɵɵNgOnChangesFeature],
    decls: 0,
    vars: 0,
    template: function DxTreeViewComponent_Template(rf, ctx) {
    },
    encapsulation: 2
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxTreeViewComponent, [{
    type: Component,
    args: [{
      selector: "dx-tree-view",
      template: "",
      providers: [DxTemplateHost, WatcherHelper, NestedOptionHost, IterableDifferHelper]
    }]
  }], function() {
    return [{
      type: ElementRef
    }, {
      type: NgZone
    }, {
      type: DxTemplateHost
    }, {
      type: WatcherHelper
    }, {
      type: IterableDifferHelper
    }, {
      type: NestedOptionHost
    }, {
      type: TransferState
    }, {
      type: void 0,
      decorators: [{
        type: Inject,
        args: [PLATFORM_ID]
      }]
    }];
  }, {
    accessKey: [{
      type: Input
    }],
    activeStateEnabled: [{
      type: Input
    }],
    animationEnabled: [{
      type: Input
    }],
    collapseIcon: [{
      type: Input
    }],
    createChildren: [{
      type: Input
    }],
    dataSource: [{
      type: Input
    }],
    dataStructure: [{
      type: Input
    }],
    disabled: [{
      type: Input
    }],
    disabledExpr: [{
      type: Input
    }],
    displayExpr: [{
      type: Input
    }],
    elementAttr: [{
      type: Input
    }],
    expandAllEnabled: [{
      type: Input
    }],
    expandedExpr: [{
      type: Input
    }],
    expandEvent: [{
      type: Input
    }],
    expandIcon: [{
      type: Input
    }],
    expandNodesRecursive: [{
      type: Input
    }],
    focusStateEnabled: [{
      type: Input
    }],
    hasItemsExpr: [{
      type: Input
    }],
    height: [{
      type: Input
    }],
    hint: [{
      type: Input
    }],
    hoverStateEnabled: [{
      type: Input
    }],
    itemHoldTimeout: [{
      type: Input
    }],
    items: [{
      type: Input
    }],
    itemsExpr: [{
      type: Input
    }],
    itemTemplate: [{
      type: Input
    }],
    keyExpr: [{
      type: Input
    }],
    noDataText: [{
      type: Input
    }],
    parentIdExpr: [{
      type: Input
    }],
    rootValue: [{
      type: Input
    }],
    rtlEnabled: [{
      type: Input
    }],
    scrollDirection: [{
      type: Input
    }],
    searchEditorOptions: [{
      type: Input
    }],
    searchEnabled: [{
      type: Input
    }],
    searchExpr: [{
      type: Input
    }],
    searchMode: [{
      type: Input
    }],
    searchTimeout: [{
      type: Input
    }],
    searchValue: [{
      type: Input
    }],
    selectAllText: [{
      type: Input
    }],
    selectByClick: [{
      type: Input
    }],
    selectedExpr: [{
      type: Input
    }],
    selectionMode: [{
      type: Input
    }],
    selectNodesRecursive: [{
      type: Input
    }],
    showCheckBoxesMode: [{
      type: Input
    }],
    tabIndex: [{
      type: Input
    }],
    useNativeScrolling: [{
      type: Input
    }],
    virtualModeEnabled: [{
      type: Input
    }],
    visible: [{
      type: Input
    }],
    width: [{
      type: Input
    }],
    onContentReady: [{
      type: Output
    }],
    onDisposing: [{
      type: Output
    }],
    onInitialized: [{
      type: Output
    }],
    onItemClick: [{
      type: Output
    }],
    onItemCollapsed: [{
      type: Output
    }],
    onItemContextMenu: [{
      type: Output
    }],
    onItemExpanded: [{
      type: Output
    }],
    onItemHold: [{
      type: Output
    }],
    onItemRendered: [{
      type: Output
    }],
    onItemSelectionChanged: [{
      type: Output
    }],
    onOptionChanged: [{
      type: Output
    }],
    onSelectAllValueChanged: [{
      type: Output
    }],
    onSelectionChanged: [{
      type: Output
    }],
    accessKeyChange: [{
      type: Output
    }],
    activeStateEnabledChange: [{
      type: Output
    }],
    animationEnabledChange: [{
      type: Output
    }],
    collapseIconChange: [{
      type: Output
    }],
    createChildrenChange: [{
      type: Output
    }],
    dataSourceChange: [{
      type: Output
    }],
    dataStructureChange: [{
      type: Output
    }],
    disabledChange: [{
      type: Output
    }],
    disabledExprChange: [{
      type: Output
    }],
    displayExprChange: [{
      type: Output
    }],
    elementAttrChange: [{
      type: Output
    }],
    expandAllEnabledChange: [{
      type: Output
    }],
    expandedExprChange: [{
      type: Output
    }],
    expandEventChange: [{
      type: Output
    }],
    expandIconChange: [{
      type: Output
    }],
    expandNodesRecursiveChange: [{
      type: Output
    }],
    focusStateEnabledChange: [{
      type: Output
    }],
    hasItemsExprChange: [{
      type: Output
    }],
    heightChange: [{
      type: Output
    }],
    hintChange: [{
      type: Output
    }],
    hoverStateEnabledChange: [{
      type: Output
    }],
    itemHoldTimeoutChange: [{
      type: Output
    }],
    itemsChange: [{
      type: Output
    }],
    itemsExprChange: [{
      type: Output
    }],
    itemTemplateChange: [{
      type: Output
    }],
    keyExprChange: [{
      type: Output
    }],
    noDataTextChange: [{
      type: Output
    }],
    parentIdExprChange: [{
      type: Output
    }],
    rootValueChange: [{
      type: Output
    }],
    rtlEnabledChange: [{
      type: Output
    }],
    scrollDirectionChange: [{
      type: Output
    }],
    searchEditorOptionsChange: [{
      type: Output
    }],
    searchEnabledChange: [{
      type: Output
    }],
    searchExprChange: [{
      type: Output
    }],
    searchModeChange: [{
      type: Output
    }],
    searchTimeoutChange: [{
      type: Output
    }],
    searchValueChange: [{
      type: Output
    }],
    selectAllTextChange: [{
      type: Output
    }],
    selectByClickChange: [{
      type: Output
    }],
    selectedExprChange: [{
      type: Output
    }],
    selectionModeChange: [{
      type: Output
    }],
    selectNodesRecursiveChange: [{
      type: Output
    }],
    showCheckBoxesModeChange: [{
      type: Output
    }],
    tabIndexChange: [{
      type: Output
    }],
    useNativeScrollingChange: [{
      type: Output
    }],
    virtualModeEnabledChange: [{
      type: Output
    }],
    visibleChange: [{
      type: Output
    }],
    widthChange: [{
      type: Output
    }],
    itemsChildren: [{
      type: ContentChildren,
      args: [DxiItemComponent]
    }]
  });
})();
var DxTreeViewModule = class _DxTreeViewModule {
  /** @nocollapse */
  static ɵfac = function DxTreeViewModule_Factory(__ngFactoryType__) {
    return new (__ngFactoryType__ || _DxTreeViewModule)();
  };
  /** @nocollapse */
  static ɵmod = ɵɵdefineNgModule({
    type: _DxTreeViewModule,
    declarations: [DxTreeViewComponent],
    imports: [DxiItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxIntegrationModule, DxTemplateModule],
    exports: [DxTreeViewComponent, DxiItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxTemplateModule]
  });
  /** @nocollapse */
  static ɵinj = ɵɵdefineInjector({
    imports: [DxiItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxIntegrationModule, DxTemplateModule, DxiItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxTemplateModule]
  });
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DxTreeViewModule, [{
    type: NgModule,
    args: [{
      imports: [DxiItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxIntegrationModule, DxTemplateModule],
      declarations: [DxTreeViewComponent],
      exports: [DxTreeViewComponent, DxiItemModule, DxoSearchEditorOptionsModule, DxiButtonModule, DxoOptionsModule, DxTemplateModule]
    }]
  }], null, null);
})();

export {
  tree_view_default,
  DxTreeViewComponent,
  DxTreeViewModule
};
/*! Bundled license information:

devextreme-angular/fesm2022/devextreme-angular-ui-tree-view.mjs:
  (*!
   * devextreme-angular
   * Version: 24.1.4
   * Build date: Mon Jul 15 2024
   *
   * Copyright (c) 2012 - 2024 Developer Express Inc. ALL RIGHTS RESERVED
   *
   * This software may be modified and distributed under the terms
   * of the MIT license. See the LICENSE file in the root of the project for details.
   *
   * https://github.com/DevExpress/devextreme-angular
   *)
*/
//# sourceMappingURL=chunk-QQCHMMO3.js.map
