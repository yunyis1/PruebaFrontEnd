import {
  clearSelection,
  createEvent,
  emitter_default,
  eventData,
  eventDelta,
  isDxMouseWheelEvent,
  isTouchEvent,
  needSkipEvent,
  resetActiveElement
} from "./chunk-X73RLF6Y.js";
import {
  devices_default
} from "./chunk-25VDHZLA.js";
import {
  renderer_default,
  styleProp
} from "./chunk-M4HNHSVV.js";
import {
  events_engine_default
} from "./chunk-PJXMQ5JC.js";
import {
  ready_callbacks_default
} from "./chunk-IY7TXKCY.js";
import {
  call_once_default
} from "./chunk-E4ZFM5M7.js";
import {
  isDefined,
  isExponential,
  noop
} from "./chunk-V6EUNM2D.js";

// node_modules/devextreme/esm/core/utils/math.js
var sign = function(value) {
  if (0 === value) {
    return 0;
  }
  return value / Math.abs(value);
};
var fitIntoRange = function(value, minValue, maxValue) {
  const isMinValueUndefined = !minValue && 0 !== minValue;
  const isMaxValueUndefined = !maxValue && 0 !== maxValue;
  isMinValueUndefined && (minValue = !isMaxValueUndefined ? Math.min(value, maxValue) : value);
  isMaxValueUndefined && (maxValue = !isMinValueUndefined ? Math.max(value, minValue) : value);
  return Math.min(Math.max(value, minValue), maxValue);
};
var inRange = function(value, minValue, maxValue) {
  return value >= minValue && value <= maxValue;
};
function getExponent(value) {
  return Math.abs(parseInt(value.toExponential().split("e")[1]));
}
function getExponentialNotation(value) {
  const parts = value.toExponential().split("e");
  const mantissa = parseFloat(parts[0]);
  const exponent = parseInt(parts[1]);
  return {
    exponent,
    mantissa
  };
}
function multiplyInExponentialForm(value, exponentShift) {
  const exponentialNotation = getExponentialNotation(value);
  return parseFloat(`${exponentialNotation.mantissa}e${exponentialNotation.exponent + exponentShift}`);
}
function _isEdgeBug() {
  return "0.000300" !== 3e-4.toPrecision(3);
}
function adjust(value, interval) {
  let precision = getPrecision(interval || 0) + 2;
  const separatedValue = value.toString().split(".");
  const sourceValue = value;
  const absValue = Math.abs(value);
  let separatedAdjustedValue;
  const isExponentValue = isExponential(value);
  const integerPart = absValue > 1 ? 10 : 0;
  if (1 === separatedValue.length) {
    return value;
  }
  if (!isExponentValue) {
    if (isExponential(interval)) {
      precision = separatedValue[0].length + getExponent(interval);
    }
    value = absValue;
    value = value - Math.floor(value) + integerPart;
  }
  precision = _isEdgeBug() && getExponent(value) > 6 || precision > 7 ? 15 : 7;
  if (!isExponentValue) {
    separatedAdjustedValue = parseFloat(value.toPrecision(precision)).toString().split(".");
    if (separatedAdjustedValue[0] === integerPart.toString()) {
      return parseFloat(separatedValue[0] + "." + separatedAdjustedValue[1]);
    }
  }
  return parseFloat(sourceValue.toPrecision(precision));
}
function getPrecision(value) {
  const str = value.toString();
  if (str.indexOf(".") < 0) {
    return 0;
  }
  const mantissa = str.split(".");
  const positionOfDelimiter = mantissa[1].indexOf("e");
  return positionOfDelimiter >= 0 ? positionOfDelimiter : mantissa[1].length;
}
function getRoot(x, n) {
  if (x < 0 && n % 2 !== 1) {
    return NaN;
  }
  const y = Math.pow(Math.abs(x), 1 / n);
  return n % 2 === 1 && x < 0 ? -y : y;
}
function solveCubicEquation(a, b, c, d) {
  if (Math.abs(a) < 1e-8) {
    a = b;
    b = c;
    c = d;
    if (Math.abs(a) < 1e-8) {
      a = b;
      b = c;
      if (Math.abs(a) < 1e-8) {
        return [];
      }
      return [-b / a];
    }
    const D2 = b * b - 4 * a * c;
    if (Math.abs(D2) < 1e-8) {
      return [-b / (2 * a)];
    } else if (D2 > 0) {
      return [(-b + Math.sqrt(D2)) / (2 * a), (-b - Math.sqrt(D2)) / (2 * a)];
    }
    return [];
  }
  const p = (3 * a * c - b * b) / (3 * a * a);
  const q = (2 * b * b * b - 9 * a * b * c + 27 * a * a * d) / (27 * a * a * a);
  let roots;
  let u;
  if (Math.abs(p) < 1e-8) {
    roots = [getRoot(-q, 3)];
  } else if (Math.abs(q) < 1e-8) {
    roots = [0].concat(p < 0 ? [Math.sqrt(-p), -Math.sqrt(-p)] : []);
  } else {
    const D3 = q * q / 4 + p * p * p / 27;
    if (Math.abs(D3) < 1e-8) {
      roots = [-1.5 * q / p, 3 * q / p];
    } else if (D3 > 0) {
      u = getRoot(-q / 2 - Math.sqrt(D3), 3);
      roots = [u - p / (3 * u)];
    } else {
      u = 2 * Math.sqrt(-p / 3);
      const t = Math.acos(3 * q / p / u) / 3;
      const k = 2 * Math.PI / 3;
      roots = [u * Math.cos(t), u * Math.cos(t - k), u * Math.cos(t - 2 * k)];
    }
  }
  for (let i = 0; i < roots.length; i++) {
    roots[i] -= b / (3 * a);
  }
  return roots;
}
function trunc(value) {
  return Math.trunc ? Math.trunc(value) : value > 0 ? Math.floor(value) : Math.ceil(value);
}
function getRemainderByDivision(dividend, divider, digitsCount) {
  if (divider === parseInt(divider)) {
    return dividend % divider;
  }
  const quotient = roundFloatPart(dividend / divider, digitsCount);
  return (quotient - parseInt(quotient)) * divider;
}
function getExponentLength(value) {
  var _valueString$split$;
  const valueString = value.toString();
  return (null === (_valueString$split$ = valueString.split(".")[1]) || void 0 === _valueString$split$ ? void 0 : _valueString$split$.length) || parseInt(valueString.split("e-")[1]) || 0;
}
function roundFloatPart(value) {
  let digitsCount = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 0;
  return parseFloat(value.toFixed(digitsCount));
}

// node_modules/devextreme/esm/events/gesture/emitter.gesture.js
var ready = ready_callbacks_default.add;
var abs = Math.abs;
var TOUCH_BOUNDARY = 10;
var supportPointerEvents = function() {
  return styleProp("pointer-events");
};
var setGestureCover = call_once_default(function() {
  const isDesktop = "desktop" === devices_default.real().deviceType;
  if (!supportPointerEvents() || !isDesktop) {
    return noop;
  }
  const $cover = renderer_default("<div>").addClass("dx-gesture-cover").css("pointerEvents", "none");
  events_engine_default.subscribeGlobal($cover, "dxmousewheel", function(e) {
    e.preventDefault();
  });
  ready(function() {
    $cover.appendTo("body");
  });
  return function(toggle, cursor) {
    $cover.css("pointerEvents", toggle ? "all" : "none");
    toggle && $cover.css("cursor", cursor);
  };
});
var gestureCover = function(toggle, cursor) {
  const gestureCoverStrategy = setGestureCover();
  gestureCoverStrategy(toggle, cursor);
};
var GestureEmitter = emitter_default.inherit({
  gesture: true,
  configure: function(data) {
    this.getElement().css("msTouchAction", data.immediate ? "pinch-zoom" : "");
    this.callBase(data);
  },
  allowInterruptionByMouseWheel: function() {
    return 2 !== this._stage;
  },
  getDirection: function() {
    return this.direction;
  },
  _cancel: function() {
    this.callBase.apply(this, arguments);
    this._toggleGestureCover(false);
    this._stage = 0;
  },
  start: function(e) {
    if (e._needSkipEvent || needSkipEvent(e)) {
      this._cancel(e);
      return;
    }
    this._startEvent = createEvent(e);
    this._startEventData = eventData(e);
    this._stage = 1;
    this._init(e);
    this._setupImmediateTimer();
  },
  _setupImmediateTimer: function() {
    clearTimeout(this._immediateTimer);
    this._immediateAccepted = false;
    if (!this.immediate) {
      return;
    }
    if (0 === this.immediateTimeout) {
      this._immediateAccepted = true;
      return;
    }
    this._immediateTimer = setTimeout((function() {
      this._immediateAccepted = true;
    }).bind(this), this.immediateTimeout ?? 180);
  },
  move: function(e) {
    if (1 === this._stage && this._directionConfirmed(e)) {
      this._stage = 2;
      this._resetActiveElement();
      this._toggleGestureCover(true);
      this._clearSelection(e);
      this._adjustStartEvent(e);
      this._start(this._startEvent);
      if (0 === this._stage) {
        return;
      }
      this._requestAccept(e);
      this._move(e);
      this._forgetAccept();
    } else if (2 === this._stage) {
      this._clearSelection(e);
      this._move(e);
    }
  },
  _directionConfirmed: function(e) {
    const touchBoundary = this._getTouchBoundary(e);
    const delta = eventDelta(this._startEventData, eventData(e));
    const deltaX = abs(delta.x);
    const deltaY = abs(delta.y);
    const horizontalMove = this._validateMove(touchBoundary, deltaX, deltaY);
    const verticalMove = this._validateMove(touchBoundary, deltaY, deltaX);
    const direction = this.getDirection(e);
    const bothAccepted = "both" === direction && (horizontalMove || verticalMove);
    const horizontalAccepted = "horizontal" === direction && horizontalMove;
    const verticalAccepted = "vertical" === direction && verticalMove;
    return bothAccepted || horizontalAccepted || verticalAccepted || this._immediateAccepted;
  },
  _validateMove: function(touchBoundary, mainAxis, crossAxis) {
    return mainAxis && mainAxis >= touchBoundary && (this.immediate ? mainAxis >= crossAxis : true);
  },
  _getTouchBoundary: function(e) {
    return this.immediate || isDxMouseWheelEvent(e) ? 0 : TOUCH_BOUNDARY;
  },
  _adjustStartEvent: function(e) {
    const touchBoundary = this._getTouchBoundary(e);
    const delta = eventDelta(this._startEventData, eventData(e));
    this._startEvent.pageX += sign(delta.x) * touchBoundary;
    this._startEvent.pageY += sign(delta.y) * touchBoundary;
  },
  _resetActiveElement: function() {
    if ("ios" === devices_default.real().platform && this.getElement().find(":focus").length) {
      resetActiveElement();
    }
  },
  _toggleGestureCover: function(toggle) {
    this._toggleGestureCoverImpl(toggle);
  },
  _toggleGestureCoverImpl: function(toggle) {
    const isStarted = 2 === this._stage;
    if (isStarted) {
      gestureCover(toggle, this.getElement().css("cursor"));
    }
  },
  _clearSelection: function(e) {
    if (isDxMouseWheelEvent(e) || isTouchEvent(e)) {
      return;
    }
    clearSelection();
  },
  end: function(e) {
    this._toggleGestureCover(false);
    if (2 === this._stage) {
      this._end(e);
    } else if (1 === this._stage) {
      this._stop(e);
    }
    this._stage = 0;
  },
  dispose: function() {
    clearTimeout(this._immediateTimer);
    this.callBase.apply(this, arguments);
    this._toggleGestureCover(false);
  },
  _init: noop,
  _start: noop,
  _move: noop,
  _stop: noop,
  _end: noop
});
GestureEmitter.initialTouchBoundary = TOUCH_BOUNDARY;
GestureEmitter.touchBoundary = function(newBoundary) {
  if (isDefined(newBoundary)) {
    TOUCH_BOUNDARY = newBoundary;
    return;
  }
  return TOUCH_BOUNDARY;
};
var emitter_gesture_default = GestureEmitter;

export {
  sign,
  fitIntoRange,
  inRange,
  getExponent,
  multiplyInExponentialForm,
  adjust,
  getPrecision,
  solveCubicEquation,
  trunc,
  getRemainderByDivision,
  getExponentLength,
  roundFloatPart,
  emitter_gesture_default
};
//# sourceMappingURL=chunk-XU5XMUT7.js.map
