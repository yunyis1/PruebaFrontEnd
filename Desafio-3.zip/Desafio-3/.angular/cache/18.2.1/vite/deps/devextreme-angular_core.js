import {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
} from "./chunk-JWCECMBJ.js";
import "./chunk-4J52MU3J.js";
import "./chunk-M4HNHSVV.js";
import "./chunk-PJXMQ5JC.js";
import "./chunk-IY7TXKCY.js";
import "./chunk-E4ZFM5M7.js";
import "./chunk-EVP23SIF.js";
import "./chunk-V6EUNM2D.js";
import "./chunk-ORYCWD4C.js";
import "./chunk-I2242OIJ.js";
import "./chunk-N6ESDQJH.js";
export {
  BaseNestedOption,
  CollectionNestedOption,
  CollectionNestedOptionContainerImpl,
  DX_TEMPLATE_WRAPPER_CLASS,
  DxComponent,
  DxComponentExtension,
  DxIntegrationModule,
  DxServerTransferStateModule,
  DxTemplateDirective,
  DxTemplateHost,
  DxTemplateModule,
  EmitterHelper,
  IterableDifferHelper,
  NestedOption,
  NestedOptionHost,
  NgEventsStrategy,
  RenderData,
  WatcherHelper,
  extractTemplate,
  getElement,
  getServerStateKey
};
//# sourceMappingURL=devextreme-angular_core.js.map
