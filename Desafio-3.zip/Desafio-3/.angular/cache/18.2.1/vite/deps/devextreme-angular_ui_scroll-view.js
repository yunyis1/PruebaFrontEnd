import {
  DxScrollViewComponent,
  DxScrollViewModule
} from "./chunk-XDNOGNY2.js";
import "./chunk-L2KSDGQO.js";
import "./chunk-X3V77ZBF.js";
import "./chunk-G6YLJM3X.js";
import "./chunk-BDTQNDWY.js";
import "./chunk-CSW63CAV.js";
import "./chunk-ZLMLMAKO.js";
import "./chunk-MY7IBGWI.js";
import "./chunk-GJ5KWMNN.js";
import "./chunk-XU5XMUT7.js";
import "./chunk-X73RLF6Y.js";
import "./chunk-25VDHZLA.js";
import "./chunk-IMMMCDPJ.js";
import "./chunk-JWCECMBJ.js";
import "./chunk-4J52MU3J.js";
import "./chunk-M4HNHSVV.js";
import "./chunk-PJXMQ5JC.js";
import "./chunk-IY7TXKCY.js";
import "./chunk-E4ZFM5M7.js";
import "./chunk-EVP23SIF.js";
import "./chunk-V6EUNM2D.js";
import "./chunk-ORYCWD4C.js";
import "./chunk-I2242OIJ.js";
import "./chunk-N6ESDQJH.js";
export {
  DxScrollViewComponent,
  DxScrollViewModule
};
//# sourceMappingURL=devextreme-angular_ui_scroll-view.js.map
