import {
  Event,
  off,
  on,
  one,
  trigger,
  triggerHandler
} from "./chunk-4J52MU3J.js";
import "./chunk-PJXMQ5JC.js";
import "./chunk-E4ZFM5M7.js";
import "./chunk-V6EUNM2D.js";
import "./chunk-N6ESDQJH.js";
export {
  Event,
  off,
  on,
  one,
  trigger,
  triggerHandler
};
//# sourceMappingURL=devextreme_events.js.map
