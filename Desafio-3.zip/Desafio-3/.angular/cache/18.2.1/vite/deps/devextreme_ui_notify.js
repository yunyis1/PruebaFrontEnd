import {
  notify_default
} from "./chunk-IWOFADVS.js";
import "./chunk-ZLMLMAKO.js";
import "./chunk-MY7IBGWI.js";
import "./chunk-GJ5KWMNN.js";
import "./chunk-XU5XMUT7.js";
import "./chunk-X73RLF6Y.js";
import "./chunk-25VDHZLA.js";
import "./chunk-IMMMCDPJ.js";
import "./chunk-M4HNHSVV.js";
import "./chunk-PJXMQ5JC.js";
import "./chunk-IY7TXKCY.js";
import "./chunk-E4ZFM5M7.js";
import "./chunk-V6EUNM2D.js";
import "./chunk-N6ESDQJH.js";
export {
  notify_default as default
};
//# sourceMappingURL=devextreme_ui_notify.js.map
