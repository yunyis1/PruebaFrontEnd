import {
  attachCssClasses,
  current,
  detachCssClasses,
  init,
  initialized,
  isCompact,
  isDark,
  isFluent,
  isGeneric,
  isMaterial,
  isMaterialBased,
  isPendingThemeLoaded,
  isWebFontLoaded,
  resetTheme,
  setDefaultTimeout,
  themeReady,
  themes_default,
  waitForThemeLoad,
  waitWebFont
} from "./chunk-ZLMLMAKO.js";
import "./chunk-25VDHZLA.js";
import "./chunk-IMMMCDPJ.js";
import "./chunk-M4HNHSVV.js";
import "./chunk-PJXMQ5JC.js";
import "./chunk-IY7TXKCY.js";
import "./chunk-E4ZFM5M7.js";
import "./chunk-V6EUNM2D.js";
import "./chunk-N6ESDQJH.js";
export {
  attachCssClasses,
  current,
  themes_default as default,
  detachCssClasses,
  init,
  initialized,
  isCompact,
  isDark,
  isFluent,
  isGeneric,
  isMaterial,
  isMaterialBased,
  isPendingThemeLoaded,
  isWebFontLoaded,
  themeReady as ready,
  resetTheme,
  setDefaultTimeout,
  waitForThemeLoad,
  waitWebFont
};
//# sourceMappingURL=devextreme_ui_themes.js.map
