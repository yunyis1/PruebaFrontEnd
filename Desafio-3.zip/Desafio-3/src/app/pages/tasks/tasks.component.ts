import { Component } from '@angular/core';
import 'devextreme/data/odata/store';
import { Employee, serviceEmployee, State } from '../../shared/services';

@Component({
  templateUrl: 'tasks.component.html'
})

export class TasksComponent {
  dataSource: Employee[];

  states: State[];

  constructor(service: serviceEmployee) {
    this.dataSource = service.getEmployees();
    this.states = service.getStates();
  }
 
}
