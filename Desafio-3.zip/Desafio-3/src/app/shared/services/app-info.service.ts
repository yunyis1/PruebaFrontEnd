import { Injectable } from '@angular/core';

@Injectable()
export class AppInfoService {
  constructor() {}

  public get title() {
    return 'Desafio 3';
  }

  public get currentYear() {
    return new Date().getFullYear();
  }
}
